-- GAS CONNECT: базовая схема (SQLite). Идентификаторы — UUID в TEXT, даты — ISO-8601 в TEXT,
-- флаги — INTEGER 0/1. Аналогичная схема для PostgreSQL: migrations/postgres/001_init.sql

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','operator','admin')),
  account_type TEXT NOT NULL CHECK (account_type IN ('person','ip','company','staff')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked')),
  email_verified_at TEXT,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  last_login_at TEXT,
  registration_ip TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_users_type ON users(account_type);
CREATE INDEX idx_users_created ON users(created_at);
CREATE INDEX idx_users_reg_ip ON users(registration_ip, created_at);

CREATE TABLE profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  region TEXT,
  city TEXT,
  phone TEXT,
  contact_note TEXT,
  preferred_fuel TEXT,
  position TEXT,
  notify_email INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);

CREATE TABLE consents (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  document TEXT NOT NULL,
  version TEXT NOT NULL,
  ip TEXT,
  accepted_at TEXT NOT NULL
);
CREATE INDEX idx_consents_user ON consents(user_id);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ip TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE auth_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('verify','reset')),
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT
);
CREATE INDEX idx_tokens_user ON auth_tokens(user_id, kind);

CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  org_type TEXT NOT NULL CHECK (org_type IN ('ip','company')),
  full_name TEXT NOT NULL,
  short_name TEXT,
  legal_form TEXT,
  inn TEXT NOT NULL UNIQUE,
  region TEXT,
  legal_address TEXT,
  activity TEXT,
  employees INTEGER,
  fleet_size INTEGER,
  vehicle_types TEXT,
  transport_directions TEXT,
  trip_frequency TEXT,
  est_monthly_gas REAL,
  est_monthly_gas_unit TEXT,
  contact_person TEXT,
  contact_position TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  verification_status TEXT NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','pending','verified','rejected')),
  verification_note TEXT,
  verified_at TEXT,
  verified_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_org_region ON organizations(region);
CREATE INDEX idx_org_verif ON organizations(verification_status);

CREATE TABLE organization_members (
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  member_role TEXT NOT NULL CHECK (member_role IN ('owner','manager','viewer')),
  created_at TEXT NOT NULL,
  PRIMARY KEY (organization_id, user_id)
);
CREATE INDEX idx_members_user ON organization_members(user_id);

CREATE TABLE organization_invites (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  member_role TEXT NOT NULL CHECK (member_role IN ('manager','viewer')),
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  accepted_at TEXT
);
CREATE INDEX idx_invites_email ON organization_invites(email);

CREATE TABLE vehicles (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  organization_id TEXT REFERENCES organizations(id) ON DELETE CASCADE,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER,
  vehicle_type TEXT NOT NULL,
  fuel_type TEXT NOT NULL,
  equipment_type TEXT,
  cylinder_count INTEGER,
  cylinder_volume_l REAL,
  working_pressure_bar REAL,
  lng_tank_l REAL,
  gas_stock_m3 REAL,
  gas_stock_kg REAL,
  stock_is_manual INTEGER NOT NULL DEFAULT 0,
  consumption_value REAL,
  consumption_unit TEXT,
  range_km REAL,
  monthly_mileage_km REAL,
  payload_t REAL,
  quantity INTEGER NOT NULL DEFAULT 1,
  convertible INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (owner_user_id IS NOT NULL OR organization_id IS NOT NULL)
);
CREATE INDEX idx_vehicles_owner ON vehicles(owner_user_id);
CREATE INDEX idx_vehicles_org ON vehicles(organization_id);
CREATE INDEX idx_vehicles_fuel ON vehicles(fuel_type);

-- Автопарк организаций (FleetVehicles) — представление над общей таблицей транспорта.
CREATE VIEW fleet_vehicles AS SELECT * FROM vehicles WHERE organization_id IS NOT NULL;

CREATE TABLE user_routes (
  id TEXT PRIMARY KEY,
  owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organization_id TEXT REFERENCES organizations(id) ON DELETE CASCADE,
  vehicle_id TEXT REFERENCES vehicles(id) ON DELETE SET NULL,
  origin_name TEXT NOT NULL,
  origin_lat REAL,
  origin_lng REAL,
  dest_name TEXT NOT NULL,
  dest_lat REAL,
  dest_lng REAL,
  waypoints TEXT,
  distance_km REAL,
  distance_source TEXT,
  geometry TEXT,
  trips_per_month REAL NOT NULL,
  purpose TEXT,
  preferred_stops TEXT,
  alternatives TEXT,
  station_issues TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_routes_owner ON user_routes(owner_user_id);
CREATE INDEX idx_routes_org ON user_routes(organization_id);
CREATE INDEX idx_routes_vehicle ON user_routes(vehicle_id);

CREATE TABLE stations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('agnks','cryo','modular','pagz','multi')),
  fuels TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('operational','construction','planned','closed')),
  operator_name TEXT,
  address TEXT,
  region TEXT,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  service_radius_km REAL,
  dispensers INTEGER,
  capacity_value REAL,
  capacity_unit TEXT,
  hours TEXT,
  hours_confirmed INTEGER NOT NULL DEFAULT 0,
  photo_key TEXT,
  description TEXT,
  source_name TEXT,
  source_url TEXT,
  data_updated_at TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_stations_status ON stations(status);
CREATE INDEX idx_stations_kind ON stations(kind);
CREATE INDEX idx_stations_region ON stations(region);
CREATE INDEX idx_stations_geo ON stations(lat, lng);

CREATE TABLE station_development_plans (
  id TEXT PRIMARY KEY,
  station_id TEXT NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
  planned_year INTEGER,
  category TEXT NOT NULL CHECK (category IN ('confirmed','announced','under_review','user_initiative')),
  basis TEXT,
  source_name TEXT,
  source_url TEXT,
  published INTEGER NOT NULL DEFAULT 1,
  proposal_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_plans_station ON station_development_plans(station_id);
CREATE INDEX idx_plans_year ON station_development_plans(planned_year);

CREATE TABLE station_proposals (
  id TEXT PRIMARY KEY,
  author_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  region TEXT NOT NULL,
  settlement TEXT NOT NULL,
  highway TEXT,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  justification TEXT NOT NULL,
  travel_frequency TEXT,
  transport_type TEXT,
  has_alternatives INTEGER NOT NULL DEFAULT 0,
  alternatives_note TEXT,
  distance_to_nearest_km REAL,
  preferred_kind TEXT,
  comment TEXT,
  author_vehicles INTEGER NOT NULL DEFAULT 1,
  author_fuel TEXT,
  author_monthly_volume REAL,
  status TEXT NOT NULL CHECK (status IN ('pending','published','under_review','included','rejected','hidden')),
  moderation_note TEXT,
  photo_key TEXT,
  linked_station_id TEXT REFERENCES stations(id) ON DELETE SET NULL,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_proposals_status ON station_proposals(status);
CREATE INDEX idx_proposals_region ON station_proposals(region);
CREATE INDEX idx_proposals_author ON station_proposals(author_id);

CREATE TABLE votes (
  proposal_id TEXT NOT NULL REFERENCES station_proposals(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  vehicles_count INTEGER NOT NULL DEFAULT 1,
  fuel_type TEXT,
  trips_per_month REAL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (proposal_id, user_id)
);
CREATE INDEX idx_votes_user ON votes(user_id);

CREATE TABLE comments (
  id TEXT PRIMARY KEY,
  proposal_id TEXT NOT NULL REFERENCES station_proposals(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','hidden','pending')),
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_comments_proposal ON comments(proposal_id, created_at);
CREATE INDEX idx_comments_user ON comments(user_id, created_at);

CREATE TABLE commercial_offers (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('draft','submitted','in_review','needs_info','preliminarily_approved','rejected')),
  title TEXT NOT NULL,
  fuel_type TEXT NOT NULL,
  volume_unit TEXT NOT NULL,
  monthly_volume REAL,
  annual_volume REAL,
  min_guaranteed_volume REAL,
  term_months INTEGER,
  vehicles_total INTEGER,
  vehicles_convertible INTEGER,
  main_region TEXT,
  details TEXT NOT NULL,
  submitted_at TEXT,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_offers_org ON commercial_offers(organization_id);
CREATE INDEX idx_offers_status ON commercial_offers(status);

CREATE TABLE offer_messages (
  id TEXT PRIMARY KEY,
  offer_id TEXT NOT NULL REFERENCES commercial_offers(id) ON DELETE CASCADE,
  author_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  author_side TEXT NOT NULL CHECK (author_side IN ('operator','client','system')),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_offer_messages ON offer_messages(offer_id, created_at);

CREATE TABLE offer_documents (
  id TEXT PRIMARY KEY,
  offer_id TEXT NOT NULL REFERENCES commercial_offers(id) ON DELETE CASCADE,
  uploaded_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  original_name TEXT NOT NULL,
  mime TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  storage_key TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_offer_docs ON offer_documents(offer_id);

CREATE TABLE contracts (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  offer_id TEXT REFERENCES commercial_offers(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('preliminary','signed_offline','terminated')),
  fuel_type TEXT NOT NULL,
  volume_unit TEXT NOT NULL,
  contracted_monthly_volume REAL NOT NULL,
  region TEXT,
  start_date TEXT,
  term_months INTEGER,
  note TEXT,
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_contracts_org ON contracts(organization_id);

CREATE TABLE status_history (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  from_status TEXT,
  to_status TEXT NOT NULL,
  comment TEXT,
  actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_status_history ON status_history(entity_type, entity_id, created_at);

CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_notifications_user ON notifications(user_id, created_at);

CREATE TABLE favorites (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('station','proposal','route')),
  entity_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, entity_type, entity_id)
);
CREATE INDEX idx_favorites_entity ON favorites(entity_type, entity_id);

CREATE TABLE news (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  summary TEXT,
  body TEXT NOT NULL,
  photo_key TEXT,
  status TEXT NOT NULL CHECK (status IN ('draft','published')),
  published_at TEXT,
  author_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX idx_news_status ON news(status, published_at);

CREATE TABLE feedback (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  name TEXT,
  email TEXT,
  topic TEXT NOT NULL,
  message TEXT NOT NULL,
  related TEXT,
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','in_progress','closed')),
  ip TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_feedback_status ON feedback(status, created_at);

CREATE TABLE investment_scenarios (
  id TEXT PRIMARY KEY,
  author_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  inputs TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE mail_outbox (
  id TEXT PRIMARY KEY,
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body_text TEXT NOT NULL,
  status TEXT NOT NULL,
  error TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_outbox_created ON mail_outbox(created_at);

CREATE TABLE audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  details TEXT,
  ip TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
