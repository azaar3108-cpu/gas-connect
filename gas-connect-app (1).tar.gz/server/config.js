// Загрузка конфигурации из переменных окружения и файла .env (без внешних зависимостей).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function loadDotEnv(file = path.join(ROOT, '.env')) {
  if (!fs.existsSync(file)) return;
  const text = fs.readFileSync(file, 'utf8');
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 0) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    } else {
      // Комментарий в конце строки: «KEY=value   # пояснение»
      const hash = value.search(/\s+#/);
      if (hash >= 0) value = value.slice(0, hash).trim();
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

const bool = (v, d = false) => (v === undefined || v === '' ? d : ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase()));
const int = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));

export function buildConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || 'development';
  const production = nodeEnv === 'production';
  const port = int(env.PORT, 3000);
  const cfg = {
    env: nodeEnv,
    production,
    test: nodeEnv === 'test',
    host: env.HOST || '0.0.0.0',
    port,
    appUrl: (env.APP_URL || `http://localhost:${port}`).replace(/\/$/, ''),
    trustProxy: bool(env.TRUST_PROXY, false),
    cookieSecure: bool(env.COOKIE_SECURE, production),
    sessionTtlDays: int(env.SESSION_TTL_DAYS, 14),
    db: {
      driver: (env.DB_DRIVER || 'sqlite').toLowerCase(),
      sqlitePath: path.resolve(ROOT, env.SQLITE_PATH || 'data/gas-connect.sqlite'),
      url: env.DATABASE_URL || '',
      poolSize: int(env.PG_POOL_SIZE, 10),
    },
    mail: {
      driver: (env.MAIL_DRIVER || 'console').toLowerCase(),
      from: env.MAIL_FROM || 'GAS CONNECT <no-reply@gas-connect.local>',
      smtpHost: env.SMTP_HOST || '',
      smtpPort: int(env.SMTP_PORT, 465),
      smtpUser: env.SMTP_USER || '',
      smtpPass: env.SMTP_PASS || '',
      smtpSecure: bool(env.SMTP_SECURE, true),
    },
    routing: {
      enabled: bool(env.ROUTING_ENABLED, true),
      url: (env.ROUTING_URL || 'https://router.project-osrm.org').replace(/\/$/, ''),
      timeoutMs: int(env.ROUTING_TIMEOUT_MS, 6000),
    },
    proposalModeration: (env.PROPOSAL_MODERATION || 'pre').toLowerCase(), // pre | post
    uploadDir: path.resolve(ROOT, env.UPLOAD_DIR || 'data/uploads'),
    maxUploadMb: int(env.MAX_UPLOAD_MB, 10),
    seedPassword: env.SEED_PASSWORD || '',
    allowDemoSeed: bool(env.ALLOW_DEMO_SEED, !production),
    allowDemoLogin: bool(env.ALLOW_DEMO_LOGIN, !production),
    rateLimits: bool(env.RATE_LIMITS, true),
    devMailPreview: bool(env.DEV_MAIL_PREVIEW, !production),
    // false — e-mail считается подтверждённым сразу при регистрации (временный режим, пока не настроена почта SMTP)
    requireEmailVerification: bool(env.REQUIRE_EMAIL_VERIFICATION, true),
    // Первичная настройка сервера без доступа к консоли (например, на PaaS-хостинге)
    autoSeedDemo: bool(env.AUTO_SEED_DEMO, false),
    bootstrapAdmin: { email: (env.ADMIN_EMAIL || '').trim().toLowerCase(), password: env.ADMIN_PASSWORD || '' },
    minFormFillMs: int(env.MIN_FORM_FILL_MS, 2500),
  };
  if (!['sqlite', 'postgres'].includes(cfg.db.driver)) {
    throw new Error(`DB_DRIVER должен быть sqlite или postgres, получено: ${cfg.db.driver}`);
  }
  if (cfg.db.driver === 'postgres' && !cfg.db.url) {
    throw new Error('Для DB_DRIVER=postgres необходимо указать DATABASE_URL');
  }
  if (production && cfg.devMailPreview) {
    throw new Error('DEV_MAIL_PREVIEW нельзя включать в production: ссылки из писем будут видны в интерфейсе');
  }
  return cfg;
}
