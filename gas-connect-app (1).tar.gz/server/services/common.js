// Общие сервисные функции: аудит, уведомления, история статусов, права в организации.
import { uuid } from '../lib/security.js';
import { forbidden, notFound } from '../lib/http.js';

export const nowIso = () => new Date().toISOString();

export async function audit(db, ctx, action, entityType = null, entityId = null, details = null) {
  await db.insert('audit_logs', {
    id: uuid(),
    actor_id: ctx?.user?.id || null,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details: details ? JSON.stringify(details).slice(0, 4000) : null,
    ip: ctx?.ip || null,
    created_at: nowIso(),
  });
}

export async function notify(db, userIds, { kind, title, body = null, link = null }) {
  const ids = [...new Set((Array.isArray(userIds) ? userIds : [userIds]).filter(Boolean))];
  const created = nowIso();
  for (const id of ids) {
    await db.insert('notifications', { id: uuid(), user_id: id, kind, title: String(title).slice(0, 200), body: body ? String(body).slice(0, 1000) : null, link, created_at: created });
  }
  return ids.length;
}

export async function orgMemberIds(db, orgId) {
  return (await db.all('SELECT user_id FROM organization_members WHERE organization_id = ?', [orgId])).map((r) => r.user_id);
}

export async function followerIds(db, entityType, entityId) {
  return (await db.all('SELECT user_id FROM favorites WHERE entity_type = ? AND entity_id = ?', [entityType, entityId])).map((r) => r.user_id);
}

export async function recordStatus(db, ctx, entityType, entityId, fromStatus, toStatus, comment = null) {
  await db.insert('status_history', { id: uuid(), entity_type: entityType, entity_id: entityId, from_status: fromStatus, to_status: toStatus, comment, actor_id: ctx?.user?.id || null, created_at: nowIso() });
}

/** Членство пользователя в организации (у пользователя ИП/юрлица — одна активная организация). */
export async function getMembership(db, userId) {
  return db.get(
    `SELECT m.organization_id, m.member_role, o.org_type, o.full_name, o.short_name, o.inn, o.region, o.verification_status
     FROM organization_members m JOIN organizations o ON o.id = m.organization_id
     WHERE m.user_id = ? ORDER BY CASE m.member_role WHEN 'owner' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END LIMIT 1`, [userId]);
}

export const ORG_ROLE_RANK = { viewer: 1, manager: 2, owner: 3 };

export async function requireOrg(ctx, minRole = 'viewer') {
  const m = await getMembership(ctx.db, ctx.user.id);
  if (!m) throw forbidden('Действие доступно ИП и юридическим лицам, зарегистрированным в организации');
  if (ORG_ROLE_RANK[m.member_role] < ORG_ROLE_RANK[minRole]) {
    throw forbidden(minRole === 'owner' ? 'Действие доступно только владельцу аккаунта организации' : 'Ваша роль в организации позволяет только просмотр');
  }
  return m;
}

export async function mustGet(db, sql, params, message) {
  const row = await db.get(sql, params);
  if (!row) throw notFound(message);
  return row;
}

export function parseJson(s, fallback = null) {
  if (s === null || s === undefined || s === '') return fallback;
  if (typeof s === 'object') return s;
  try { return JSON.parse(s); } catch { return fallback; }
}

export function isStaff(user) {
  return !!user && (user.role === 'operator' || user.role === 'admin');
}

export function csvEscape(v) {
  const s = v === null || v === undefined ? '' : String(v);
  // Защита от CSV-инъекций формул в табличных редакторах.
  const safe = /^[=+\-@\t\r]/.test(s) ? "'" + s : s;
  return '"' + safe.replace(/"/g, '""') + '"';
}

export function toCsv(rows, columns) {
  const head = columns.map((c) => csvEscape(c.label)).join(';');
  const body = rows.map((r) => columns.map((c) => csvEscape(typeof c.get === 'function' ? c.get(r) : r[c.key])).join(';'));
  return '﻿' + [head, ...body].join('\r\n');
}
