// Расчёт спроса: объединение интереса нескольких участников без двойного учёта автомобилей,
// трёхуровневая модель спроса для панели оператора.
import { locateOnPolyline, haversine } from '../../public/assets/js/shared/geo.js';
import { vehicleMetrics, PHYS } from '../../public/assets/js/shared/calc.js';
import { parseJson } from './common.js';

export const POOL_RADIUS_KM = 25;

export async function loadDemandContext(db) {
  const routes = (await db.all('SELECT id, owner_user_id, organization_id, vehicle_id, geometry, trips_per_month, distance_km FROM user_routes WHERE geometry IS NOT NULL'))
    .map((r) => ({ ...r, line: parseJson(r.geometry, []) })).filter((r) => r.line.length >= 2);
  const vehicles = await db.all('SELECT * FROM vehicles');
  const vehicleById = new Map(vehicles.map((v) => [v.id, v]));
  const votes = await db.all('SELECT proposal_id, user_id, organization_id, vehicles_count, fuel_type FROM votes');
  return { routes, vehicleById, votes };
}

function quickBoxNear(line, p, km) {
  // Быстрый отсев по ограничивающему прямоугольнику (1° широты ≈ 111 км).
  const dLat = km / 111, dLng = km / (111 * Math.max(0.2, Math.cos((p[0] * Math.PI) / 180)));
  let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
  for (const [la, ln] of line) { if (la < minLat) minLat = la; if (la > maxLat) maxLat = la; if (ln < minLng) minLng = ln; if (ln > maxLng) maxLng = ln; }
  return p[0] >= minLat - dLat && p[0] <= maxLat + dLat && p[1] >= minLng - dLng && p[1] <= maxLng + dLng;
}

/**
 * Объединение спроса в точке: участники — организации (или пользователи без организации),
 * чьи маршруты проходят в радиусе POOL_RADIUS_KM, плюс проголосовавшие за инициативу.
 * Автомобиль учитывается один раз, даже если через точку проходят несколько его маршрутов;
 * заявленное при голосовании число автомобилей участника не суммируется с найденными по маршрутам — берётся максимум.
 */
export function poolDemand(point, ctxData, proposalId = null, radiusKm = POOL_RADIUS_KM) {
  const parties = new Map();
  const party = (orgId, userId) => {
    const key = orgId ? `o:${orgId}` : `u:${userId}`;
    let p = parties.get(key);
    if (!p) { p = { key, isOrg: !!orgId, vehicleIds: new Set(), unknownVehicleRoutes: 0, declared: 0, voted: false, routes: 0 }; parties.set(key, p); }
    return p;
  };
  let routesNear = 0;
  for (const r of ctxData.routes) {
    if (!quickBoxNear(r.line, point, radiusKm)) continue;
    const loc = locateOnPolyline(point, r.line);
    if (loc.distanceKm > radiusKm) continue;
    routesNear++;
    const p = party(r.organization_id, r.owner_user_id);
    p.routes++;
    if (r.vehicle_id && ctxData.vehicleById.has(r.vehicle_id)) p.vehicleIds.add(r.vehicle_id);
    else p.unknownVehicleRoutes++;
  }
  if (proposalId) {
    for (const v of ctxData.votes) {
      if (v.proposal_id !== proposalId) continue;
      const p = party(v.organization_id, v.user_id);
      p.voted = true;
      p.declared = Math.max(p.declared, Number(v.vehicles_count) || 1);
    }
  }
  let vehiclesFromRoutes = 0, vehiclesTotal = 0, demandM3 = 0, demandKg = 0, orgs = 0, persons = 0;
  for (const p of parties.values()) {
    if (p.isOrg) orgs++; else persons++;
    let fromRoutes = 0;
    for (const id of p.vehicleIds) {
      const v = ctxData.vehicleById.get(id);
      const q = Number(v.quantity) || 1;
      fromRoutes += q;
      const m = vehicleMetrics(v);
      if (m.monthlyDemand) { if (m.methane === 'cng') demandM3 += m.monthlyDemand; else if (m.methane === 'lng') demandKg += m.monthlyDemand; }
    }
    vehiclesFromRoutes += fromRoutes;
    vehiclesTotal += Math.max(fromRoutes, p.declared, p.unknownVehicleRoutes ? 1 : 0);
  }
  return {
    radiusKm,
    parties: parties.size,
    organizations: orgs,
    persons,
    routesNear,
    vehiclesFromRoutes,
    vehiclesTotal,
    demandM3: Math.round(demandM3),
    demandKg: Math.round(demandKg),
    multiCompany: orgs >= 2,
  };
}

export function equivalentM3(p) {
  return (p.demandM3 || 0) + (p.demandKg || 0) * PHYS.M3_PER_KG_GAS;
}

/** Трёхуровневая модель спроса по регионам. Значения уровней не суммируются между собой. */
export async function demandTiers(db) {
  const users = await db.all("SELECT u.id, u.account_type, p.region FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE u.role = 'user'");
  const regionOfUser = new Map(users.map((u) => [u.id, u.region || 'Не указан']));
  const orgs = await db.all('SELECT id, region FROM organizations');
  const regionOfOrg = new Map(orgs.map((o) => [o.id, o.region || 'Не указан']));
  const regions = new Map();
  const R = (name) => {
    let r = regions.get(name);
    if (!r) { r = { region: name, votes: 0, proposals: 0, declaredVehicles: 0, estimatedM3: 0, estimatedKg: 0, offersM3: 0, offersKg: 0, contractM3: 0, contractKg: 0, vehicles: 0 }; regions.set(name, r); }
    return r;
  };
  // Уровень 1 — интерес.
  const proposals = await db.all("SELECT id, region FROM station_proposals WHERE status IN ('published','under_review','included')");
  const proposalRegion = new Map(proposals.map((p) => [p.id, p.region]));
  for (const p of proposals) R(p.region).proposals++;
  for (const v of await db.all('SELECT proposal_id, vehicles_count FROM votes')) {
    const reg = proposalRegion.get(v.proposal_id);
    if (!reg) continue;
    R(reg).votes++;
    R(reg).declaredVehicles += Number(v.vehicles_count) || 0;
  }
  // Уровень 2 — расчётный спрос по автомобилям (пробег × расход). Автомобиль учитывается один раз.
  const perOrgEstimate = new Map();
  for (const v of await db.all('SELECT * FROM vehicles')) {
    const reg = v.organization_id ? regionOfOrg.get(v.organization_id) : regionOfUser.get(v.owner_user_id);
    if (!reg) continue;
    const m = vehicleMetrics(v);
    const r = R(reg);
    r.vehicles += Number(v.quantity) || 1;
    if (!m.monthlyDemand) continue;
    if (m.methane === 'cng') r.estimatedM3 += m.monthlyDemand;
    if (m.methane === 'lng') r.estimatedKg += m.monthlyDemand;
    if (v.organization_id) {
      const e = perOrgEstimate.get(v.organization_id) || { m3: 0, kg: 0 };
      if (m.methane === 'cng') e.m3 += m.monthlyDemand; else e.kg += m.monthlyDemand;
      perOrgEstimate.set(v.organization_id, e);
    }
  }
  // Заявленные в коммерческих предложениях объёмы относятся ко 2-му уровню (не подтверждены),
  // показываются отдельно; для организации берётся последнее активное предложение по каждому виду топлива.
  const offers = await db.all("SELECT organization_id, fuel_type, volume_unit, monthly_volume, updated_at FROM commercial_offers WHERE status IN ('submitted','in_review','needs_info','preliminarily_approved') ORDER BY updated_at DESC");
  const seen = new Set();
  for (const o of offers) {
    const key = `${o.organization_id}:${o.fuel_type}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const r = R(regionOfOrg.get(o.organization_id) || 'Не указан');
    const vol = Number(o.monthly_volume) || 0;
    if (o.fuel_type === 'lng') r.offersKg += o.volume_unit === 'т' ? vol * 1000 : vol; else r.offersM3 += vol;
  }
  // Уровень 3 — договорной спрос: только договорённости, подтверждённые оператором.
  for (const c of await db.all("SELECT organization_id, region, fuel_type, volume_unit, contracted_monthly_volume FROM contracts WHERE status IN ('preliminary','signed_offline')")) {
    const r = R(c.region || regionOfOrg.get(c.organization_id) || 'Не указан');
    const vol = Number(c.contracted_monthly_volume) || 0;
    if (c.fuel_type === 'lng') r.contractKg += c.volume_unit === 'т' ? vol * 1000 : vol; else r.contractM3 += vol;
  }
  const list = [...regions.values()].map((r) => ({ ...r, estimatedM3: Math.round(r.estimatedM3), estimatedKg: Math.round(r.estimatedKg) }));
  const sum = (k) => list.reduce((a, r) => a + (r[k] || 0), 0);
  return {
    regions: list.sort((a, b) => (b.estimatedM3 + b.estimatedKg * PHYS.M3_PER_KG_GAS + b.votes * 100) - (a.estimatedM3 + a.estimatedKg * PHYS.M3_PER_KG_GAS + a.votes * 100)),
    totals: {
      interest: { votes: sum('votes'), proposals: sum('proposals'), declaredVehicles: sum('declaredVehicles') },
      estimated: { m3: sum('estimatedM3'), kg: sum('estimatedKg'), offersM3: sum('offersM3'), offersKg: sum('offersKg'), vehicles: sum('vehicles') },
      contracted: { m3: sum('contractM3'), kg: sum('contractKg') },
    },
    methodology: [
      'Уровень 1 «Интерес»: число голосов, опубликованных инициатив и заявленное при голосовании число автомобилей. Не является прогнозом продаж.',
      'Уровень 2 «Расчётный спрос»: Σ (среднемесячный пробег × средний расход ÷ 100 × количество ТС) по зарегистрированным автомобилям на метане. Каждый автомобиль учитывается один раз независимо от числа маршрутов. Объёмы из коммерческих предложений показаны отдельной строкой и с расчётом по автопаркам не суммируются.',
      'Уровень 3 «Договорной спрос»: объёмы по договорённостям, подтверждённым оператором (предварительные и подписанные вне платформы).',
      'КПГ учитывается в м³ при стандартных условиях, СПГ — в кг. Пересчёт СПГ в м³ (1 кг ≈ 1,39 м³) используется только для сортировки.',
    ],
  };
}

/** Пользователи, чьи маршруты проходят в радиусе radiusKm от точки (для уведомлений о новых объектах). */
export async function usersWithRoutesNear(db, point, radiusKm = 15) {
  const rows = await db.all('SELECT owner_user_id, geometry FROM user_routes WHERE geometry IS NOT NULL');
  const out = new Set();
  for (const r of rows) {
    if (out.has(r.owner_user_id)) continue;
    const line = parseJson(r.geometry, []);
    if (line.length < 2 || !quickBoxNear(line, point, radiusKm)) continue;
    if (locateOnPolyline(point, line).distanceKm <= radiusKm) out.add(r.owner_user_id);
  }
  return [...out];
}

export function nearestDistanceKm(point, stations) {
  let best = Infinity;
  for (const s of stations) best = Math.min(best, haversine(point, [s.lat, s.lng]));
  return Number.isFinite(best) ? Math.round(best) : null;
}
