// Построение автомобильного маршрута через OSRM. Если сервис недоступен — явная оценка по прямой ×1,25.
import { downsample, polylineLength, straightLine } from '../../public/assets/js/shared/geo.js';

export const DETOUR_FACTOR = 1.25;
const cache = new Map();

export async function buildRoute(config, points, { alternatives = false } = {}) {
  const key = JSON.stringify([points, alternatives]);
  if (cache.has(key)) return cache.get(key);
  let result = null;
  if (config.routing.enabled && points.length >= 2 && points.length <= 12) {
    try {
      const coords = points.map((p) => `${p[1].toFixed(5)},${p[0].toFixed(5)}`).join(';');
      const url = `${config.routing.url}/route/v1/driving/${coords}?overview=full&geometries=geojson&alternatives=${alternatives && points.length === 2 ? 'true' : 'false'}`;
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), config.routing.timeoutMs);
      const resp = await fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': 'GAS-CONNECT-demo/1.0' } });
      clearTimeout(t);
      if (resp.ok) {
        const data = await resp.json();
        if (data.code === 'Ok' && data.routes?.length) {
          const routes = data.routes.slice(0, 3).map((r) => ({
            line: downsample(r.geometry.coordinates.map(([lng, lat]) => [lat, lng]), 600),
            distanceKm: Math.round(r.distance / 100) / 10,
            durationMin: Math.round(r.duration / 60),
          }));
          result = { source: 'osrm', sourceLabel: 'Дорожный граф OpenStreetMap (OSRM)', ...routes[0], alternatives: routes.slice(1) };
        }
      }
    } catch { /* сервис недоступен — используем оценку */ }
  }
  if (!result) {
    const line = straightLine(points, 10);
    const straight = polylineLength(line);
    result = {
      source: 'estimate',
      sourceLabel: `Оценка: расстояние по прямой × ${DETOUR_FACTOR.toString().replace('.', ',')} (маршрутизатор недоступен — демонстрационный расчёт)`,
      line: downsample(line, 400),
      distanceKm: Math.round(straight * DETOUR_FACTOR * 10) / 10,
      straightKm: Math.round(straight * 10) / 10,
      durationMin: null,
      alternatives: [],
    };
  }
  if (cache.size > 300) cache.clear();
  cache.set(key, result);
  return result;
}
