// Инициативы строительства станций, голосование и обсуждение.
import { validate, latRule, lngRule } from '../lib/validate.js';
import { HttpError, notFound, forbidden, conflict } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { audit, getMembership, nowIso, isStaff, notify, recordStatus } from '../services/common.js';
import { loadDemandContext, poolDemand, equivalentM3, nearestDistanceKm } from '../services/demand.js';
import { haversine } from '../../public/assets/js/shared/geo.js';

export const PROPOSAL_STATUS = {
  pending: 'На модерации', published: 'Сбор голосов', under_review: 'Рассматривается оператором',
  included: 'Включена в план развития', rejected: 'Отклонена', hidden: 'Скрыта модератором',
};
export const KIND_OPTIONS = { agnks: 'АГНКС', modular: 'Модульная АГНКС', cryo: 'КриоАЗС (СПГ)', pagz: 'ПАГЗ', multi: 'АЗС с метаном', any: 'Не важно' };
const PUBLIC_STATUSES = ['published', 'under_review', 'included', 'rejected'];
const VOTABLE = ['published', 'under_review'];

export function proposalDto(p, extra = {}) {
  return {
    id: p.id, title: p.title, region: p.region, settlement: p.settlement, highway: p.highway, lat: p.lat, lng: p.lng,
    justification: p.justification, travelFrequency: p.travel_frequency, transportType: p.transport_type, hasAlternatives: !!p.has_alternatives,
    alternativesNote: p.alternatives_note, distanceToNearestKm: p.distance_to_nearest_km, preferredKind: p.preferred_kind, preferredKindLabel: KIND_OPTIONS[p.preferred_kind] || '—',
    comment: p.comment, authorVehicles: p.author_vehicles, authorFuel: p.author_fuel, status: p.status, statusLabel: PROPOSAL_STATUS[p.status],
    moderationNote: p.moderation_note, photoKey: p.photo_key, linkedStationId: p.linked_station_id, isDemo: !!p.is_demo, createdAt: p.created_at, updatedAt: p.updated_at,
    ...extra,
  };
}

const PROPOSAL_SCHEMA = {
  region: { type: 'string', required: true, max: 120, label: 'Регион' },
  settlement: { type: 'string', required: true, max: 120, label: 'Ближайший населённый пункт' },
  highway: { type: 'string', max: 120, label: 'Автомобильная трасса' },
  lat: latRule('Широта точки', true),
  lng: lngRule('Долгота точки', true),
  justification: { type: 'text', required: true, min: 20, max: 2000, label: 'Почему здесь необходима заправка' },
  travelFrequency: { type: 'enum', values: ['Ежедневно', 'Несколько раз в неделю', 'Еженедельно', 'Несколько раз в месяц', 'Реже раза в месяц'], required: true, label: 'Как часто вы проезжаете участок' },
  transportType: { type: 'string', required: true, max: 120, label: 'Транспорт' },
  hasAlternatives: { type: 'bool', label: 'Есть альтернативные заправки' },
  alternativesNote: { type: 'string', max: 300, label: 'Альтернативы' },
  distanceToNearestKm: { type: 'number', min: 0, max: 5000, label: 'Расстояние до ближайшей станции, км' },
  preferredKind: { type: 'enum', values: Object.keys(KIND_OPTIONS), default: 'any', label: 'Предпочтительный тип станции' },
  comment: { type: 'text', max: 1000, label: 'Комментарий' },
  authorVehicles: { type: 'int', min: 1, max: 10000, default: 1, label: 'Сколько ваших автомобилей заправлялись бы здесь' },
  authorFuel: { type: 'enum', values: ['cng', 'lng', 'both'], default: 'cng', label: 'Вид топлива' },
  force: { type: 'bool', label: 'Подтверждение' },
};

const PHOTO_BY_KIND = { cryo: 'lng-station', pagz: 'trucks-road', modular: 'cng-dispenser', agnks: 'cng-station', multi: 'cng-station-2', any: 'highway' };

async function maxVehiclesFor(db, userId) {
  const m = await getMembership(db, userId);
  if (!m) return { limit: 5, orgId: null };
  const org = await db.get('SELECT fleet_size FROM organizations WHERE id = ?', [m.organization_id]);
  const fleet = await db.count('SELECT COALESCE(SUM(quantity),0) AS n FROM vehicles WHERE organization_id = ?', [m.organization_id]);
  return { limit: Math.max(5, Number(org?.fleet_size) || 0, fleet), orgId: m.organization_id };
}

export default function register(r, { db, config }) {
  r.get('/api/proposals', async (ctx) => {
    const q = ctx.query;
    const staff = isStaff(ctx.user);
    let statuses = PUBLIC_STATUSES.filter((s) => s !== 'rejected');
    if (q.status && (PUBLIC_STATUSES.includes(q.status) || (staff && PROPOSAL_STATUS[q.status]))) statuses = [q.status];
    let rows = await db.all(`SELECT * FROM station_proposals WHERE status IN (${statuses.map(() => '?').join(',')}) ORDER BY created_at DESC`, statuses);
    if (q.region) rows = rows.filter((p) => p.region === q.region);
    if (q.mine && ctx.user) rows = (await db.all('SELECT * FROM station_proposals WHERE author_id = ? ORDER BY created_at DESC', [ctx.user.id]));
    const votes = Object.fromEntries((await db.all('SELECT proposal_id, COUNT(*) AS n FROM votes GROUP BY proposal_id')).map((x) => [x.proposal_id, Number(x.n)]));
    const comments = Object.fromEntries((await db.all("SELECT proposal_id, COUNT(*) AS n FROM comments WHERE status = 'visible' GROUP BY proposal_id")).map((x) => [x.proposal_id, Number(x.n)]));
    const myVotes = ctx.user ? new Set((await db.all('SELECT proposal_id FROM votes WHERE user_id = ?', [ctx.user.id])).map((x) => x.proposal_id)) : new Set();
    const dctx = await loadDemandContext(db);
    const items = rows.map((p) => {
      const pool = poolDemand([p.lat, p.lng], dctx, p.id);
      return proposalDto(p, { votes: votes[p.id] || 0, comments: comments[p.id] || 0, myVote: myVotes.has(p.id), demand: pool, demandEquivM3: Math.round(equivalentM3(pool)) });
    });
    const sort = q.sort || 'votes';
    const sorters = {
      votes: (a, b) => b.votes - a.votes,
      vehicles: (a, b) => b.demand.vehiclesTotal - a.demand.vehiclesTotal,
      volume: (a, b) => b.demandEquivM3 - a.demandEquivM3,
      new: (a, b) => (a.createdAt < b.createdAt ? 1 : -1),
      region: (a, b) => a.region.localeCompare(b.region, 'ru'),
      status: (a, b) => a.status.localeCompare(b.status),
    };
    items.sort(sorters[sort] || sorters.votes);
    const regions = [...new Set(items.map((x) => x.region))].sort((a, b) => a.localeCompare(b, 'ru'));
    return { items, regions, statuses: PROPOSAL_STATUS };
  });

  r.get('/api/proposals/:id', async (ctx) => {
    const p = await db.get('SELECT * FROM station_proposals WHERE id = ?', [ctx.params.id]);
    const staff = isStaff(ctx.user);
    if (!p || (!PUBLIC_STATUSES.includes(p.status) && !staff && p.author_id !== ctx.user?.id)) throw notFound('Инициатива не найдена');
    const votes = await db.count('SELECT COUNT(*) AS n FROM votes WHERE proposal_id = ?', [p.id]);
    const declared = await db.count('SELECT COALESCE(SUM(vehicles_count),0) AS n FROM votes WHERE proposal_id = ?', [p.id]);
    const myVote = ctx.user ? await db.get('SELECT vehicles_count, trips_per_month, created_at FROM votes WHERE proposal_id = ? AND user_id = ?', [p.id, ctx.user.id]) : null;
    const fav = ctx.user ? !!(await db.get("SELECT 1 AS x FROM favorites WHERE user_id = ? AND entity_type = 'proposal' AND entity_id = ?", [ctx.user.id, p.id])) : false;
    const history = await db.all("SELECT from_status, to_status, comment, created_at FROM status_history WHERE entity_type = 'proposal' AND entity_id = ? ORDER BY created_at", [p.id]);
    const dctx = await loadDemandContext(db);
    const pool = poolDemand([p.lat, p.lng], dctx, p.id);
    const stations = await db.all("SELECT lat, lng FROM stations WHERE status = 'operational'");
    const author = p.author_id ? await db.get('SELECT p.full_name, u.account_type FROM users u LEFT JOIN profiles p ON p.user_id = u.id WHERE u.id = ?', [p.author_id]) : null;
    return {
      item: proposalDto(p, {
        votes, declaredVehicles: declared, myVote, favorite: fav, demand: pool, history: history.map((h) => ({ ...h, toLabel: PROPOSAL_STATUS[h.to_status] })),
        nearestOperationalKm: nearestDistanceKm([p.lat, p.lng], stations),
        authorName: author ? (author.account_type === 'person' ? (author.full_name || '').split(' ')[0] : author.full_name) : 'Участник платформы',
        isAuthor: ctx.user?.id === p.author_id,
      }),
    };
  });

  r.post('/api/proposals', async (ctx) => {
    ctx.limiter.hit(`proposal:${ctx.user.id}`, config.production ? 5 : 100, 86400_000);
    const v = validate(ctx.body, PROPOSAL_SCHEMA);
    const { limit, orgId } = await maxVehiclesFor(db, ctx.user.id);
    if (v.authorVehicles > limit) throw new HttpError(422, `Число автомобилей не может превышать размер вашего автопарка (${limit})`);
    // Поиск дублей: рядом (до 3 км) уже есть активная инициатива — предлагаем поддержать её.
    const nearby = (await db.all("SELECT id, title, lat, lng FROM station_proposals WHERE status IN ('pending','published','under_review')"))
      .map((x) => ({ ...x, d: haversine([v.lat, v.lng], [x.lat, x.lng]) })).filter((x) => x.d <= 3).sort((a, b) => a.d - b.d);
    if (nearby.length && !v.force) {
      throw new HttpError(409, `В ${nearby[0].d.toFixed(1).replace('.', ',')} км уже есть инициатива «${nearby[0].title}». Поддержите её или подтвердите создание новой.`, { duplicateOf: nearby[0].id });
    }
    const now = nowIso();
    const status = config.proposalModeration === 'post' ? 'published' : 'pending';
    const id = uuid();
    const title = `${KIND_OPTIONS[v.preferredKind] === 'Не важно' ? 'Газозаправочная станция' : KIND_OPTIONS[v.preferredKind]} — ${v.settlement}${v.highway ? ', ' + v.highway : ''}`.slice(0, 200);
    await db.tx(async (t) => {
      await t.insert('station_proposals', {
        id, author_id: ctx.user.id, organization_id: orgId, title, region: v.region, settlement: v.settlement, highway: v.highway, lat: v.lat, lng: v.lng,
        justification: v.justification, travel_frequency: v.travelFrequency, transport_type: v.transportType, has_alternatives: v.hasAlternatives ? 1 : 0,
        alternatives_note: v.alternativesNote, distance_to_nearest_km: v.distanceToNearestKm, preferred_kind: v.preferredKind, comment: v.comment,
        author_vehicles: v.authorVehicles, author_fuel: v.authorFuel, status, photo_key: PHOTO_BY_KIND[v.preferredKind] || 'highway', created_at: now, updated_at: now,
      });
      await t.insert('votes', { proposal_id: id, user_id: ctx.user.id, organization_id: orgId, vehicles_count: v.authorVehicles, fuel_type: v.authorFuel, created_at: now });
      await t.insert('favorites', { user_id: ctx.user.id, entity_type: 'proposal', entity_id: id, created_at: now });
      await recordStatus(t, ctx, 'proposal', id, null, status, status === 'pending' ? 'Создана пользователем, ожидает модерации' : 'Опубликована');
    });
    return { ok: true, id, status, message: status === 'pending' ? 'Инициатива отправлена на модерацию. Мы уведомим вас о публикации.' : 'Инициатива опубликована' };
  }, { auth: true, verified: true });

  r.post('/api/proposals/:id/vote', async (ctx) => {
    ctx.limiter.hit(`vote:${ctx.user.id}`, 60, 3600_000);
    const p = await db.get('SELECT id, status, author_id FROM station_proposals WHERE id = ?', [ctx.params.id]);
    if (!p) throw notFound('Инициатива не найдена');
    if (!VOTABLE.includes(p.status)) throw conflict('Голосование по этой инициативе закрыто');
    const v = validate(ctx.body, {
      vehiclesCount: { type: 'int', min: 1, max: 10000, default: 1, label: 'Количество автомобилей' },
      tripsPerMonth: { type: 'number', min: 0, max: 1000, label: 'Поездок в месяц' },
      fuelType: { type: 'enum', values: ['cng', 'lng', 'both'], default: 'cng', label: 'Топливо' },
    });
    const { limit, orgId } = await maxVehiclesFor(db, ctx.user.id);
    const vehicles = Math.min(v.vehiclesCount, limit);
    // Уникальность «один пользователь — один голос» обеспечивается первичным ключом (proposal_id, user_id).
    const inserted = await db.run(
      'INSERT INTO votes (proposal_id, user_id, organization_id, vehicles_count, fuel_type, trips_per_month, created_at) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT (proposal_id, user_id) DO NOTHING',
      [p.id, ctx.user.id, orgId, vehicles, v.fuelType, v.tripsPerMonth, nowIso()]);
    const votes = await db.count('SELECT COUNT(*) AS n FROM votes WHERE proposal_id = ?', [p.id]);
    if (!inserted) return { ok: true, alreadyVoted: true, votes, message: 'Вы уже поддержали эту инициативу' };
    await db.run('INSERT INTO favorites (user_id, entity_type, entity_id, created_at) VALUES (?, ?, ?, ?) ON CONFLICT (user_id, entity_type, entity_id) DO NOTHING', [ctx.user.id, 'proposal', p.id, nowIso()]);
    return { ok: true, votes, message: 'Спасибо! Ваш голос учтён.' };
  }, { auth: true, verified: true });

  r.delete('/api/proposals/:id/vote', async (ctx) => {
    const n = await db.run('DELETE FROM votes WHERE proposal_id = ? AND user_id = ?', [ctx.params.id, ctx.user.id]);
    const votes = await db.count('SELECT COUNT(*) AS n FROM votes WHERE proposal_id = ?', [ctx.params.id]);
    return { ok: true, removed: n > 0, votes, message: n ? 'Голос отозван' : 'Голос не найден' };
  }, { auth: true });

  r.get('/api/proposals/:id/comments', async (ctx) => {
    const staff = isStaff(ctx.user);
    const rows = await db.all(
      `SELECT c.id, c.body, c.status, c.created_at, c.user_id, c.is_demo, p.full_name, u.account_type, u.role FROM comments c
       LEFT JOIN users u ON u.id = c.user_id LEFT JOIN profiles p ON p.user_id = c.user_id WHERE c.proposal_id = ? ORDER BY c.created_at`, [ctx.params.id]);
    return {
      items: rows.filter((c) => c.status === 'visible' || staff || c.user_id === ctx.user?.id).map((c) => ({
        id: c.id, body: c.body, status: c.status, createdAt: c.created_at, mine: c.user_id === ctx.user?.id, isDemo: !!c.is_demo,
        author: c.role !== 'user' && c.role ? 'Оператор платформы' : c.account_type === 'person' ? (c.full_name || 'Участник').split(' ')[0] : (c.full_name || 'Участник'),
        staff: c.role === 'operator' || c.role === 'admin',
      })),
    };
  });

  r.post('/api/proposals/:id/comments', async (ctx) => {
    ctx.limiter.hit(`comment-burst:${ctx.user.id}`, 1, 20_000);
    ctx.limiter.hit(`comment-day:${ctx.user.id}`, 30, 86400_000);
    const p = await db.get('SELECT id, status, author_id, title FROM station_proposals WHERE id = ?', [ctx.params.id]);
    if (!p || !PUBLIC_STATUSES.includes(p.status)) throw notFound('Инициатива не найдена');
    const { body } = validate(ctx.body, { body: { type: 'text', required: true, min: 3, max: 1000, label: 'Комментарий' } });
    const links = (body.match(/https?:\/\//gi) || []).length;
    if (links > 2) throw new HttpError(422, 'В комментарии слишком много ссылок');
    const dup = await db.get('SELECT id FROM comments WHERE user_id = ? AND body = ? AND created_at > ?', [ctx.user.id, body, new Date(Date.now() - 86400_000).toISOString()]);
    if (dup) throw conflict('Такой комментарий уже опубликован');
    // Комментарии со ссылками и от новых аккаунтов (младше суток) проходят предварительную модерацию.
    const young = new Date(ctx.user.created_at) > new Date(Date.now() - 86400_000) && !isStaff(ctx.user) && config.production;
    const status = links > 0 || young ? 'pending' : 'visible';
    const id = uuid();
    await db.insert('comments', { id, proposal_id: p.id, user_id: ctx.user.id, body, status, created_at: nowIso() });
    if (status === 'visible' && p.author_id && p.author_id !== ctx.user.id) {
      await notify(db, p.author_id, { kind: 'proposal.comment', title: `Новый комментарий к инициативе «${p.title}»`, link: `/vote/${p.id}` });
    }
    return { ok: true, id, status, message: status === 'pending' ? 'Комментарий отправлен на модерацию' : 'Комментарий опубликован' };
  }, { auth: true, verified: true });

  r.delete('/api/comments/:id', async (ctx) => {
    const c = await db.get('SELECT id, user_id FROM comments WHERE id = ?', [ctx.params.id]);
    if (!c) throw notFound('Комментарий не найден');
    if (c.user_id !== ctx.user.id && !isStaff(ctx.user)) throw forbidden();
    await db.run('DELETE FROM comments WHERE id = ?', [c.id]);
    if (c.user_id !== ctx.user.id) await audit(db, ctx, 'comment.deleted', 'comment', c.id);
    return { ok: true };
  }, { auth: true });
}
