// Личный кабинет: профиль, организация, сотрудники организации, удаление аккаунта и выгрузка своих данных.
import { validate } from '../lib/validate.js';
import { badRequest, conflict, forbidden, HttpError, notFound, serializeCookie } from '../lib/http.js';
import { uuid, verifyPassword } from '../lib/security.js';
import { audit, getMembership, notify, nowIso, requireOrg } from '../services/common.js';
import { SESSION_COOKIE } from '../app.js';

const ORG_SCHEMA = {
  fullName: { type: 'string', min: 3, max: 250, label: 'Полное наименование' },
  shortName: { type: 'string', max: 120, label: 'Краткое наименование' },
  legalForm: { type: 'string', max: 40, label: 'Организационно-правовая форма' },
  region: { type: 'string', max: 120, label: 'Регион' },
  legalAddress: { type: 'string', max: 300, label: 'Юридический адрес' },
  activity: { type: 'string', max: 200, label: 'Вид деятельности' },
  employees: { type: 'int', min: 0, max: 1_000_000, label: 'Количество сотрудников' },
  fleetSize: { type: 'int', min: 0, max: 1_000_000, label: 'Количество транспортных средств' },
  vehicleTypes: { type: 'string', max: 300, label: 'Типы автомобилей' },
  transportDirections: { type: 'text', max: 1000, label: 'Основные направления перевозок' },
  tripFrequency: { type: 'string', max: 200, label: 'Частота коммерческих поездок' },
  estMonthlyGas: { type: 'number', min: 0, max: 1e9, label: 'Предполагаемый объём потребления газа' },
  estMonthlyGasUnit: { type: 'enum', values: ['м³', 'кг'], default: 'м³', label: 'Единица объёма' },
  contactPerson: { type: 'string', max: 120, label: 'Контактное лицо' },
  contactPosition: { type: 'string', max: 120, label: 'Должность' },
  contactEmail: { type: 'email', label: 'E-mail организации' },
  contactPhone: { type: 'phone', label: 'Телефон организации' },
};

export function orgDto(o) {
  if (!o) return null;
  return {
    id: o.id, type: o.org_type, fullName: o.full_name, shortName: o.short_name, legalForm: o.legal_form, inn: o.inn, region: o.region,
    legalAddress: o.legal_address, activity: o.activity, employees: o.employees, fleetSize: o.fleet_size, vehicleTypes: o.vehicle_types,
    transportDirections: o.transport_directions, tripFrequency: o.trip_frequency, estMonthlyGas: o.est_monthly_gas, estMonthlyGasUnit: o.est_monthly_gas_unit,
    contactPerson: o.contact_person, contactPosition: o.contact_position, contactEmail: o.contact_email, contactPhone: o.contact_phone,
    verificationStatus: o.verification_status, verificationNote: o.verification_note, isDemo: !!o.is_demo, createdAt: o.created_at,
  };
}

export default function register(r, { db }) {
  r.get('/api/me', async (ctx) => {
    const u = await db.get('SELECT id, email, role, account_type, email_verified_at, created_at, is_demo FROM users WHERE id = ?', [ctx.user.id]);
    const p = await db.get('SELECT * FROM profiles WHERE user_id = ?', [ctx.user.id]);
    const m = await getMembership(db, ctx.user.id);
    const org = m ? await db.get('SELECT * FROM organizations WHERE id = ?', [m.organization_id]) : null;
    const counts = {
      vehicles: await db.count('SELECT COUNT(*) AS n FROM vehicles WHERE owner_user_id = ? AND organization_id IS NULL', [ctx.user.id]),
      fleet: m ? await db.count('SELECT COALESCE(SUM(quantity),0) AS n FROM vehicles WHERE organization_id = ?', [m.organization_id]) : 0,
      routes: m ? await db.count('SELECT COUNT(*) AS n FROM user_routes WHERE organization_id = ?', [m.organization_id]) : await db.count('SELECT COUNT(*) AS n FROM user_routes WHERE owner_user_id = ?', [ctx.user.id]),
      votes: await db.count('SELECT COUNT(*) AS n FROM votes WHERE user_id = ?', [ctx.user.id]),
      proposals: await db.count('SELECT COUNT(*) AS n FROM station_proposals WHERE author_id = ?', [ctx.user.id]),
      offers: m ? await db.count('SELECT COUNT(*) AS n FROM commercial_offers WHERE organization_id = ?', [m.organization_id]) : 0,
      favorites: await db.count('SELECT COUNT(*) AS n FROM favorites WHERE user_id = ?', [ctx.user.id]),
    };
    return {
      user: { id: u.id, email: u.email, role: u.role, accountType: u.account_type, emailVerified: !!u.email_verified_at, createdAt: u.created_at, isDemo: !!u.is_demo },
      profile: p && { fullName: p.full_name, region: p.region, city: p.city, phone: p.phone, contactNote: p.contact_note, preferredFuel: p.preferred_fuel, position: p.position, notifyEmail: !!p.notify_email },
      organization: orgDto(org),
      memberRole: m?.member_role || null,
      counts,
    };
  }, { auth: true });

  r.put('/api/me/profile', async (ctx) => {
    const v = validate(ctx.body, {
      fullName: { type: 'string', required: true, min: 2, max: 120, label: 'Имя' },
      region: { type: 'string', required: true, max: 120, label: 'Регион' },
      city: { type: 'string', max: 120, label: 'Город' },
      phone: { type: 'phone', label: 'Телефон' },
      contactNote: { type: 'string', max: 200, label: 'Дополнительные контакты' },
      preferredFuel: { type: 'enum', values: ['cng', 'lng', 'both', 'undecided'], default: 'undecided', label: 'Предпочитаемое топливо' },
      position: { type: 'string', max: 120, label: 'Должность' },
      notifyEmail: { type: 'bool', label: 'Уведомления' },
    });
    await db.run(
      'UPDATE profiles SET full_name = ?, region = ?, city = ?, phone = ?, contact_note = ?, preferred_fuel = ?, position = ?, notify_email = ?, updated_at = ? WHERE user_id = ?',
      [v.fullName, v.region, v.city, v.phone, v.contactNote, v.preferredFuel, v.position, v.notifyEmail ? 1 : 0, nowIso(), ctx.user.id]);
    return { ok: true, message: 'Профиль сохранён' };
  }, { auth: true });

  r.put('/api/me/organization', async (ctx) => {
    const m = await requireOrg(ctx, 'manager');
    const v = validate(ctx.body, ORG_SCHEMA);
    const before = await db.get('SELECT * FROM organizations WHERE id = ?', [m.organization_id]);
    const patch = {
      full_name: v.fullName || before.full_name, short_name: v.shortName, legal_form: v.legalForm, region: v.region, legal_address: v.legalAddress,
      activity: v.activity, employees: v.employees, fleet_size: v.fleetSize, vehicle_types: v.vehicleTypes, transport_directions: v.transportDirections,
      trip_frequency: v.tripFrequency, est_monthly_gas: v.estMonthlyGas, est_monthly_gas_unit: v.estMonthlyGasUnit, contact_person: v.contactPerson,
      contact_position: v.contactPosition, contact_email: v.contactEmail, contact_phone: v.contactPhone, updated_at: nowIso(),
    };
    // Существенные реквизиты меняются — организация повторно проходит проверку.
    if (before.verification_status === 'verified' && (patch.full_name !== before.full_name)) {
      patch.verification_status = 'pending';
      patch.verification_note = 'Изменено наименование — требуется повторная проверка';
    }
    await db.update('organizations', m.organization_id, patch);
    await audit(db, ctx, 'org.updated', 'organization', m.organization_id);
    return { ok: true, message: 'Данные организации сохранены' };
  }, { auth: true });

  r.get('/api/me/organization/members', async (ctx) => {
    const m = await requireOrg(ctx, 'viewer');
    const members = await db.all(
      `SELECT m.user_id, m.member_role, m.created_at, u.email, p.full_name, p.position FROM organization_members m
       JOIN users u ON u.id = m.user_id LEFT JOIN profiles p ON p.user_id = m.user_id WHERE m.organization_id = ? ORDER BY m.created_at`, [m.organization_id]);
    const invites = m.member_role === 'owner'
      ? await db.all('SELECT id, email, member_role, created_at, expires_at FROM organization_invites WHERE organization_id = ? AND accepted_at IS NULL AND expires_at > ? ORDER BY created_at DESC', [m.organization_id, nowIso()])
      : [];
    return { myRole: m.member_role, members: members.map((x) => ({ userId: x.user_id, role: x.member_role, email: x.email, name: x.full_name, position: x.position, since: x.created_at, me: x.user_id === ctx.user.id })), invites };
  }, { auth: true });

  r.post('/api/me/organization/members', async (ctx) => {
    const m = await requireOrg(ctx, 'owner');
    ctx.limiter.hit(`invite:${ctx.user.id}`, 20, 3600_000);
    const v = validate(ctx.body, {
      email: { type: 'email', required: true, label: 'E-mail сотрудника' },
      role: { type: 'enum', values: ['manager', 'viewer'], required: true, label: 'Права доступа' },
    });
    const user = await db.get('SELECT id, account_type FROM users WHERE email = ?', [v.email]);
    const now = nowIso();
    if (user) {
      const already = await getMembership(db, user.id);
      if (already) throw conflict('Пользователь уже состоит в организации');
      if (!['company', 'ip'].includes(user.account_type)) throw conflict('Пользователь зарегистрирован как физическое лицо. Попросите его зарегистрировать отдельный рабочий e-mail.');
      await db.insert('organization_members', { organization_id: m.organization_id, user_id: user.id, member_role: v.role, created_at: now });
      await notify(db, user.id, { kind: 'org.member_added', title: `Вас добавили в организацию «${m.short_name || m.full_name}»`, link: '/account/company' });
      await audit(db, ctx, 'org.member_added', 'organization', m.organization_id, { email: v.email, role: v.role });
      return { ok: true, message: 'Сотрудник добавлен в организацию' };
    }
    await db.insert('organization_invites', { id: uuid(), organization_id: m.organization_id, email: v.email, member_role: v.role, created_by: ctx.user.id, created_at: now, expires_at: new Date(Date.now() + 14 * 86400_000).toISOString() });
    await ctx.mailer.send({
      to: v.email,
      subject: 'GAS CONNECT: приглашение в организацию',
      text: `Вас пригласили в организацию «${m.short_name || m.full_name}» на платформе GAS CONNECT.\n\nЗарегистрируйтесь по адресу ${ctx.config.appUrl}/register?invite=1 с этим e-mail и выберите «Я сотрудник приглашённой организации». Приглашение действует 14 дней.`,
    });
    await audit(db, ctx, 'org.invite_sent', 'organization', m.organization_id, { email: v.email, role: v.role });
    return { ok: true, message: 'Приглашение отправлено. Сотрудник появится в списке после регистрации.' };
  }, { auth: true });

  r.put('/api/me/organization/members/:userId', async (ctx) => {
    const m = await requireOrg(ctx, 'owner');
    const v = validate(ctx.body, { role: { type: 'enum', values: ['manager', 'viewer'], required: true, label: 'Права' } });
    if (ctx.params.userId === ctx.user.id) throw badRequest('Нельзя изменить собственную роль владельца');
    const n = await db.run('UPDATE organization_members SET member_role = ? WHERE organization_id = ? AND user_id = ? AND member_role <> ?', [v.role, m.organization_id, ctx.params.userId, 'owner']);
    if (!n) throw notFound('Сотрудник не найден');
    await audit(db, ctx, 'org.member_role', 'organization', m.organization_id, { userId: ctx.params.userId, role: v.role });
    return { ok: true };
  }, { auth: true });

  r.delete('/api/me/organization/members/:userId', async (ctx) => {
    const m = await requireOrg(ctx, 'owner');
    if (ctx.params.userId === ctx.user.id) throw badRequest('Владелец не может удалить себя из организации');
    const n = await db.run('DELETE FROM organization_members WHERE organization_id = ? AND user_id = ? AND member_role <> ?', [m.organization_id, ctx.params.userId, 'owner']);
    if (!n) throw notFound('Сотрудник не найден');
    await db.run('DELETE FROM sessions WHERE user_id = ?', [ctx.params.userId]);
    await audit(db, ctx, 'org.member_removed', 'organization', m.organization_id, { userId: ctx.params.userId });
    return { ok: true };
  }, { auth: true });

  r.delete('/api/me/organization/invites/:id', async (ctx) => {
    const m = await requireOrg(ctx, 'owner');
    await db.run('DELETE FROM organization_invites WHERE id = ? AND organization_id = ?', [ctx.params.id, m.organization_id]);
    return { ok: true };
  }, { auth: true });

  // Выгрузка персональных данных пользователя (право субъекта на доступ к своим данным).
  r.get('/api/me/export', async (ctx) => {
    ctx.limiter.hit(`export-me:${ctx.user.id}`, 5, 3600_000);
    const id = ctx.user.id;
    return {
      exportedAt: nowIso(),
      user: await db.get('SELECT id, email, account_type, created_at, email_verified_at, last_login_at FROM users WHERE id = ?', [id]),
      profile: await db.get('SELECT * FROM profiles WHERE user_id = ?', [id]),
      consents: await db.all('SELECT document, version, accepted_at FROM consents WHERE user_id = ?', [id]),
      vehicles: await db.all('SELECT * FROM vehicles WHERE owner_user_id = ?', [id]),
      routes: await db.all('SELECT * FROM user_routes WHERE owner_user_id = ?', [id]),
      votes: await db.all('SELECT proposal_id, vehicles_count, trips_per_month, created_at FROM votes WHERE user_id = ?', [id]),
      proposals: await db.all('SELECT * FROM station_proposals WHERE author_id = ?', [id]),
      comments: await db.all('SELECT proposal_id, body, created_at FROM comments WHERE user_id = ?', [id]),
      favorites: await db.all('SELECT entity_type, entity_id, created_at FROM favorites WHERE user_id = ?', [id]),
    };
  }, { auth: true });

  // Удаление аккаунта (отзыв согласия на обработку персональных данных).
  r.post('/api/me/delete', async (ctx) => {
    const user = await db.get('SELECT password_hash FROM users WHERE id = ?', [ctx.user.id]);
    if (!(await verifyPassword(String(ctx.body.password || ''), user.password_hash))) throw new HttpError(422, 'Пароль указан неверно', { fields: { password: 'Неверный пароль' } });
    if (ctx.user.role !== 'user') throw forbidden('Учётные записи сотрудников удаляет администратор');
    const m = await getMembership(db, ctx.user.id);
    if (m?.member_role === 'owner') {
      const others = await db.count('SELECT COUNT(*) AS n FROM organization_members WHERE organization_id = ? AND user_id <> ?', [m.organization_id, ctx.user.id]);
      if (others > 0) throw conflict('Вы владелец аккаунта организации, в которой есть другие сотрудники. Передайте права или удалите сотрудников.');
    }
    await db.tx(async (t) => {
      // Голоса, маршруты, автомобили и избранное удаляются каскадно вместе с аккаунтом.
      if (m?.member_role === 'owner') await t.run('DELETE FROM organizations WHERE id = ?', [m.organization_id]);
      await t.run('DELETE FROM users WHERE id = ?', [ctx.user.id]);
    });
    await audit(db, { ...ctx, user: null }, 'user.self_deleted', 'user', ctx.user.id);
    ctx.setCookie(serializeCookie(SESSION_COOKIE, '', { httpOnly: true, secure: ctx.config.cookieSecure, maxAge: 0 }));
    return { ok: true, message: 'Аккаунт и связанные персональные данные удалены' };
  }, { auth: true });
}
