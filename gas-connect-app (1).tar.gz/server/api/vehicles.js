// Автомобили физических лиц и автопарк организаций.
import { validate } from '../lib/validate.js';
import { notFound } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { nowIso, requireOrg, getMembership, ORG_ROLE_RANK } from '../services/common.js';
import { forbidden } from '../lib/http.js';
import { vehicleMetrics, FUELS } from '../../public/assets/js/shared/calc.js';

export const VEHICLE_TYPES = ['Легковой', 'Лёгкий коммерческий', 'Грузовой (до 12 т)', 'Магистральный тягач', 'Автобус', 'Коммунальная / спецтехника', 'Другое'];
export const EQUIPMENT_TYPES = ['КПГ: баллоны тип 1 (сталь)', 'КПГ: баллоны тип 2 (металлокомпозит)', 'КПГ: баллоны тип 3', 'КПГ: баллоны тип 4 (композит)', 'СПГ: криогенный бак', 'Заводская газовая версия', 'Не установлено'];

const SCHEMA = {
  make: { type: 'string', required: true, max: 60, label: 'Марка' },
  model: { type: 'string', required: true, max: 80, label: 'Модель' },
  year: { type: 'int', min: 1960, max: new Date().getFullYear() + 1, label: 'Год выпуска' },
  vehicleType: { type: 'enum', values: VEHICLE_TYPES, required: true, label: 'Тип транспортного средства' },
  fuelType: { type: 'enum', values: Object.keys(FUELS), required: true, label: 'Топливо' },
  equipmentType: { type: 'enum', values: EQUIPMENT_TYPES, label: 'Тип газобаллонного оборудования' },
  cylinderCount: { type: 'int', min: 0, max: 40, label: 'Количество баллонов' },
  cylinderVolumeL: { type: 'number', min: 0, max: 2000, label: 'Объём баллона (геометрический), л' },
  workingPressureBar: { type: 'number', min: 50, max: 350, default: 200, label: 'Рабочее давление, бар' },
  lngTankL: { type: 'number', min: 0, max: 3000, label: 'Объём криобака, л' },
  stockIsManual: { type: 'bool', label: 'Запас указан вручную' },
  gasStockM3: { type: 'number', min: 0, max: 5000, label: 'Запас газа, м³' },
  gasStockKg: { type: 'number', min: 0, max: 5000, label: 'Запас СПГ, кг' },
  consumptionValue: { type: 'number', min: 0, max: 300, label: 'Средний расход' },
  monthlyMileageKm: { type: 'number', min: 0, max: 50000, label: 'Среднемесячный пробег, км' },
  payloadT: { type: 'number', min: 0, max: 100, label: 'Грузоподъёмность, т' },
  quantity: { type: 'int', min: 1, max: 10000, default: 1, label: 'Количество одинаковых ТС' },
  convertible: { type: 'bool', label: 'Можно перевести на метан' },
  note: { type: 'string', max: 300, label: 'Примечание' },
};

export function toRow(v) {
  const fuel = FUELS[v.fuelType];
  const row = {
    make: v.make, model: v.model, year: v.year, vehicle_type: v.vehicleType, fuel_type: v.fuelType, equipment_type: v.equipmentType,
    cylinder_count: fuel.methane === 'cng' ? v.cylinderCount : null,
    cylinder_volume_l: fuel.methane === 'cng' ? v.cylinderVolumeL : null,
    working_pressure_bar: fuel.methane === 'cng' ? v.workingPressureBar : null,
    lng_tank_l: fuel.methane === 'lng' ? v.lngTankL : null,
    stock_is_manual: v.stockIsManual ? 1 : 0,
    gas_stock_m3: fuel.methane === 'cng' && v.stockIsManual ? v.gasStockM3 : null,
    gas_stock_kg: fuel.methane === 'lng' && v.stockIsManual ? v.gasStockKg : null,
    consumption_value: v.consumptionValue, consumption_unit: fuel.consUnit,
    monthly_mileage_km: v.monthlyMileageKm, payload_t: v.payloadT, quantity: v.quantity || 1, convertible: v.convertible ? 1 : 0, note: v.note,
  };
  // Расчётные величины всегда вычисляются на сервере.
  const m = vehicleMetrics(row);
  if (fuel.methane === 'cng') row.gas_stock_m3 = m.stockValue;
  if (fuel.methane === 'lng') row.gas_stock_kg = m.stockValue;
  row.range_km = m.rangeKm;
  return row;
}

export function vehicleDto(r) {
  const m = vehicleMetrics(r);
  return {
    id: r.id, make: r.make, model: r.model, year: r.year, vehicleType: r.vehicle_type, fuelType: r.fuel_type, fuelLabel: FUELS[r.fuel_type]?.short,
    equipmentType: r.equipment_type, cylinderCount: r.cylinder_count, cylinderVolumeL: r.cylinder_volume_l, workingPressureBar: r.working_pressure_bar,
    lngTankL: r.lng_tank_l, stockIsManual: !!r.stock_is_manual, gasStockM3: r.gas_stock_m3, gasStockKg: r.gas_stock_kg,
    consumptionValue: r.consumption_value, consumptionUnit: r.consumption_unit, rangeKm: r.range_km, monthlyMileageKm: r.monthly_mileage_km,
    payloadT: r.payload_t, quantity: r.quantity, convertible: !!r.convertible, note: r.note, organizationId: r.organization_id,
    metrics: m, isDemo: !!r.is_demo, updatedAt: r.updated_at,
  };
}

async function scopeFor(ctx, scope, write) {
  if (scope === 'fleet') {
    const m = await requireOrg(ctx, write ? 'manager' : 'viewer');
    return { where: 'organization_id = ?', params: [m.organization_id], owner: { owner_user_id: ctx.user.id, organization_id: m.organization_id } };
  }
  return { where: 'owner_user_id = ? AND organization_id IS NULL', params: [ctx.user.id], owner: { owner_user_id: ctx.user.id, organization_id: null } };
}

export function fleetSummary(rows) {
  const s = { cards: rows.length, vehicles: 0, byFuel: {}, byType: {}, convertible: 0, monthlyKm: 0, demandM3: 0, demandKg: 0, avgRangeKm: null };
  let rangeSum = 0, rangeN = 0;
  for (const r of rows) {
    const q = r.quantity || 1;
    s.vehicles += q;
    s.byFuel[r.fuel_type] = (s.byFuel[r.fuel_type] || 0) + q;
    s.byType[r.vehicle_type] = (s.byType[r.vehicle_type] || 0) + q;
    if (r.convertible) s.convertible += q;
    s.monthlyKm += (r.monthly_mileage_km || 0) * q;
    const m = vehicleMetrics(r);
    if (m.monthlyDemand) { if (m.methane === 'cng') s.demandM3 += m.monthlyDemand; else if (m.methane === 'lng') s.demandKg += m.monthlyDemand; }
    if (m.rangeKm) { rangeSum += m.rangeKm * q; rangeN += q; }
  }
  if (rangeN) s.avgRangeKm = Math.round(rangeSum / rangeN);
  return s;
}

export default function register(r, { db }) {
  r.get('/api/vehicles', async (ctx) => {
    const scope = ctx.query.scope === 'fleet' ? 'fleet' : 'personal';
    const sc = await scopeFor(ctx, scope, false);
    const rows = await db.all(`SELECT * FROM vehicles WHERE ${sc.where} ORDER BY created_at`, sc.params);
    return { items: rows.map(vehicleDto), summary: fleetSummary(rows) };
  }, { auth: true });

  r.post('/api/vehicles', async (ctx) => {
    ctx.limiter.hit(`vehicle-create:${ctx.user.id}`, 120, 3600_000);
    const scope = ctx.body.scope === 'fleet' ? 'fleet' : 'personal';
    const sc = await scopeFor(ctx, scope, true);
    const count = await db.count(`SELECT COUNT(*) AS n FROM vehicles WHERE ${sc.where}`, sc.params);
    if (scope === 'personal' && count >= 20) throw forbidden('Для физического лица можно добавить не более 20 автомобилей');
    if (count >= 2000) throw forbidden('Достигнут предел количества карточек автопарка');
    const v = validate(ctx.body, SCHEMA);
    if (scope === 'personal') v.quantity = 1;
    const now = nowIso();
    const row = { id: uuid(), ...sc.owner, ...toRow(v), created_at: now, updated_at: now };
    await db.insert('vehicles', row);
    return { ok: true, item: vehicleDto(row) };
  }, { auth: true });

  r.put('/api/vehicles/:id', async (ctx) => {
    const row = await db.get('SELECT * FROM vehicles WHERE id = ?', [ctx.params.id]);
    if (!row) throw notFound('Автомобиль не найден');
    await assertVehicleWrite(ctx, row);
    const v = validate(ctx.body, SCHEMA);
    if (!row.organization_id) v.quantity = 1;
    const patch = { ...toRow(v), updated_at: nowIso() };
    await db.update('vehicles', row.id, patch);
    return { ok: true, item: vehicleDto({ ...row, ...patch }) };
  }, { auth: true });

  r.delete('/api/vehicles/:id', async (ctx) => {
    const row = await db.get('SELECT * FROM vehicles WHERE id = ?', [ctx.params.id]);
    if (!row) throw notFound('Автомобиль не найден');
    await assertVehicleWrite(ctx, row);
    await db.run('DELETE FROM vehicles WHERE id = ?', [row.id]);
    return { ok: true };
  }, { auth: true });

  async function assertVehicleWrite(ctx, row) {
    if (row.organization_id) {
      const m = await getMembership(db, ctx.user.id);
      if (!m || m.organization_id !== row.organization_id) throw notFound('Автомобиль не найден');
      if (ORG_ROLE_RANK[m.member_role] < ORG_ROLE_RANK.manager) throw forbidden('Ваша роль в организации позволяет только просмотр');
    } else if (row.owner_user_id !== ctx.user.id) throw notFound('Автомобиль не найден');
  }
}
