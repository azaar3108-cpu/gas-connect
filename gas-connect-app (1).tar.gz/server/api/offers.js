// Коммерческие предложения ИП и юридических лиц о сотрудничестве по поставке газомоторного топлива.
// Важно: это заявки и предложения, а не юридически обязывающие договоры.
import fs from 'node:fs';
import path from 'node:path';
import { validate } from '../lib/validate.js';
import { HttpError, notFound, forbidden, conflict } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { audit, getMembership, isStaff, notify, nowIso, parseJson, recordStatus, requireOrg, ORG_ROLE_RANK } from '../services/common.js';

export const OFFER_STATUS = {
  draft: 'Черновик', submitted: 'Отправлено', in_review: 'На рассмотрении', needs_info: 'Требуется уточнение',
  preliminarily_approved: 'Предварительно согласовано', rejected: 'Отклонено',
};
export const CONTRACT_STATUS = { preliminary: 'Предварительная договорённость', signed_offline: 'Договор подписан вне платформы', terminated: 'Прекращён' };
const EDITABLE = ['draft', 'needs_info'];

const S = (label, max = 300) => ({ type: 'string', max, label });
const T = (label, max = 2000) => ({ type: 'text', max, label });
const N = (label, max = 1e10) => ({ type: 'number', min: 0, max, label });

export const OFFER_SCHEMA = {
  // Информация об организации (снимок на момент подачи)
  orgName: S('Наименование', 250), orgInn: S('ИНН', 12), orgRegion: S('Регион', 120), representative: S('Представитель', 120),
  contactEmail: { type: 'email', label: 'E-mail для связи' }, contactPhone: { type: 'phone', label: 'Телефон для связи' }, activity: S('Вид деятельности', 200),
  // Транспортный парк
  vehiclesTotal: { type: 'int', min: 0, max: 1_000_000, label: 'Количество автомобилей' }, makesModels: T('Марки и модели', 1000), fuelTypesNow: S('Используемые виды топлива', 200),
  avgMileageKm: N('Средний пробег, км/мес', 100000), vehiclesConvertible: { type: 'int', min: 0, max: 1_000_000, label: 'Можно перевести на метан' }, conversionTimeline: S('Планируемые сроки перевода', 200),
  // Маршруты перевозок
  mainDirections: T('Основные транспортные направления'), tripFrequency: S('Частота перевозок', 200), avgDistanceKm: N('Среднее расстояние, км', 20000),
  alternativePaths: T('Альтернативные пути'), seasonalLimits: T('Сезонные ограничения'), weightLimits: T('Ограничения по массе и габаритам'),
  unavailableSections: T('Недоступные участки дорог'), mandatoryStops: T('Места обязательных остановок'), underservedAreas: T('Территории с недостаточной заправочной инфраструктурой'),
  // Потребность в топливе
  fuelType: { type: 'enum', values: ['cng', 'lng'], default: 'cng', label: 'Вид топлива' },
  volumeUnit: { type: 'enum', values: ['м³', 'кг', 'т'], default: 'м³', label: 'Единица объёма' },
  monthlyVolume: N('Среднемесячный объём'), annualVolume: N('Предполагаемый годовой объём'),
  termMonths: { type: 'int', min: 1, max: 240, label: 'Срок сотрудничества, мес.' }, minGuaranteedVolume: N('Минимальный гарантируемый объём (в месяц)'),
  deliveryTerms: T('Предпочтительные условия поставки', 1500),
  // Дополнительно
  restrictions: T('Возможные ограничения'), locationWishes: T('Пожелания к расположению заправок'), comments: T('Комментарии'), specialRequirements: T('Особые требования'),
};
const REQUIRED_ON_SUBMIT = ['orgName', 'representative', 'contactEmail', 'vehiclesTotal', 'mainDirections', 'tripFrequency', 'fuelType', 'monthlyVolume', 'termMonths'];
const DETAIL_KEYS = Object.keys(OFFER_SCHEMA).filter((k) => !['fuelType', 'volumeUnit', 'monthlyVolume', 'annualVolume', 'termMonths', 'minGuaranteedVolume', 'vehiclesTotal', 'vehiclesConvertible'].includes(k));

const ALLOWED_DOCS = {
  'application/pdf': { ext: '.pdf', magic: (b) => b.subarray(0, 4).toString('latin1') === '%PDF' },
  'image/png': { ext: '.png', magic: (b) => b[0] === 0x89 && b[1] === 0x50 },
  'image/jpeg': { ext: '.jpg', magic: (b) => b[0] === 0xff && b[1] === 0xd8 },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { ext: '.docx', magic: (b) => b[0] === 0x50 && b[1] === 0x4b },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { ext: '.xlsx', magic: (b) => b[0] === 0x50 && b[1] === 0x4b },
};

function normalizeVolume(v) {
  if (v.fuelType === 'cng') v.volumeUnit = 'м³';
  else if (v.volumeUnit === 'м³') v.volumeUnit = 'кг';
  if (v.monthlyVolume && !v.annualVolume) v.annualVolume = Math.round(v.monthlyVolume * 12);
  return v;
}

function toRow(v) {
  const details = Object.fromEntries(DETAIL_KEYS.map((k) => [k, v[k] ?? null]));
  const unitLabel = v.volumeUnit || 'м³';
  return {
    title: `Поставка ${v.fuelType === 'lng' ? 'СПГ' : 'КПГ'}${v.orgRegion ? ' — ' + v.orgRegion : ''}${v.monthlyVolume ? `, ${Math.round(v.monthlyVolume).toLocaleString('ru-RU')} ${unitLabel}/мес.` : ''}`.slice(0, 200),
    fuel_type: v.fuelType, volume_unit: unitLabel, monthly_volume: v.monthlyVolume, annual_volume: v.annualVolume, min_guaranteed_volume: v.minGuaranteedVolume,
    term_months: v.termMonths, vehicles_total: v.vehiclesTotal, vehicles_convertible: v.vehiclesConvertible, main_region: v.orgRegion, details: JSON.stringify(details),
  };
}

export function offerDto(o, extra = {}) {
  const d = parseJson(o.details, {});
  return {
    id: o.id, organizationId: o.organization_id, status: o.status, statusLabel: OFFER_STATUS[o.status], title: o.title,
    fuelType: o.fuel_type, volumeUnit: o.volume_unit, monthlyVolume: o.monthly_volume, annualVolume: o.annual_volume, minGuaranteedVolume: o.min_guaranteed_volume,
    termMonths: o.term_months, vehiclesTotal: o.vehicles_total, vehiclesConvertible: o.vehicles_convertible, mainRegion: o.main_region,
    ...d, submittedAt: o.submitted_at, createdAt: o.created_at, updatedAt: o.updated_at, isDemo: !!o.is_demo, editable: EDITABLE.includes(o.status), ...extra,
  };
}

export async function offerFull(db, o, viewerIsStaff) {
  const history = await db.all("SELECT from_status, to_status, comment, created_at FROM status_history WHERE entity_type = 'offer' AND entity_id = ? ORDER BY created_at", [o.id]);
  const messages = await db.all(
    `SELECT m.id, m.author_side, m.body, m.created_at, p.full_name FROM offer_messages m LEFT JOIN profiles p ON p.user_id = m.author_id WHERE m.offer_id = ? ORDER BY m.created_at`, [o.id]);
  const documents = await db.all('SELECT id, original_name, mime, size_bytes, created_at FROM offer_documents WHERE offer_id = ? ORDER BY created_at', [o.id]);
  const org = await db.get('SELECT id, full_name, short_name, inn, region, verification_status, org_type FROM organizations WHERE id = ?', [o.organization_id]);
  return offerDto(o, {
    history: history.map((h) => ({ from: h.from_status, to: h.to_status, toLabel: OFFER_STATUS[h.to_status], comment: h.comment, at: h.created_at })),
    messages: messages.map((m) => ({ id: m.id, side: m.author_side, body: m.body, at: m.created_at, author: m.author_side === 'operator' ? 'Оператор платформы' : (m.full_name || 'Представитель организации') + (viewerIsStaff ? '' : '') })),
    documents: documents.map((d) => ({ id: d.id, name: d.original_name, mime: d.mime, size: d.size_bytes, at: d.created_at })),
    organization: org && { id: org.id, name: org.short_name || org.full_name, inn: org.inn, region: org.region, verification: org.verification_status, type: org.org_type },
  });
}

async function staffIds(db) {
  return (await db.all("SELECT id FROM users WHERE role IN ('operator','admin') AND status = 'active'")).map((x) => x.id);
}

export default function register(r, { db, config }) {
  async function loadForMember(ctx, minRole = 'viewer') {
    const o = await db.get('SELECT * FROM commercial_offers WHERE id = ?', [ctx.params.id]);
    if (!o) throw notFound('Предложение не найдено');
    if (isStaff(ctx.user) && minRole === 'viewer') return { o, m: null };
    const m = await getMembership(db, ctx.user.id);
    if (!m || m.organization_id !== o.organization_id) throw notFound('Предложение не найдено');
    if (ORG_ROLE_RANK[m.member_role] < ORG_ROLE_RANK[minRole]) throw forbidden('Ваша роль в организации позволяет только просмотр');
    return { o, m };
  }

  r.get('/api/offers', async (ctx) => {
    const m = await requireOrg(ctx, 'viewer');
    const rows = await db.all('SELECT * FROM commercial_offers WHERE organization_id = ? ORDER BY updated_at DESC', [m.organization_id]);
    return { items: rows.map((o) => offerDto(o)), statuses: OFFER_STATUS };
  }, { auth: true });

  r.get('/api/offers/prefill', async (ctx) => {
    const m = await requireOrg(ctx, 'viewer');
    const org = await db.get('SELECT * FROM organizations WHERE id = ?', [m.organization_id]);
    const prof = await db.get('SELECT full_name, phone FROM profiles WHERE user_id = ?', [ctx.user.id]);
    const fleet = await db.all('SELECT make, model, fuel_type, quantity, monthly_mileage_km, convertible FROM vehicles WHERE organization_id = ?', [m.organization_id]);
    const total = fleet.reduce((a, v) => a + (v.quantity || 1), 0);
    const conv = fleet.filter((v) => v.convertible || ['cng', 'lng', 'bifuel_cng', 'gasdiesel_cng'].includes(v.fuel_type)).reduce((a, v) => a + (v.quantity || 1), 0);
    const km = total ? Math.round(fleet.reduce((a, v) => a + (v.monthly_mileage_km || 0) * (v.quantity || 1), 0) / total) : null;
    return {
      orgName: org.full_name, orgInn: org.inn, orgRegion: org.region, representative: prof?.full_name, contactEmail: org.contact_email || ctx.user.email,
      contactPhone: org.contact_phone || prof?.phone, activity: org.activity, vehiclesTotal: total || org.fleet_size, vehiclesConvertible: conv || null, avgMileageKm: km,
      makesModels: [...new Set(fleet.map((v) => `${v.make} ${v.model}`))].join(', '), mainDirections: org.transport_directions, tripFrequency: org.trip_frequency,
      orgVerification: org.verification_status,
    };
  }, { auth: true });

  r.post('/api/offers', async (ctx) => {
    const m = await requireOrg(ctx, 'manager');
    ctx.limiter.hit(`offer-create:${m.organization_id}`, 30, 86400_000);
    const v = normalizeVolume(validate(ctx.body, OFFER_SCHEMA));
    const now = nowIso();
    const id = uuid();
    await db.insert('commercial_offers', { id, organization_id: m.organization_id, created_by: ctx.user.id, status: 'draft', ...toRow(v), created_at: now, updated_at: now });
    await recordStatus(db, ctx, 'offer', id, null, 'draft', 'Черновик создан');
    return { ok: true, id };
  }, { auth: true });

  r.get('/api/offers/:id', async (ctx) => {
    const { o } = await loadForMember(ctx, 'viewer');
    return { item: await offerFull(db, o, isStaff(ctx.user)) };
  }, { auth: true });

  r.put('/api/offers/:id', async (ctx) => {
    const { o } = await loadForMember(ctx, 'manager');
    if (!EDITABLE.includes(o.status)) throw conflict('Предложение можно редактировать только в статусах «Черновик» и «Требуется уточнение»');
    const v = normalizeVolume(validate(ctx.body, OFFER_SCHEMA));
    await db.update('commercial_offers', o.id, { ...toRow(v), updated_at: nowIso() });
    return { ok: true };
  }, { auth: true });

  r.delete('/api/offers/:id', async (ctx) => {
    const { o } = await loadForMember(ctx, 'manager');
    if (o.status !== 'draft') throw conflict('Удалить можно только черновик');
    await db.run('DELETE FROM commercial_offers WHERE id = ?', [o.id]);
    return { ok: true };
  }, { auth: true });

  r.post('/api/offers/:id/submit', async (ctx) => {
    const { o, m } = await loadForMember(ctx, 'manager');
    if (!EDITABLE.includes(o.status)) throw conflict('Предложение уже отправлено');
    const data = { ...offerDto(o) };
    const missing = REQUIRED_ON_SUBMIT.filter((k) => data[k] === null || data[k] === undefined || data[k] === '');
    if (missing.length) {
      throw new HttpError(422, `Заполните обязательные поля: ${missing.map((k) => OFFER_SCHEMA[k].label).join(', ')}`, { fields: Object.fromEntries(missing.map((k) => [k, 'Обязательно для отправки'])) });
    }
    const now = nowIso();
    await db.run('UPDATE commercial_offers SET status = ?, submitted_at = ?, updated_at = ? WHERE id = ?', ['submitted', now, now, o.id]);
    await recordStatus(db, ctx, 'offer', o.id, o.status, 'submitted', o.status === 'needs_info' ? 'Уточнения отправлены' : 'Предложение отправлено оператору');
    await notify(db, await staffIds(db), { kind: 'op.offer_submitted', title: `Новое коммерческое предложение: ${m.short_name || m.full_name}`, body: o.title, link: `/operator/offers/${o.id}` });
    return { ok: true, message: 'Предложение отправлено оператору. Статус будет отображаться в личном кабинете.' };
  }, { auth: true, verified: true });

  r.post('/api/offers/:id/messages', async (ctx) => {
    const { o, m } = await loadForMember(ctx, 'manager');
    ctx.limiter.hit(`offer-msg:${ctx.user.id}`, 30, 3600_000);
    const { body } = validate(ctx.body, { body: { type: 'text', required: true, min: 2, max: 3000, label: 'Сообщение' } });
    await db.insert('offer_messages', { id: uuid(), offer_id: o.id, author_id: ctx.user.id, author_side: 'client', body, created_at: nowIso() });
    await notify(db, await staffIds(db), { kind: 'op.offer_message', title: `Сообщение по предложению от ${m.short_name || m.full_name}`, link: `/operator/offers/${o.id}` });
    return { ok: true };
  }, { auth: true });

  r.post('/api/offers/:id/documents', async (ctx) => {
    const { o } = await loadForMember(ctx, 'manager');
    if (!EDITABLE.includes(o.status) && o.status !== 'submitted' && o.status !== 'in_review') throw conflict('Документы нельзя добавить в текущем статусе');
    ctx.limiter.hit(`upload:${ctx.user.id}`, 30, 3600_000);
    const v = validate(ctx.body, {
      name: { type: 'string', required: true, max: 150, label: 'Имя файла' },
      mime: { type: 'enum', values: Object.keys(ALLOWED_DOCS), required: true, label: 'Тип файла' },
      dataBase64: { type: 'string', required: true, max: Math.ceil(config.maxUploadMb * 1024 * 1024 * 1.4), label: 'Файл' },
    });
    const count = await db.count('SELECT COUNT(*) AS n FROM offer_documents WHERE offer_id = ?', [o.id]);
    if (count >= 10) throw conflict('К предложению можно приложить не более 10 документов');
    const buf = Buffer.from(v.dataBase64, 'base64');
    if (!buf.length || buf.length > config.maxUploadMb * 1024 * 1024) throw new HttpError(413, `Размер файла — не более ${config.maxUploadMb} МБ`);
    const kind = ALLOWED_DOCS[v.mime];
    if (!kind.magic(buf)) throw new HttpError(422, 'Содержимое файла не соответствует указанному типу');
    const id = uuid();
    const storageKey = `${id}${kind.ext}`;
    fs.mkdirSync(config.uploadDir, { recursive: true });
    fs.writeFileSync(path.join(config.uploadDir, storageKey), buf, { mode: 0o600 });
    const safeName = v.name.replace(/[\\/:*?"<>|]+/g, '_');
    await db.insert('offer_documents', { id, offer_id: o.id, uploaded_by: ctx.user.id, original_name: safeName, mime: v.mime, size_bytes: buf.length, storage_key: storageKey, created_at: nowIso() });
    return { ok: true, id };
  }, { auth: true, bodyLimitMb: 16 });

  r.get('/api/documents/:id', async (ctx) => {
    const d = await db.get('SELECT d.*, o.organization_id FROM offer_documents d JOIN commercial_offers o ON o.id = d.offer_id WHERE d.id = ?', [ctx.params.id]);
    if (!d) throw notFound('Документ не найден');
    if (!isStaff(ctx.user)) {
      const m = await getMembership(db, ctx.user.id);
      if (!m || m.organization_id !== d.organization_id) throw notFound('Документ не найден');
    }
    const file = path.join(config.uploadDir, d.storage_key);
    if (!fs.existsSync(file)) throw notFound('Файл документа отсутствует в хранилище');
    const data = fs.readFileSync(file);
    ctx.res.writeHead(200, {
      'Content-Type': d.mime,
      'Content-Length': data.length,
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(d.original_name)}`,
      'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    ctx.res.end(data);
    if (isStaff(ctx.user)) await audit(db, ctx, 'document.downloaded', 'offer_document', d.id);
  }, { auth: true });

  r.delete('/api/documents/:id', async (ctx) => {
    const d = await db.get('SELECT d.*, o.organization_id, o.status FROM offer_documents d JOIN commercial_offers o ON o.id = d.offer_id WHERE d.id = ?', [ctx.params.id]);
    if (!d) throw notFound('Документ не найден');
    const m = await getMembership(db, ctx.user.id);
    if (!m || m.organization_id !== d.organization_id) throw notFound('Документ не найден');
    if (ORG_ROLE_RANK[m.member_role] < ORG_ROLE_RANK.manager) throw forbidden();
    if (!EDITABLE.includes(d.status)) throw conflict('Документы можно удалять только у черновика или при запросе уточнений');
    await db.run('DELETE FROM offer_documents WHERE id = ?', [d.id]);
    try { fs.unlinkSync(path.join(config.uploadDir, d.storage_key)); } catch { /* файл уже удалён */ }
    return { ok: true };
  }, { auth: true });

  r.get('/api/contracts', async (ctx) => {
    const m = await requireOrg(ctx, 'viewer');
    const rows = await db.all('SELECT * FROM contracts WHERE organization_id = ? ORDER BY created_at DESC', [m.organization_id]);
    return { items: rows.map(contractDto) };
  }, { auth: true });
}

export function contractDto(c) {
  return {
    id: c.id, organizationId: c.organization_id, offerId: c.offer_id, status: c.status, statusLabel: CONTRACT_STATUS[c.status], fuelType: c.fuel_type,
    volumeUnit: c.volume_unit, contractedMonthlyVolume: c.contracted_monthly_volume, region: c.region, startDate: c.start_date, termMonths: c.term_months,
    note: c.note, isDemo: !!c.is_demo, createdAt: c.created_at, updatedAt: c.updated_at,
  };
}
