// Регулярные маршруты пользователей, справочник городов и планировщик газомоторного маршрута.
import { validate, latRule, lngRule } from '../lib/validate.js';
import { HttpError, notFound, forbidden } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { nowIso, getMembership, ORG_ROLE_RANK, parseJson } from '../services/common.js';
import { CITIES, findCity } from '../data/cities.js';
import { buildRoute, DETOUR_FACTOR } from '../services/routing.js';
import { analyzeCorridor, downsample } from '../../public/assets/js/shared/geo.js';
import { vehicleMetrics, FUELS } from '../../public/assets/js/shared/calc.js';

const POINT = { name: { type: 'string', required: true, max: 120, label: 'Пункт' }, lat: latRule(), lng: lngRule() };

function resolvePoint(p, label) {
  if (p.lat !== null && p.lat !== undefined && p.lng !== null && p.lng !== undefined) return { name: p.name, lat: p.lat, lng: p.lng };
  const c = findCity(p.name);
  if (!c) throw new HttpError(422, `Не удалось определить координаты пункта «${p.name}» (${label}). Выберите город из списка подсказок или укажите точку на карте.`);
  return { name: c.name, lat: c.lat, lng: c.lng };
}

const ROUTE_SCHEMA = {
  originName: { type: 'string', required: true, max: 120, label: 'Город отправления' },
  originLat: latRule(), originLng: lngRule(),
  destName: { type: 'string', required: true, max: 120, label: 'Город назначения' },
  destLat: latRule(), destLng: lngRule(),
  waypoints: { type: 'array', max: 8, of: POINT, label: 'Промежуточные пункты' },
  distanceKm: { type: 'number', min: 1, max: 20000, label: 'Расстояние, км' },
  tripsPerMonth: { type: 'number', required: true, min: 0.1, max: 1000, label: 'Частота поездок в месяц' },
  purpose: { type: 'string', max: 120, label: 'Причина поездок' },
  vehicleId: { type: 'string', max: 64, label: 'Автомобиль' },
  preferredStops: { type: 'text', max: 500, label: 'Предпочтительные места остановок' },
  alternatives: { type: 'text', max: 500, label: 'Альтернативные маршруты' },
  stationIssues: { type: 'text', max: 1000, label: 'Проблемы с существующими заправками' },
};

export function routeDto(r, vehicle) {
  return {
    id: r.id, originName: r.origin_name, originLat: r.origin_lat, originLng: r.origin_lng, destName: r.dest_name, destLat: r.dest_lat, destLng: r.dest_lng,
    waypoints: parseJson(r.waypoints, []), distanceKm: r.distance_km, distanceSource: r.distance_source, tripsPerMonth: r.trips_per_month,
    purpose: r.purpose, vehicleId: r.vehicle_id, vehicle: vehicle ? `${vehicle.make} ${vehicle.model}` : null, preferredStops: r.preferred_stops,
    alternatives: r.alternatives, stationIssues: r.station_issues, geometry: parseJson(r.geometry, null), organizationId: r.organization_id,
    monthlyKm: r.distance_km ? Math.round(r.distance_km * r.trips_per_month) : null, isDemo: !!r.is_demo, updatedAt: r.updated_at,
  };
}

async function prepareRoute(ctx, v, orgId) {
  const o = resolvePoint({ name: v.originName, lat: v.originLat, lng: v.originLng }, 'отправление');
  const d = resolvePoint({ name: v.destName, lat: v.destLat, lng: v.destLng }, 'назначение');
  const wps = (v.waypoints || []).map((w) => resolvePoint(w, 'промежуточный пункт'));
  if (o.lat === d.lat && o.lng === d.lng && !wps.length) throw new HttpError(422, 'Пункты отправления и назначения совпадают');
  if (v.vehicleId) {
    const veh = await ctx.db.get('SELECT id, owner_user_id, organization_id FROM vehicles WHERE id = ?', [v.vehicleId]);
    const allowed = veh && ((veh.organization_id && veh.organization_id === orgId) || (!veh.organization_id && veh.owner_user_id === ctx.user.id));
    if (!allowed) throw new HttpError(422, 'Выбранный автомобиль не найден в вашем гараже или автопарке');
  }
  const route = await buildRoute(ctx.config, [[o.lat, o.lng], ...wps.map((w) => [w.lat, w.lng]), [d.lat, d.lng]]);
  return {
    origin_name: o.name, origin_lat: o.lat, origin_lng: o.lng, dest_name: d.name, dest_lat: d.lat, dest_lng: d.lng,
    waypoints: JSON.stringify(wps), distance_km: v.distanceKm || route.distanceKm, distance_source: v.distanceKm ? 'user' : route.source,
    geometry: JSON.stringify(downsample(route.line, 200)), trips_per_month: v.tripsPerMonth, purpose: v.purpose, vehicle_id: v.vehicleId || null,
    preferred_stops: v.preferredStops, alternatives: v.alternatives, station_issues: v.stationIssues,
  };
}

export default function register(r, { db, config }) {
  r.get('/api/geo/cities', async (ctx) => {
    const q = String(ctx.query.q || '').trim().toLowerCase().replace(/ё/g, 'е');
    const items = q ? CITIES.filter((c) => c.name.toLowerCase().replace(/ё/g, 'е').startsWith(q) || c.region.toLowerCase().includes(q)) : CITIES;
    return { items: items.slice(0, q ? 20 : 200) };
  });

  r.get('/api/my-routes', async (ctx) => {
    const m = await getMembership(db, ctx.user.id);
    const rows = ctx.query.scope === 'org' && m
      ? await db.all('SELECT * FROM user_routes WHERE organization_id = ? ORDER BY created_at DESC', [m.organization_id])
      : await db.all('SELECT * FROM user_routes WHERE owner_user_id = ? ORDER BY created_at DESC', [ctx.user.id]);
    const vIds = [...new Set(rows.map((x) => x.vehicle_id).filter(Boolean))];
    const vehicles = vIds.length ? await db.all(`SELECT id, make, model FROM vehicles WHERE id IN (${vIds.map(() => '?').join(',')})`, vIds) : [];
    const vm = Object.fromEntries(vehicles.map((v) => [v.id, v]));
    return { items: rows.map((x) => routeDto(x, vm[x.vehicle_id])) };
  }, { auth: true });

  r.post('/api/my-routes', async (ctx) => {
    ctx.limiter.hit(`route-create:${ctx.user.id}`, 60, 3600_000);
    const v = validate(ctx.body, ROUTE_SCHEMA);
    const m = await getMembership(db, ctx.user.id);
    const useOrg = ctx.body.scope === 'org' && m;
    if (useOrg && ORG_ROLE_RANK[m.member_role] < ORG_ROLE_RANK.manager) throw forbidden('Ваша роль в организации позволяет только просмотр');
    const total = await db.count('SELECT COUNT(*) AS n FROM user_routes WHERE owner_user_id = ?', [ctx.user.id]);
    if (total >= 200) throw forbidden('Достигнут предел количества маршрутов');
    const data = await prepareRoute(ctx, v, m?.organization_id);
    const now = nowIso();
    const row = { id: uuid(), owner_user_id: ctx.user.id, organization_id: useOrg ? m.organization_id : null, ...data, created_at: now, updated_at: now };
    await db.insert('user_routes', row);
    return { ok: true, item: routeDto(row), routing: data.distance_source };
  }, { auth: true });

  async function loadOwned(ctx) {
    const row = await db.get('SELECT * FROM user_routes WHERE id = ?', [ctx.params.id]);
    if (!row) throw notFound('Маршрут не найден');
    if (row.owner_user_id === ctx.user.id) return row;
    if (row.organization_id) {
      const m = await getMembership(db, ctx.user.id);
      if (m && m.organization_id === row.organization_id && ORG_ROLE_RANK[m.member_role] >= ORG_ROLE_RANK.manager) return row;
    }
    throw notFound('Маршрут не найден');
  }

  r.put('/api/my-routes/:id', async (ctx) => {
    const row = await loadOwned(ctx);
    const v = validate(ctx.body, ROUTE_SCHEMA);
    const data = await prepareRoute(ctx, v, row.organization_id);
    await db.update('user_routes', row.id, { ...data, updated_at: nowIso() });
    return { ok: true };
  }, { auth: true });

  r.delete('/api/my-routes/:id', async (ctx) => {
    const row = await loadOwned(ctx);
    await db.run('DELETE FROM user_routes WHERE id = ?', [row.id]);
    return { ok: true };
  }, { auth: true });

  r.post('/api/planner', async (ctx) => {
    ctx.limiter.hit(`planner:${ctx.ip}`, config.production ? 40 : 400, 60 * 60_000);
    const v = validate(ctx.body, {
      originName: { type: 'string', required: true, max: 120, label: 'Начальный пункт' }, originLat: latRule(), originLng: lngRule(),
      destName: { type: 'string', required: true, max: 120, label: 'Конечный пункт' }, destLat: latRule(), destLng: lngRule(),
      waypoints: { type: 'array', max: 8, of: POINT, label: 'Промежуточные точки' },
      vehicleId: { type: 'string', max: 64, label: 'Автомобиль' },
      fuel: { type: 'enum', values: ['cng', 'lng'], default: 'cng', label: 'Вид топлива' },
      fullStock: { type: 'number', min: 1, max: 5000, label: 'Полный запас газа' },
      startStockPct: { type: 'number', min: 0, max: 100, default: 100, label: 'Запас на старте, %' },
      consumption: { type: 'number', min: 1, max: 200, label: 'Средний расход на 100 км' },
      deviationKm: { type: 'number', min: 0, max: 100, default: 10, label: 'Допустимое отклонение, км' },
      reservePct: { type: 'number', min: 0, max: 40, default: 10, label: 'Резерв запаса хода, %' },
    });
    let fuel = v.fuel, fullStock = v.fullStock, consumption = v.consumption, vehicleLabel = null;
    if (v.vehicleId && ctx.user) {
      const veh = await db.get('SELECT * FROM vehicles WHERE id = ?', [v.vehicleId]);
      const m = await getMembership(db, ctx.user.id);
      if (veh && (veh.owner_user_id === ctx.user.id || (veh.organization_id && m?.organization_id === veh.organization_id))) {
        const met = vehicleMetrics(veh);
        if (met.methane) fuel = met.methane;
        fullStock = fullStock || met.stockValue;
        consumption = consumption || veh.consumption_value;
        vehicleLabel = `${veh.make} ${veh.model}`;
      }
    }
    if (!fullStock || !consumption) throw new HttpError(422, 'Укажите запас газа и средний расход (или выберите автомобиль с заполненными характеристиками)');
    const unit = fuel === 'lng' ? 'кг' : 'м³';
    const o = resolvePoint({ name: v.originName, lat: v.originLat, lng: v.originLng }, 'начальный пункт');
    const d = resolvePoint({ name: v.destName, lat: v.destLat, lng: v.destLng }, 'конечный пункт');
    const wps = (v.waypoints || []).map((w) => resolvePoint(w, 'промежуточная точка'));
    if (o.lat === d.lat && o.lng === d.lng && !wps.length) throw new HttpError(422, 'Начальный и конечный пункты совпадают — укажите разные точки');
    const points = [[o.lat, o.lng], ...wps.map((w) => [w.lat, w.lng]), [d.lat, d.lng]];
    const route = await buildRoute(config, points, { alternatives: true });

    const stationsRaw = await db.all("SELECT id, name, kind, fuels, status, address, region, lat, lng, operator_name, hours, is_demo FROM stations WHERE status = 'operational'");
    const fitting = stationsRaw.filter((s) => String(s.fuels).split(',').includes(fuel));
    const fullRangeKm = (fullStock / consumption) * 100;
    // В режиме оценки линия маршрута — прямая, поэтому запас хода переводим в «прямолинейные» км.
    const k = route.source === 'estimate' ? DETOUR_FACTOR : 1;
    const analyse = (line) => {
      const a = analyzeCorridor(line, fitting, { fullRangeKm: fullRangeKm / k, startRangeKm: (fullRangeKm * (v.startStockPct / 100)) / k, maxDeviationKm: v.deviationKm, reservePct: v.reservePct });
      const scale = (x) => Math.round(x * k);
      return {
        ...a,
        totalKm: Math.round(a.totalKm * k * 10) / 10,
        effectiveRangeKm: scale(a.effectiveRangeKm),
        stationsOnRoute: a.stationsOnRoute.map((s) => ({ id: s.id, name: s.name, kind: s.kind, address: s.address, region: s.region, lat: s.lat, lng: s.lng, hours: s.hours, isDemo: !!s.is_demo, alongKm: scale(s.alongKm), deviationKm: s.deviationKm })),
        refuelStops: a.refuelStops.map((s) => ({ ...s, alongKm: scale(s.alongKm) })),
        gaps: a.gaps.map((g) => ({ ...g, fromKm: scale(g.fromKm), toKm: scale(g.toKm), lengthKm: scale(g.lengthKm) })),
      };
    };
    const main = analyse(route.line);
    const distanceKm = route.distanceKm;
    return {
      route: { line: route.line, distanceKm, durationMin: route.durationMin, source: route.source, sourceLabel: route.sourceLabel },
      fuel, unit, vehicle: vehicleLabel, fullStock, consumption,
      fullRangeKm: Math.round(fullRangeKm),
      gasNeeded: Math.round((distanceKm * consumption) / 100),
      analysis: main,
      alternatives: (route.alternatives || []).map((alt) => {
        const a = analyse(alt.line);
        return { line: alt.line, distanceKm: alt.distanceKm, durationMin: alt.durationMin, stations: a.stationsOnRoute.length, gaps: a.gaps.length, feasible: a.feasible };
      }),
      points: { origin: o, destination: d, waypoints: wps },
      disclaimer: route.source === 'osrm'
        ? 'Маршрут построен по дорожному графу OpenStreetMap. Перед поездкой уточняйте режим работы станций и наличие топлива.'
        : 'Маршрутизатор недоступен: расстояние оценено по прямой с коэффициентом извилистости дорог 1,25 и является демонстрационным.',
    };
  });
}
