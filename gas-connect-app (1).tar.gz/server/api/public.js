// Публичные данные: метаинформация, счётчики главной страницы, обезличенная аналитика, новости, обратная связь.
import { validate } from '../lib/validate.js';
import { notFound, HttpError } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { nowIso, notify } from '../services/common.js';
import { REGION_SUGGESTIONS } from '../data/cities.js';
import { demandTiers } from '../services/demand.js';
import { FUELS } from '../../public/assets/js/shared/calc.js';

export function newsDto(n, full = false) {
  return { id: n.id, slug: n.slug, title: n.title, summary: n.summary, ...(full ? { body: n.body } : {}), photoKey: n.photo_key, status: n.status, publishedAt: n.published_at, isDemo: !!n.is_demo };
}

export default function register(r, { db, config }) {
  r.get('/api/meta', async () => {
    const demo = await db.count('SELECT COUNT(*) AS n FROM stations WHERE is_demo = 1');
    return {
      demoData: demo > 0,
      production: config.production,
      routingEnabled: config.routing.enabled,
      proposalModeration: config.proposalModeration,
      devMailPreview: config.devMailPreview,
      maxUploadMb: config.maxUploadMb,
      regions: REGION_SUGGESTIONS,
    };
  });

  r.get('/api/stats/public', async () => {
    const pair = async (sqlAll, sqlDemo) => ({ total: await db.count(sqlAll), demo: await db.count(sqlDemo) });
    return {
      users: await pair("SELECT COUNT(*) AS n FROM users WHERE role = 'user'", "SELECT COUNT(*) AS n FROM users WHERE role = 'user' AND is_demo = 1"),
      companies: await pair('SELECT COUNT(*) AS n FROM organizations', 'SELECT COUNT(*) AS n FROM organizations WHERE is_demo = 1'),
      stations: await pair("SELECT COUNT(*) AS n FROM stations WHERE status = 'operational'", "SELECT COUNT(*) AS n FROM stations WHERE status = 'operational' AND is_demo = 1"),
      proposals: await pair("SELECT COUNT(*) AS n FROM station_proposals WHERE status IN ('published','under_review','included')", "SELECT COUNT(*) AS n FROM station_proposals WHERE status IN ('published','under_review','included') AND is_demo = 1"),
      votes: await db.count('SELECT COUNT(*) AS n FROM votes'),
      routes: await db.count('SELECT COUNT(*) AS n FROM user_routes'),
      vehicles: await db.count('SELECT COALESCE(SUM(quantity),0) AS n FROM vehicles'),
    };
  });

  r.get('/api/analytics/public', async () => {
    const stations = await db.all('SELECT kind, status, COUNT(*) AS n FROM stations GROUP BY kind, status');
    const vehicles = await db.all('SELECT fuel_type, COALESCE(SUM(quantity),0) AS n FROM vehicles GROUP BY fuel_type');
    const proposals = await db.all("SELECT p.region, COUNT(DISTINCT p.id) AS proposals, COUNT(v.user_id) AS votes FROM station_proposals p LEFT JOIN votes v ON v.proposal_id = p.id WHERE p.status IN ('published','under_review','included') GROUP BY p.region");
    const tiers = await demandTiers(db);
    const users = await db.all("SELECT account_type, COUNT(*) AS n FROM users WHERE role = 'user' GROUP BY account_type");
    return {
      stationsByKindStatus: stations.map((s) => ({ kind: s.kind, status: s.status, n: Number(s.n) })),
      vehiclesByFuel: vehicles.map((v) => ({ fuel: v.fuel_type, label: FUELS[v.fuel_type]?.short || v.fuel_type, n: Number(v.n) })),
      proposalsByRegion: proposals.map((p) => ({ region: p.region, proposals: Number(p.proposals), votes: Number(p.votes) })).sort((a, b) => b.votes - a.votes).slice(0, 12),
      usersByType: users.map((u) => ({ type: u.account_type, n: Number(u.n) })),
      demand: { totals: tiers.totals, methodology: tiers.methodology, topRegions: tiers.regions.slice(0, 10).map((x) => ({ region: x.region, votes: x.votes, estimatedM3: x.estimatedM3, estimatedKg: x.estimatedKg })) },
    };
  });

  r.get('/api/news', async () => {
    const rows = await db.all("SELECT * FROM news WHERE status = 'published' ORDER BY published_at DESC LIMIT 50");
    return { items: rows.map((n) => newsDto(n)) };
  });

  r.get('/api/news/:slug', async (ctx) => {
    const n = await db.get("SELECT * FROM news WHERE slug = ? AND status = 'published'", [ctx.params.slug]);
    if (!n) throw notFound('Публикация не найдена');
    return { item: newsDto(n, true) };
  });

  r.post('/api/feedback', async (ctx) => {
    ctx.limiter.hit(`feedback:${ctx.ip}`, config.production ? 5 : 100, 3600_000);
    if (ctx.body.website) return { ok: true, message: 'Спасибо! Сообщение отправлено.' };
    const v = validate(ctx.body, {
      name: { type: 'string', required: !ctx.user, max: 120, label: 'Имя' },
      email: { type: 'email', required: !ctx.user, label: 'E-mail для ответа' },
      topic: { type: 'enum', values: ['question', 'suggestion', 'data_error', 'other'], required: true, label: 'Тема' },
      message: { type: 'text', required: true, min: 10, max: 3000, label: 'Сообщение' },
      related: { type: 'string', max: 200, label: 'Связанный объект' },
      consent: { type: 'bool', label: 'Согласие' },
    });
    if (!ctx.user && !v.consent) throw new HttpError(422, 'Необходимо согласие на обработку персональных данных', { fields: { consent: 'Обязательно' } });
    const id = uuid();
    await db.insert('feedback', { id, user_id: ctx.user?.id || null, name: v.name, email: v.email || ctx.user?.email, topic: v.topic, message: v.message, related: v.related, status: 'new', ip: ctx.ip, created_at: nowIso() });
    const staff = (await db.all("SELECT id FROM users WHERE role IN ('operator','admin') AND status = 'active'")).map((x) => x.id);
    await notify(db, staff, { kind: 'op.feedback', title: 'Новое обращение через форму обратной связи', link: '/operator/feedback' });
    return { ok: true, message: 'Спасибо! Сообщение отправлено, оператор ответит на указанный e-mail.' };
  });
}
