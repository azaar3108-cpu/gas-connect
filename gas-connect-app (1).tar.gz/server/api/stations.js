// Публичные данные о станциях, план развития сети и агрегированные маршруты для карты.
import { notFound } from '../lib/http.js';
import { parseJson } from '../services/common.js';

export const KIND_LABELS = { agnks: 'АГНКС', cryo: 'КриоАЗС', modular: 'Модульная АГНКС', pagz: 'ПАГЗ (передвижной заправщик)', multi: 'Многотопливная АЗС с метаном' };
export const STATUS_LABELS = { operational: 'Действующая', construction: 'Строится', planned: 'Проектируется', closed: 'Закрыта' };
export const PLAN_CATEGORY_LABELS = { confirmed: 'Подтверждённый объект', announced: 'Официально объявленный проект', under_review: 'Рассматривается оператором', user_initiative: 'Инициатива пользователей' };

export function stationDto(s, extra = {}) {
  return {
    id: s.id, name: s.name, kind: s.kind, kindLabel: KIND_LABELS[s.kind], fuels: String(s.fuels).split(','), status: s.status, statusLabel: STATUS_LABELS[s.status],
    operator: s.operator_name, address: s.address, region: s.region, lat: s.lat, lng: s.lng, serviceRadiusKm: s.service_radius_km,
    dispensers: s.dispensers, capacityValue: s.capacity_value, capacityUnit: s.capacity_unit, hours: s.hours, hoursConfirmed: !!s.hours_confirmed,
    photoKey: s.photo_key, description: s.description, sourceName: s.source_name, sourceUrl: s.source_url, dataUpdatedAt: s.data_updated_at || s.updated_at,
    isDemo: !!s.is_demo, plannedYear: s.planned_year ?? null, planCategory: s.category ?? null, ...extra,
  };
}

export default function register(r, { db }) {
  r.get('/api/stations', async (ctx) => {
    const where = [];
    const params = [];
    const q = ctx.query;
    if (q.kind && KIND_LABELS[q.kind]) { where.push('s.kind = ?'); params.push(q.kind); }
    if (q.status && STATUS_LABELS[q.status]) { where.push('s.status = ?'); params.push(q.status); }
    if (q.region) { where.push('s.region = ?'); params.push(String(q.region).slice(0, 120)); }
    if (q.year && /^\d{4}$/.test(q.year)) { where.push('p.planned_year = ?'); params.push(Number(q.year)); }
    let rows = await db.all(
      `SELECT s.*, p.planned_year, p.category FROM stations s
       LEFT JOIN station_development_plans p ON p.station_id = s.id AND p.published = 1
       ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY s.name`, params);
    if (q.fuel === 'cng' || q.fuel === 'lng') rows = rows.filter((s) => String(s.fuels).split(',').includes(q.fuel));
    if (q.q) {
      // Поиск по подстроке без учёта регистра (в т. ч. кириллица) выполняется в приложении.
      const needle = String(q.q).toLowerCase().replace(/ё/g, 'е').slice(0, 100);
      rows = rows.filter((s) => [s.name, s.address, s.region, s.operator_name].join(' ').toLowerCase().replace(/ё/g, 'е').includes(needle));
    }
    return { items: rows.map((s) => stationDto(s)) };
  });

  r.get('/api/stations/:id', async (ctx) => {
    const s = await db.get(`SELECT s.*, p.planned_year, p.category, p.basis, p.source_name AS plan_source_name, p.source_url AS plan_source_url
      FROM stations s LEFT JOIN station_development_plans p ON p.station_id = s.id AND p.published = 1 WHERE s.id = ?`, [ctx.params.id]);
    if (!s) throw notFound('Станция не найдена');
    const followers = await db.count("SELECT COUNT(*) AS n FROM favorites WHERE entity_type = 'station' AND entity_id = ?", [s.id]);
    const fav = ctx.user ? !!(await db.get("SELECT 1 AS x FROM favorites WHERE user_id = ? AND entity_type = 'station' AND entity_id = ?", [ctx.user.id, s.id])) : false;
    const proposal = await db.get('SELECT id, title FROM station_proposals WHERE linked_station_id = ?', [s.id]);
    let votes = 0;
    if (proposal) votes = await db.count('SELECT COUNT(*) AS n FROM votes WHERE proposal_id = ?', [proposal.id]);
    return { item: stationDto(s, { planBasis: s.basis, planSourceName: s.plan_source_name, planSourceUrl: s.plan_source_url, followers, favorite: fav, fromProposal: proposal, proposalVotes: votes }) };
  });

  r.get('/api/plans', async () => {
    const plans = await db.all(
      `SELECT s.*, p.planned_year, p.category, p.basis, p.source_name AS plan_source_name, p.source_url AS plan_source_url, p.proposal_id
       FROM stations s LEFT JOIN station_development_plans p ON p.station_id = s.id AND p.published = 1
       WHERE s.status IN ('operational','construction','planned') ORDER BY COALESCE(p.planned_year, 2026), s.name`);
    const interest = await db.all("SELECT entity_id, COUNT(*) AS n FROM favorites WHERE entity_type = 'station' GROUP BY entity_id");
    const im = Object.fromEntries(interest.map((x) => [x.entity_id, Number(x.n)]));
    const votesByProposal = Object.fromEntries((await db.all('SELECT proposal_id, COUNT(*) AS n FROM votes GROUP BY proposal_id')).map((x) => [x.proposal_id, Number(x.n)]));
    const initiatives = await db.all("SELECT id, title, region, settlement, highway, preferred_kind, status, created_at, is_demo, photo_key FROM station_proposals WHERE status IN ('published','under_review') ORDER BY created_at DESC");
    return {
      stations: plans.map((s) => stationDto(s, { planBasis: s.basis, planSourceName: s.plan_source_name, planSourceUrl: s.plan_source_url, interested: (im[s.id] || 0) + (s.proposal_id ? votesByProposal[s.proposal_id] || 0 : 0) })),
      initiatives: initiatives.map((p) => ({ id: p.id, title: p.title, region: p.region, settlement: p.settlement, highway: p.highway, preferredKind: p.preferred_kind, status: p.status, votes: votesByProposal[p.id] || 0, isDemo: !!p.is_demo, photoKey: p.photo_key, createdAt: p.created_at })),
    };
  });

  // Обезличенные популярные направления: показываются только связки, заявленные ≥ 2 участниками.
  r.get('/api/map/routes', async (ctx) => {
    const rows = await db.all('SELECT owner_user_id, organization_id, origin_name, dest_name, trips_per_month, distance_km, geometry FROM user_routes WHERE geometry IS NOT NULL');
    const groups = new Map();
    for (const x of rows) {
      const key = [x.origin_name, x.dest_name].sort().join(' — ');
      let g = groups.get(key);
      if (!g) { g = { key, participants: new Set(), trips: 0, distanceKm: x.distance_km, geometry: parseJson(x.geometry, null) }; groups.set(key, g); }
      g.participants.add(x.organization_id || x.owner_user_id);
      g.trips += Number(x.trips_per_month) || 0;
    }
    const popular = [...groups.values()].filter((g) => g.participants.size >= 2 && g.geometry)
      .map((g) => ({ name: g.key, participants: g.participants.size, tripsPerMonth: Math.round(g.trips), distanceKm: g.distanceKm, line: g.geometry }))
      .sort((a, b) => b.tripsPerMonth - a.tripsPerMonth).slice(0, 40);
    let mine = [];
    if (ctx.user) {
      mine = (await db.all('SELECT id, origin_name, dest_name, geometry, trips_per_month FROM user_routes WHERE owner_user_id = ?', [ctx.user.id]))
        .map((x) => ({ id: x.id, name: `${x.origin_name} — ${x.dest_name}`, tripsPerMonth: x.trips_per_month, line: parseJson(x.geometry, null) })).filter((x) => x.line);
    }
    return { popular, mine };
  });
}
