// Регистрация, вход, подтверждение e-mail, восстановление доступа, сессии.
import { validate } from '../lib/validate.js';
import { badRequest, conflict, forbidden, HttpError, serializeCookie } from '../lib/http.js';
import { hashPassword, verifyPassword, DUMMY_HASH, randomToken, sha256, uuid } from '../lib/security.js';
import { audit, nowIso, getMembership } from '../services/common.js';
import { SESSION_COOKIE } from '../app.js';

export const PRIVACY_VERSION = '2026-10';
const DISPOSABLE = ['mailinator.com', 'yopmail.com', 'tempmail.com', 'guerrillamail.com', '10minutemail.com', 'trashmail.com', 'temp-mail.org', 'sharklasers.com', 'getnada.com', 'dispostable.com'];
const COMMON_PASSWORDS = ['qwerty123456', '1234567890', 'password123', 'qwertyuiop', '123456789q', 'gazprom2026', 'admin12345', 'passw0rd123'];
const LEGAL_FORMS = ['ООО', 'АО', 'ПАО', 'НАО', 'МУП', 'ГУП', 'ФГУП', 'ГБУ', 'МБУ', 'Кооператив', 'Другое'];

export function checkPasswordPolicy(password, email = '') {
  if (typeof password !== 'string' || password.length < 10) throw new HttpError(422, 'Пароль должен содержать не менее 10 символов', { fields: { password: 'Не менее 10 символов' } });
  if (password.length > 128) throw new HttpError(422, 'Пароль слишком длинный (не более 128 символов)', { fields: { password: 'Не более 128 символов' } });
  if (!/[A-Za-zА-Яа-яЁё]/.test(password) || !/\d/.test(password)) throw new HttpError(422, 'Пароль должен содержать буквы и цифры', { fields: { password: 'Нужны буквы и цифры' } });
  const lower = password.toLowerCase();
  if (COMMON_PASSWORDS.includes(lower) || (email && lower.includes(email.split('@')[0].toLowerCase()) && email.split('@')[0].length > 3)) {
    throw new HttpError(422, 'Пароль слишком простой или совпадает с частью e-mail', { fields: { password: 'Слишком простой пароль' } });
  }
}

export async function createSession(ctx, userId) {
  const token = randomToken(32);
  const now = new Date();
  const expires = new Date(now.getTime() + ctx.config.sessionTtlDays * 86400_000);
  await ctx.db.insert('sessions', { id: sha256(token), user_id: userId, ip: ctx.ip, user_agent: ctx.ua, created_at: now.toISOString(), last_seen_at: now.toISOString(), expires_at: expires.toISOString() });
  // Удаляем просроченные сессии пользователя и ограничиваем число одновременных.
  await ctx.db.run('DELETE FROM sessions WHERE user_id = ? AND expires_at < ?', [userId, now.toISOString()]);
  ctx.setCookie(serializeCookie(SESSION_COOKIE, token, { httpOnly: true, secure: ctx.config.cookieSecure, sameSite: 'Lax', maxAge: ctx.config.sessionTtlDays * 86400 }));
  return token;
}

async function issueToken(db, userId, kind, ttlHours) {
  const token = randomToken(32);
  const now = new Date();
  await db.run('UPDATE auth_tokens SET used_at = ? WHERE user_id = ? AND kind = ? AND used_at IS NULL', [now.toISOString(), userId, kind]);
  await db.insert('auth_tokens', { id: sha256(token), user_id: userId, kind, created_at: now.toISOString(), expires_at: new Date(now.getTime() + ttlHours * 3600_000).toISOString() });
  return token;
}

async function consumeToken(db, token, kind) {
  if (typeof token !== 'string' || token.length < 20 || token.length > 200) throw badRequest('Ссылка недействительна');
  const row = await db.get('SELECT * FROM auth_tokens WHERE id = ? AND kind = ?', [sha256(token), kind]);
  if (!row || row.used_at) throw badRequest('Ссылка недействительна или уже использована');
  if (new Date(row.expires_at) < new Date()) throw badRequest('Срок действия ссылки истёк. Запросите новую.');
  const n = await db.run('UPDATE auth_tokens SET used_at = ? WHERE id = ? AND used_at IS NULL', [nowIso(), row.id]);
  if (!n) throw badRequest('Ссылка уже использована');
  return row;
}

async function sendVerification(ctx, user) {
  const token = await issueToken(ctx.db, user.id, 'verify', 48);
  const link = `${ctx.config.appUrl}/verify?token=${token}`;
  await ctx.mailer.send({
    to: user.email,
    subject: 'GAS CONNECT: подтвердите адрес электронной почты',
    text: `Здравствуйте!\n\nДля завершения регистрации на платформе GAS CONNECT перейдите по ссылке:\n${link}\n\nСсылка действует 48 часов. Если вы не регистрировались, просто проигнорируйте письмо.\n\nGAS CONNECT — демонстрационная платформа.`,
  });
  return link;
}

export async function sessionPayload(ctx) {
  if (!ctx.user) return { user: null, csrf: ctx.csrf };
  const u = ctx.user;
  const profile = await ctx.db.get('SELECT full_name, region, city FROM profiles WHERE user_id = ?', [u.id]);
  const membership = await getMembership(ctx.db, u.id);
  const unread = await ctx.db.count('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL', [u.id]);
  return {
    csrf: ctx.csrf,
    user: {
      id: u.id, email: u.email, role: u.role, accountType: u.account_type, emailVerified: !!u.email_verified_at, isDemo: !!u.is_demo,
      name: profile?.full_name || u.email, region: profile?.region || null, city: profile?.city || null,
      organization: membership ? { id: membership.organization_id, name: membership.short_name || membership.full_name, role: membership.member_role, type: membership.org_type, verification: membership.verification_status } : null,
      unreadNotifications: unread,
    },
  };
}

export default function register(r, { config, db }) {
  r.get('/api/session', async (ctx) => sessionPayload(ctx));

  r.post('/api/auth/register', async (ctx) => {
    ctx.limiter.hit(`register:${ctx.ip}`, config.production ? 5 : 50, 3600_000);
    const b = ctx.body;
    // Ловушка для ботов: скрытое поле должно остаться пустым.
    if (b.website) return { ok: true, message: 'Проверьте почту — мы отправили письмо для подтверждения.' };
    const started = Number(b.formStartedAt);
    if (config.minFormFillMs > 0 && (!started || Date.now() - started < config.minFormFillMs)) {
      throw new HttpError(422, 'Форма заполнена слишком быстро. Проверьте данные и отправьте ещё раз.');
    }
    const base = validate(b, {
      accountType: { type: 'enum', values: ['person', 'ip', 'company'], required: true, label: 'Тип участника' },
      email: { type: 'email', required: true, label: 'E-mail' },
      fullName: { type: 'string', required: true, min: 2, max: 120, label: b.accountType === 'company' ? 'Контактное лицо' : 'Имя' },
      region: { type: 'string', required: true, max: 120, label: 'Регион' },
      city: { type: 'string', max: 120, label: 'Город' },
      phone: { type: 'phone', label: 'Телефон' },
      preferredFuel: { type: 'enum', values: ['cng', 'lng', 'both', 'undecided'], default: 'undecided', label: 'Предпочитаемое топливо' },
      consent: { type: 'bool', label: 'Согласие' },
      joinByInvite: { type: 'bool', label: 'Приглашение' },
    });
    if (!base.consent) throw new HttpError(422, 'Необходимо согласие на обработку персональных данных', { fields: { consent: 'Обязательно' } });
    checkPasswordPolicy(b.password, base.email);
    const domain = base.email.split('@')[1];
    if (DISPOSABLE.includes(domain)) throw new HttpError(422, 'Регистрация с временных почтовых ящиков недоступна', { fields: { email: 'Используйте постоянный адрес' } });

    // Ограничение на массовую регистрацию с одного адреса (сохраняется между перезапусками).
    const dayAgo = new Date(Date.now() - 86400_000).toISOString();
    const recentFromIp = await db.count('SELECT COUNT(*) AS n FROM users WHERE registration_ip = ? AND created_at > ?', [ctx.ip, dayAgo]);
    if (config.production && recentFromIp >= 10) throw new HttpError(429, 'С этого адреса создано слишком много аккаунтов за сутки. Обратитесь в поддержку.');

    let org = null;
    let invite = null;
    if (base.accountType !== 'person') {
      if (base.accountType === 'company' && base.joinByInvite) {
        invite = await db.get('SELECT * FROM organization_invites WHERE email = ? AND accepted_at IS NULL AND expires_at > ? ORDER BY created_at DESC LIMIT 1', [base.email, nowIso()]);
        if (!invite) throw new HttpError(422, 'Для этого e-mail нет действующего приглашения в организацию', { fields: { email: 'Приглашение не найдено' } });
      } else {
        org = validate(b, {
          inn: { type: 'inn', required: true, length: base.accountType === 'ip' ? 12 : 10, label: 'ИНН' },
          orgFullName: { type: 'string', required: base.accountType === 'company', min: 3, max: 250, label: 'Полное наименование' },
          legalForm: { type: 'enum', values: base.accountType === 'ip' ? ['ИП'] : LEGAL_FORMS, default: base.accountType === 'ip' ? 'ИП' : undefined, required: base.accountType === 'company', label: 'Организационно-правовая форма' },
          legalAddress: { type: 'string', max: 300, label: 'Юридический адрес' },
          activity: { type: 'string', required: true, max: 200, label: 'Вид деятельности' },
          employees: { type: 'int', min: 0, max: 1_000_000, label: 'Количество сотрудников' },
          fleetSize: { type: 'int', min: 0, max: 1_000_000, label: 'Размер автопарка' },
          contactPosition: { type: 'string', max: 120, label: 'Должность' },
        });
        const exists = await db.get('SELECT id FROM organizations WHERE inn = ?', [org.inn]);
        if (exists) throw conflict('Организация с таким ИНН уже зарегистрирована. Попросите владельца аккаунта организации пригласить вас.');
      }
    }

    const existing = await db.get('SELECT id, email FROM users WHERE email = ?', [base.email]);
    const genericOk = config.requireEmailVerification
      ? { ok: true, message: 'Проверьте почту — мы отправили письмо со ссылкой для подтверждения адреса.' }
      : { ok: true, message: 'Регистрация завершена. Войдите, используя e-mail и пароль.' };
    if (existing) {
      // Не раскрываем факт регистрации e-mail: владельцу адреса отправляется уведомление.
      await ctx.mailer.send({ to: base.email, subject: 'GAS CONNECT: попытка повторной регистрации', text: 'Кто-то пытался зарегистрироваться на GAS CONNECT с вашим адресом. Если это были вы — войдите в аккаунт или восстановите пароль.' });
      return genericOk;
    }

    const now = nowIso();
    const userId = uuid();
    const passwordHash = await hashPassword(b.password);
    const accountType = invite ? (await db.get('SELECT org_type FROM organizations WHERE id = ?', [invite.organization_id])).org_type : base.accountType;
    try {
      await db.tx(async (t) => {
        await t.insert('users', { id: userId, email: base.email, password_hash: passwordHash, role: 'user', account_type: accountType, status: 'active', registration_ip: ctx.ip, email_verified_at: config.requireEmailVerification ? null : now, created_at: now, updated_at: now });
        await t.insert('profiles', { user_id: userId, full_name: base.fullName, region: base.region, city: base.city, phone: base.phone, preferred_fuel: base.preferredFuel, position: org?.contactPosition || null, updated_at: now });
        await t.insert('consents', { id: uuid(), user_id: userId, document: 'privacy_policy', version: PRIVACY_VERSION, ip: ctx.ip, accepted_at: now });
        if (org) {
          const orgId = uuid();
          const fullName = base.accountType === 'ip' ? (org.orgFullName || `ИП ${base.fullName}`) : org.orgFullName;
          await t.insert('organizations', {
            id: orgId, org_type: base.accountType, full_name: fullName, short_name: fullName.length > 60 ? fullName.slice(0, 60) : fullName,
            legal_form: org.legalForm || (base.accountType === 'ip' ? 'ИП' : null), inn: org.inn, region: base.region, legal_address: org.legalAddress,
            activity: org.activity, employees: org.employees, fleet_size: org.fleetSize, contact_person: base.fullName, contact_position: org.contactPosition,
            contact_email: base.email, contact_phone: base.phone, verification_status: 'pending', created_at: now, updated_at: now,
          });
          await t.insert('organization_members', { organization_id: orgId, user_id: userId, member_role: 'owner', created_at: now });
        }
        if (invite) {
          await t.insert('organization_members', { organization_id: invite.organization_id, user_id: userId, member_role: invite.member_role, created_at: now });
          await t.run('UPDATE organization_invites SET accepted_at = ? WHERE id = ?', [now, invite.id]);
        }
      });
    } catch (e) {
      if (e.code === 'UNIQUE') return genericOk;
      throw e;
    }
    const link = config.requireEmailVerification ? await sendVerification(ctx, { id: userId, email: base.email }) : null;
    await audit(db, { ...ctx, user: { id: userId } }, 'auth.register', 'user', userId, { accountType });
    return { ...genericOk, ...(config.devMailPreview && link ? { devVerifyLink: link } : {}) };
  });

  r.post('/api/auth/login', async (ctx) => {
    const { email, password } = validate(ctx.body, {
      email: { type: 'email', required: true, label: 'E-mail' },
      password: { type: 'string', required: true, max: 128, label: 'Пароль' },
    });
    ctx.limiter.hit(`login-ip:${ctx.ip}`, 30, 15 * 60_000);
    ctx.limiter.hit(`login-email:${email}`, 10, 15 * 60_000);
    const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
    const ok = await verifyPassword(ctx.body.password, user?.password_hash || DUMMY_HASH);
    const fail = new HttpError(401, 'Неверный e-mail или пароль');
    if (!user) throw fail;
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new HttpError(423, 'Вход временно заблокирован из-за множества неудачных попыток. Попробуйте позже или восстановите пароль.');
    }
    if (!ok) {
      const failed = (user.failed_logins || 0) + 1;
      const lock = failed >= 10 ? new Date(Date.now() + 15 * 60_000).toISOString() : null;
      await db.run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', [lock ? 0 : failed, lock, user.id]);
      if (lock) await audit(db, ctx, 'auth.locked', 'user', user.id);
      throw fail;
    }
    if (user.status !== 'active') throw forbidden('Аккаунт заблокирован. Обратитесь к оператору платформы.');
    if (user.is_demo && !config.allowDemoLogin) throw forbidden('Демонстрационные аккаунты отключены в этой версии сайта.');
    await db.run('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?', [nowIso(), user.id]);
    await createSession(ctx, user.id);
    ctx.user = user;
    if (user.role !== 'user') await audit(db, ctx, 'auth.staff_login', 'user', user.id);
    return sessionPayload(ctx);
  });

  r.post('/api/auth/logout', async (ctx) => {
    if (ctx.session) await db.run('DELETE FROM sessions WHERE id = ?', [ctx.session.session_id]);
    ctx.setCookie(serializeCookie(SESSION_COOKIE, '', { httpOnly: true, secure: config.cookieSecure, maxAge: 0 }));
    return { ok: true };
  });

  r.post('/api/auth/verify', async (ctx) => {
    ctx.limiter.hit(`verify:${ctx.ip}`, 30, 3600_000);
    const row = await consumeToken(db, ctx.body.token, 'verify');
    await db.run('UPDATE users SET email_verified_at = ?, updated_at = ? WHERE id = ? AND email_verified_at IS NULL', [nowIso(), nowIso(), row.user_id]);
    await audit(db, ctx, 'auth.email_verified', 'user', row.user_id);
    return { ok: true, message: 'Адрес электронной почты подтверждён. Теперь можно голосовать и отправлять заявки.' };
  });

  r.post('/api/auth/resend-verification', async (ctx) => {
    ctx.limiter.hit(`resend:${ctx.user.id}`, 3, 3600_000);
    if (ctx.user.email_verified_at) return { ok: true, message: 'Адрес уже подтверждён' };
    const link = await sendVerification(ctx, ctx.user);
    return { ok: true, message: 'Письмо отправлено повторно', ...(config.devMailPreview ? { devVerifyLink: link } : {}) };
  }, { auth: true });

  r.post('/api/auth/forgot', async (ctx) => {
    ctx.limiter.hit(`forgot-ip:${ctx.ip}`, 10, 3600_000);
    const { email } = validate(ctx.body, { email: { type: 'email', required: true, label: 'E-mail' } });
    ctx.limiter.hit(`forgot-email:${email}`, 3, 3600_000);
    const user = await db.get('SELECT id, email, status FROM users WHERE email = ?', [email]);
    const out = { ok: true, message: 'Если аккаунт с таким адресом существует, мы отправили на него ссылку для восстановления доступа.' };
    if (!user || user.status !== 'active') return out;
    const token = await issueToken(db, user.id, 'reset', 1);
    const link = `${config.appUrl}/reset?token=${token}`;
    await ctx.mailer.send({ to: user.email, subject: 'GAS CONNECT: восстановление доступа', text: `Для установки нового пароля перейдите по ссылке (действует 1 час):\n${link}\n\nЕсли вы не запрашивали восстановление — проигнорируйте письмо, ваш пароль не изменится.` });
    await audit(db, ctx, 'auth.reset_requested', 'user', user.id);
    return { ...out, ...(config.devMailPreview ? { devResetLink: link } : {}) };
  });

  r.post('/api/auth/reset', async (ctx) => {
    ctx.limiter.hit(`reset:${ctx.ip}`, 20, 3600_000);
    const row = await consumeToken(db, ctx.body.token, 'reset');
    const user = await db.get('SELECT email FROM users WHERE id = ?', [row.user_id]);
    checkPasswordPolicy(ctx.body.password, user.email);
    const hash = await hashPassword(ctx.body.password);
    await db.run('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL, email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?', [hash, nowIso(), nowIso(), row.user_id]);
    await db.run('DELETE FROM sessions WHERE user_id = ?', [row.user_id]);
    await audit(db, ctx, 'auth.password_reset', 'user', row.user_id);
    return { ok: true, message: 'Пароль изменён. Войдите с новым паролем.' };
  });

  r.post('/api/auth/change-password', async (ctx) => {
    ctx.limiter.hit(`chpass:${ctx.user.id}`, 10, 3600_000);
    const user = await db.get('SELECT password_hash, email FROM users WHERE id = ?', [ctx.user.id]);
    if (!(await verifyPassword(String(ctx.body.currentPassword || ''), user.password_hash))) throw new HttpError(422, 'Текущий пароль указан неверно', { fields: { currentPassword: 'Неверный пароль' } });
    checkPasswordPolicy(ctx.body.newPassword, user.email);
    await db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', [await hashPassword(ctx.body.newPassword), nowIso(), ctx.user.id]);
    await db.run('DELETE FROM sessions WHERE user_id = ? AND id <> ?', [ctx.user.id, ctx.session.session_id]);
    await audit(db, ctx, 'auth.password_changed', 'user', ctx.user.id);
    return { ok: true, message: 'Пароль изменён. Другие сеансы завершены.' };
  }, { auth: true });
}
