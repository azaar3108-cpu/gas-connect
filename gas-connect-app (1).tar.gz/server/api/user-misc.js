// Избранное (подписки на станции, инициативы и маршруты) и уведомления.
import { validate } from '../lib/validate.js';
import { notFound } from '../lib/http.js';
import { nowIso } from '../services/common.js';

export default function register(r, { db }) {
  r.get('/api/favorites', async (ctx) => {
    const favs = await db.all('SELECT entity_type, entity_id, created_at FROM favorites WHERE user_id = ? ORDER BY created_at DESC', [ctx.user.id]);
    const ids = (t) => favs.filter((f) => f.entity_type === t).map((f) => f.entity_id);
    const load = async (table, list, cols) => (list.length ? db.all(`SELECT ${cols} FROM ${table} WHERE id IN (${list.map(() => '?').join(',')})`, list) : []);
    const stations = await load('stations', ids('station'), 'id, name, kind, status, region, is_demo');
    const proposals = await load('station_proposals', ids('proposal'), 'id, title, status, region, is_demo');
    const routes = await load('user_routes', ids('route'), 'id, origin_name, dest_name, owner_user_id');
    return {
      stations: stations.map((s) => ({ id: s.id, name: s.name, kind: s.kind, status: s.status, region: s.region, isDemo: !!s.is_demo })),
      proposals: proposals.map((p) => ({ id: p.id, title: p.title, status: p.status, region: p.region, isDemo: !!p.is_demo })),
      routes: routes.filter((x) => x.owner_user_id === ctx.user.id).map((x) => ({ id: x.id, name: `${x.origin_name} — ${x.dest_name}` })),
    };
  }, { auth: true });

  r.post('/api/favorites', async (ctx) => {
    ctx.limiter.hit(`fav:${ctx.user.id}`, 200, 3600_000);
    const v = validate(ctx.body, {
      type: { type: 'enum', values: ['station', 'proposal', 'route'], required: true, label: 'Тип' },
      id: { type: 'string', required: true, max: 64, label: 'Объект' },
    });
    const table = { station: 'stations', proposal: 'station_proposals', route: 'user_routes' }[v.type];
    const exists = await db.get(`SELECT id FROM ${table} WHERE id = ?`, [v.id]);
    if (!exists) throw notFound('Объект не найден');
    await db.run('INSERT INTO favorites (user_id, entity_type, entity_id, created_at) VALUES (?, ?, ?, ?) ON CONFLICT (user_id, entity_type, entity_id) DO NOTHING', [ctx.user.id, v.type, v.id, nowIso()]);
    return { ok: true, favorite: true, message: 'Добавлено в избранное — вы будете получать уведомления об изменениях' };
  }, { auth: true });

  r.delete('/api/favorites/:type/:id', async (ctx) => {
    await db.run('DELETE FROM favorites WHERE user_id = ? AND entity_type = ? AND entity_id = ?', [ctx.user.id, ctx.params.type, ctx.params.id]);
    return { ok: true, favorite: false };
  }, { auth: true });

  r.get('/api/notifications', async (ctx) => {
    const items = await db.all('SELECT id, kind, title, body, link, read_at, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100', [ctx.user.id]);
    return { items: items.map((n) => ({ id: n.id, kind: n.kind, title: n.title, body: n.body, link: n.link, read: !!n.read_at, createdAt: n.created_at })) };
  }, { auth: true });

  r.post('/api/notifications/read', async (ctx) => {
    const now = nowIso();
    if (ctx.body.all) await db.run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', [now, ctx.user.id]);
    else if (Array.isArray(ctx.body.ids)) {
      for (const id of ctx.body.ids.slice(0, 100)) await db.run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ?', [now, String(id), ctx.user.id]);
    }
    return { ok: true };
  }, { auth: true });
}
