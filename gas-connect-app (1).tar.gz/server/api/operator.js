// Кабинет оператора и администратора. Все маршруты требуют роли operator или admin (проверка на сервере).
import { validate, latRule, lngRule } from '../lib/validate.js';
import { HttpError, notFound, conflict, badRequest, sendText } from '../lib/http.js';
import { uuid } from '../lib/security.js';
import { audit, notify, nowIso, orgMemberIds, followerIds, recordStatus, parseJson, toCsv } from '../services/common.js';
import { demandTiers, loadDemandContext, poolDemand, equivalentM3, usersWithRoutesNear, nearestDistanceKm } from '../services/demand.js';
import { OFFER_STATUS, offerFull, offerDto, contractDto, CONTRACT_STATUS } from './offers.js';
import { PROPOSAL_STATUS, proposalDto, KIND_OPTIONS } from './proposals.js';
import { stationDto, KIND_LABELS, STATUS_LABELS, PLAN_CATEGORY_LABELS } from './stations.js';
import { orgDto } from './profile.js';
import { fleetSummary } from './vehicles.js';
import { newsDto } from './public.js';

const OP = { auth: 'operator' };
const ADMIN = { auth: 'admin' };

const OFFER_TRANSITIONS = {
  submitted: ['in_review', 'needs_info', 'preliminarily_approved', 'rejected'],
  in_review: ['needs_info', 'preliminarily_approved', 'rejected'],
  needs_info: ['in_review', 'rejected'],
  preliminarily_approved: ['in_review', 'rejected'],
  rejected: ['in_review'],
  draft: [],
};
const PROPOSAL_TRANSITIONS = {
  pending: ['published', 'rejected', 'hidden'],
  published: ['under_review', 'rejected', 'hidden'],
  under_review: ['published', 'rejected', 'hidden'],
  rejected: ['published', 'under_review'],
  hidden: ['published', 'pending'],
  included: ['under_review'],
};

const STATION_SCHEMA = {
  name: { type: 'string', required: true, max: 160, label: 'Название' },
  kind: { type: 'enum', values: Object.keys(KIND_LABELS), required: true, label: 'Тип станции' },
  fuels: { type: 'array', max: 2, label: 'Виды топлива' },
  status: { type: 'enum', values: Object.keys(STATUS_LABELS), required: true, label: 'Статус' },
  operatorName: { type: 'string', max: 160, label: 'Оператор' },
  address: { type: 'string', max: 300, label: 'Адрес' },
  region: { type: 'string', required: true, max: 120, label: 'Регион' },
  lat: latRule('Широта', true), lng: lngRule('Долгота', true),
  serviceRadiusKm: { type: 'number', min: 0, max: 500, label: 'Радиус обслуживания ПАГЗ, км' },
  dispensers: { type: 'int', min: 0, max: 100, label: 'Количество заправочных постов' },
  capacityValue: { type: 'number', min: 0, max: 1e7, label: 'Проектная производительность' },
  capacityUnit: { type: 'enum', values: ['м³/ч', 'м³/сут', 'т/сут', 'тыс. м³/год'], default: 'м³/ч', label: 'Единица производительности' },
  hours: { type: 'string', max: 120, label: 'Часы работы' },
  hoursConfirmed: { type: 'bool', label: 'Часы работы подтверждены' },
  photoKey: { type: 'string', max: 40, label: 'Фото' },
  description: { type: 'text', max: 2000, label: 'Описание' },
  sourceName: { type: 'string', max: 200, label: 'Источник данных' },
  sourceUrl: { type: 'url', label: 'Ссылка на источник' },
  isDemo: { type: 'bool', label: 'Демонстрационная запись' },
  plannedYear: { type: 'int', min: 2000, max: 2060, label: 'Планируемый год ввода' },
  planCategory: { type: 'enum', values: Object.keys(PLAN_CATEGORY_LABELS), label: 'Категория плана' },
  planBasis: { type: 'text', max: 1000, label: 'Основание включения в план' },
  planSourceName: { type: 'string', max: 200, label: 'Источник плана' },
  planSourceUrl: { type: 'url', label: 'Ссылка на источник плана' },
  planPublished: { type: 'bool', default: true, label: 'Опубликовать в плане' },
};

function stationRow(v) {
  const fuels = (v.fuels && v.fuels.length ? v.fuels : [v.kind === 'cryo' ? 'lng' : 'cng']).filter((f) => f === 'cng' || f === 'lng');
  if (!fuels.length) throw new HttpError(422, 'Укажите хотя бы один вид топлива: КПГ или СПГ');
  return {
    name: v.name, kind: v.kind, fuels: [...new Set(fuels)].join(','), status: v.status, operator_name: v.operatorName, address: v.address, region: v.region,
    lat: v.lat, lng: v.lng, service_radius_km: v.kind === 'pagz' ? v.serviceRadiusKm : null, dispensers: v.dispensers, capacity_value: v.capacityValue,
    capacity_unit: v.capacityUnit, hours: v.hours, hours_confirmed: v.hoursConfirmed ? 1 : 0, photo_key: v.photoKey, description: v.description,
    source_name: v.sourceName, source_url: v.sourceUrl, is_demo: v.isDemo ? 1 : 0, data_updated_at: nowIso(),
  };
}

/** Прозрачная формула приоритета участка (показывается в интерфейсе). */
export function segmentScore({ votes, demand, nearestKm }) {
  const remote = nearestKm === null ? 0 : Math.min(30, Math.max(0, (nearestKm - 50) / 10));
  return Math.round(votes * 1 + demand.vehiclesTotal * 2 + equivalentM3(demand) / 1000 + (demand.multiCompany ? 10 : 0) + remote);
}

export default function register(r, { db, config }) {
  // ---------- Сводная панель ----------
  r.get('/api/op/dashboard', async () => {
    const c = (sql, p) => db.count(sql, p);
    const vehicles = await db.all('SELECT fuel_type, quantity FROM vehicles');
    const qtyBy = (pred) => vehicles.filter(pred).reduce((a, v) => a + (v.quantity || 1), 0);
    const users = await db.all("SELECT created_at, account_type FROM users WHERE role = 'user'");
    const months = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
      const key = d.toISOString().slice(0, 7);
      months.push({ month: key, person: 0, ip: 0, company: 0 });
    }
    for (const u of users) {
      const m = months.find((x) => x.month === String(u.created_at).slice(0, 7));
      if (m && m[u.account_type] !== undefined) m[u.account_type]++;
    }
    const byStatus = async (table, col = 'status') => Object.fromEntries((await db.all(`SELECT ${col} AS s, COUNT(*) AS n FROM ${table} GROUP BY ${col}`)).map((x) => [x.s, Number(x.n)]));
    return {
      users: {
        total: users.length,
        person: users.filter((u) => u.account_type === 'person').length,
        ip: users.filter((u) => u.account_type === 'ip').length,
        company: users.filter((u) => u.account_type === 'company').length,
        verifiedEmail: await c("SELECT COUNT(*) AS n FROM users WHERE role = 'user' AND email_verified_at IS NOT NULL"),
      },
      organizations: { total: await c('SELECT COUNT(*) AS n FROM organizations'), byVerification: await byStatus('organizations', 'verification_status') },
      vehicles: {
        total: qtyBy(() => true),
        cng: qtyBy((v) => ['cng', 'bifuel_cng', 'gasdiesel_cng'].includes(v.fuel_type)),
        lng: qtyBy((v) => v.fuel_type === 'lng'),
        other: qtyBy((v) => !['cng', 'bifuel_cng', 'gasdiesel_cng', 'lng'].includes(v.fuel_type)),
      },
      routes: await c('SELECT COUNT(*) AS n FROM user_routes'),
      votes: await c('SELECT COUNT(*) AS n FROM votes'),
      proposals: await byStatus('station_proposals'),
      offers: await byStatus('commercial_offers'),
      stations: await byStatus('stations'),
      contracts: await byStatus('contracts'),
      queue: {
        proposalsPending: await c("SELECT COUNT(*) AS n FROM station_proposals WHERE status = 'pending'"),
        commentsPending: await c("SELECT COUNT(*) AS n FROM comments WHERE status = 'pending'"),
        offersNew: await c("SELECT COUNT(*) AS n FROM commercial_offers WHERE status = 'submitted'"),
        orgsPending: await c("SELECT COUNT(*) AS n FROM organizations WHERE verification_status = 'pending'"),
        feedbackNew: await c("SELECT COUNT(*) AS n FROM feedback WHERE status = 'new'"),
      },
      registrations: months,
      demand: await demandTiers(db),
    };
  }, OP);

  // ---------- Перспективные участки и объединение спроса ----------
  r.get('/api/op/segments', async () => {
    const dctx = await loadDemandContext(db);
    const stations = await db.all("SELECT lat, lng FROM stations WHERE status = 'operational'");
    const votes = Object.fromEntries((await db.all('SELECT proposal_id, COUNT(*) AS n FROM votes GROUP BY proposal_id')).map((x) => [x.proposal_id, Number(x.n)]));
    const proposals = await db.all("SELECT * FROM station_proposals WHERE status IN ('published','under_review','pending')");
    const planned = await db.all("SELECT s.*, p.planned_year, p.category FROM stations s LEFT JOIN station_development_plans p ON p.station_id = s.id WHERE s.status IN ('planned','construction')");
    const items = [];
    for (const p of proposals) {
      const demand = poolDemand([p.lat, p.lng], dctx, p.id);
      const nearestKm = nearestDistanceKm([p.lat, p.lng], stations);
      items.push({ type: 'proposal', id: p.id, title: p.title, region: p.region, highway: p.highway, status: p.status, statusLabel: PROPOSAL_STATUS[p.status], lat: p.lat, lng: p.lng, votes: votes[p.id] || 0, demand, nearestKm, isDemo: !!p.is_demo, score: segmentScore({ votes: votes[p.id] || 0, demand, nearestKm }) });
    }
    for (const s of planned) {
      const demand = poolDemand([s.lat, s.lng], dctx, null);
      const nearestKm = nearestDistanceKm([s.lat, s.lng], stations);
      items.push({ type: 'station', id: s.id, title: s.name, region: s.region, status: s.status, statusLabel: STATUS_LABELS[s.status], plannedYear: s.planned_year, lat: s.lat, lng: s.lng, votes: 0, demand, nearestKm, isDemo: !!s.is_demo, score: segmentScore({ votes: 0, demand, nearestKm }) });
    }
    items.sort((a, b) => b.score - a.score);
    return {
      items,
      formula: 'Приоритет = голоса × 1 + автомобили без двойного учёта × 2 + расчётная потребность (тыс. м³ экв./мес.) + 10, если заинтересованы ≥ 2 организаций + удалённость от действующей станции (до 30 баллов). Формула упрощённая и служит для сортировки, а не для принятия решений.',
      radiusKm: 25,
    };
  }, OP);

  // ---------- Коммерческие предложения ----------
  r.get('/api/op/offers', async (ctx) => {
    const status = ctx.query.status;
    const rows = await db.all(
      `SELECT o.*, g.full_name AS org_name, g.short_name AS org_short, g.verification_status, g.region AS org_region FROM commercial_offers o JOIN organizations g ON g.id = o.organization_id
       WHERE o.status <> 'draft' ${status && OFFER_STATUS[status] ? 'AND o.status = ?' : ''} ORDER BY COALESCE(o.submitted_at, o.updated_at) DESC`, status && OFFER_STATUS[status] ? [status] : []);
    return { items: rows.map((o) => offerDto(o, { organizationName: o.org_short || o.org_name, organizationVerification: o.verification_status })), statuses: OFFER_STATUS };
  }, OP);

  r.get('/api/op/offers/:id', async (ctx) => {
    const o = await db.get('SELECT * FROM commercial_offers WHERE id = ?', [ctx.params.id]);
    if (!o || o.status === 'draft') throw notFound('Предложение не найдено');
    const fleet = await db.all('SELECT * FROM vehicles WHERE organization_id = ?', [o.organization_id]);
    const contracts = await db.all('SELECT * FROM contracts WHERE offer_id = ?', [o.id]);
    const item = await offerFull(db, o, true);
    await audit(db, ctx, 'offer.viewed', 'offer', o.id);
    return { item, fleet: fleetSummary(fleet), contracts: contracts.map(contractDto), transitions: (OFFER_TRANSITIONS[o.status] || []).map((s) => ({ value: s, label: OFFER_STATUS[s] })) };
  }, OP);

  r.post('/api/op/offers/:id/status', async (ctx) => {
    const o = await db.get('SELECT * FROM commercial_offers WHERE id = ?', [ctx.params.id]);
    if (!o) throw notFound('Предложение не найдено');
    const v = validate(ctx.body, {
      status: { type: 'enum', values: Object.keys(OFFER_STATUS), required: true, label: 'Статус' },
      comment: { type: 'text', max: 3000, label: 'Комментарий оператора' },
    });
    if (!(OFFER_TRANSITIONS[o.status] || []).includes(v.status)) throw conflict(`Переход «${OFFER_STATUS[o.status]}» → «${OFFER_STATUS[v.status]}» недопустим`);
    if (['needs_info', 'rejected'].includes(v.status) && !v.comment) throw new HttpError(422, 'Укажите комментарий: что нужно уточнить или причину отклонения', { fields: { comment: 'Обязательно' } });
    const now = nowIso();
    await db.tx(async (t) => {
      await t.run('UPDATE commercial_offers SET status = ?, updated_at = ? WHERE id = ?', [v.status, now, o.id]);
      await recordStatus(t, ctx, 'offer', o.id, o.status, v.status, v.comment);
      if (v.comment) await t.insert('offer_messages', { id: uuid(), offer_id: o.id, author_id: ctx.user.id, author_side: 'operator', body: v.comment, created_at: now });
      await notify(t, await orgMemberIds(t, o.organization_id), { kind: 'offer.status', title: `Статус предложения изменён: ${OFFER_STATUS[v.status]}`, body: v.comment || o.title, link: `/account/offers/${o.id}` });
      await audit(t, ctx, 'offer.status_changed', 'offer', o.id, { from: o.status, to: v.status });
    });
    return { ok: true, message: `Статус изменён на «${OFFER_STATUS[v.status]}». Организация получила уведомление.` };
  }, OP);

  r.post('/api/op/offers/:id/messages', async (ctx) => {
    const o = await db.get('SELECT id, organization_id, title FROM commercial_offers WHERE id = ?', [ctx.params.id]);
    if (!o) throw notFound('Предложение не найдено');
    const { body } = validate(ctx.body, { body: { type: 'text', required: true, min: 2, max: 3000, label: 'Сообщение' } });
    await db.insert('offer_messages', { id: uuid(), offer_id: o.id, author_id: ctx.user.id, author_side: 'operator', body, created_at: nowIso() });
    await notify(db, await orgMemberIds(db, o.organization_id), { kind: 'offer.message', title: 'Оператор ответил по коммерческому предложению', body: o.title, link: `/account/offers/${o.id}` });
    await audit(db, ctx, 'offer.message', 'offer', o.id);
    return { ok: true };
  }, OP);

  // ---------- Договорённости (уровень 3 спроса) ----------
  const CONTRACT_SCHEMA = {
    organizationId: { type: 'string', required: true, max: 64, label: 'Организация' },
    offerId: { type: 'string', max: 64, label: 'Предложение' },
    status: { type: 'enum', values: Object.keys(CONTRACT_STATUS), required: true, label: 'Статус' },
    fuelType: { type: 'enum', values: ['cng', 'lng'], required: true, label: 'Топливо' },
    volumeUnit: { type: 'enum', values: ['м³', 'кг', 'т'], required: true, label: 'Единица' },
    contractedMonthlyVolume: { type: 'number', min: 0, max: 1e10, required: true, label: 'Объём в месяц' },
    region: { type: 'string', max: 120, label: 'Регион' },
    startDate: { type: 'date', label: 'Дата начала' },
    termMonths: { type: 'int', min: 1, max: 240, label: 'Срок, мес.' },
    note: { type: 'text', max: 1000, label: 'Примечание' },
  };
  r.get('/api/op/contracts', async () => {
    const rows = await db.all('SELECT c.*, o.full_name, o.short_name FROM contracts c JOIN organizations o ON o.id = c.organization_id ORDER BY c.created_at DESC');
    return { items: rows.map((c) => ({ ...contractDto(c), organizationName: c.short_name || c.full_name })), statuses: CONTRACT_STATUS };
  }, OP);
  r.post('/api/op/contracts', async (ctx) => {
    const v = validate(ctx.body, CONTRACT_SCHEMA);
    const org = await db.get('SELECT id, region FROM organizations WHERE id = ?', [v.organizationId]);
    if (!org) throw notFound('Организация не найдена');
    if (v.fuelType === 'cng') v.volumeUnit = 'м³';
    const now = nowIso();
    const id = uuid();
    await db.insert('contracts', { id, organization_id: org.id, offer_id: v.offerId, status: v.status, fuel_type: v.fuelType, volume_unit: v.volumeUnit, contracted_monthly_volume: v.contractedMonthlyVolume, region: v.region || org.region, start_date: v.startDate, term_months: v.termMonths, note: v.note, created_by: ctx.user.id, created_at: now, updated_at: now });
    await notify(db, await orgMemberIds(db, org.id), { kind: 'contract.created', title: `Оператор зафиксировал договорённость: ${CONTRACT_STATUS[v.status]}`, link: '/account/contracts' });
    await audit(db, ctx, 'contract.created', 'contract', id, { volume: v.contractedMonthlyVolume, status: v.status });
    return { ok: true, id };
  }, OP);
  r.put('/api/op/contracts/:id', async (ctx) => {
    const c = await db.get('SELECT * FROM contracts WHERE id = ?', [ctx.params.id]);
    if (!c) throw notFound('Договорённость не найдена');
    const v = validate({ organizationId: c.organization_id, ...ctx.body }, CONTRACT_SCHEMA);
    if (v.fuelType === 'cng') v.volumeUnit = 'м³';
    await db.update('contracts', c.id, { status: v.status, fuel_type: v.fuelType, volume_unit: v.volumeUnit, contracted_monthly_volume: v.contractedMonthlyVolume, region: v.region, start_date: v.startDate, term_months: v.termMonths, note: v.note, updated_at: nowIso() });
    if (v.status !== c.status) await notify(db, await orgMemberIds(db, c.organization_id), { kind: 'contract.status', title: `Статус договорённости: ${CONTRACT_STATUS[v.status]}`, link: '/account/contracts' });
    await audit(db, ctx, 'contract.updated', 'contract', c.id, { from: c.status, to: v.status });
    return { ok: true };
  }, OP);

  // ---------- Организации ----------
  r.get('/api/op/organizations', async (ctx) => {
    const st = ctx.query.status;
    const rows = await db.all(`SELECT * FROM organizations ${st ? 'WHERE verification_status = ?' : ''} ORDER BY created_at DESC`, st ? [st] : []);
    const fleets = Object.fromEntries((await db.all('SELECT organization_id, COALESCE(SUM(quantity),0) AS n FROM vehicles WHERE organization_id IS NOT NULL GROUP BY organization_id')).map((x) => [x.organization_id, Number(x.n)]));
    return { items: rows.map((o) => ({ ...orgDto(o), registeredVehicles: fleets[o.id] || 0 })) };
  }, OP);
  r.get('/api/op/organizations/:id', async (ctx) => {
    const o = await db.get('SELECT * FROM organizations WHERE id = ?', [ctx.params.id]);
    if (!o) throw notFound('Организация не найдена');
    const members = await db.all('SELECT m.member_role, u.email, p.full_name, p.position FROM organization_members m JOIN users u ON u.id = m.user_id LEFT JOIN profiles p ON p.user_id = u.id WHERE m.organization_id = ?', [o.id]);
    const fleet = await db.all('SELECT * FROM vehicles WHERE organization_id = ?', [o.id]);
    const offers = await db.all("SELECT * FROM commercial_offers WHERE organization_id = ? AND status <> 'draft' ORDER BY updated_at DESC", [o.id]);
    const routes = await db.count('SELECT COUNT(*) AS n FROM user_routes WHERE organization_id = ?', [o.id]);
    await audit(db, ctx, 'org.viewed', 'organization', o.id);
    return { item: orgDto(o), members: members.map((m) => ({ role: m.member_role, email: m.email, name: m.full_name, position: m.position })), fleet: fleetSummary(fleet), offers: offers.map((x) => offerDto(x)), routes, checkUrl: 'https://egrul.nalog.ru/' };
  }, OP);
  r.post('/api/op/organizations/:id/verify', async (ctx) => {
    const o = await db.get('SELECT * FROM organizations WHERE id = ?', [ctx.params.id]);
    if (!o) throw notFound('Организация не найдена');
    const v = validate(ctx.body, {
      status: { type: 'enum', values: ['verified', 'rejected', 'pending'], required: true, label: 'Результат проверки' },
      note: { type: 'text', max: 1000, label: 'Комментарий' },
    });
    if (v.status === 'rejected' && !v.note) throw new HttpError(422, 'Укажите причину отказа в подтверждении', { fields: { note: 'Обязательно' } });
    await db.update('organizations', o.id, { verification_status: v.status, verification_note: v.note, verified_at: v.status === 'verified' ? nowIso() : null, verified_by: ctx.user.id, updated_at: nowIso() });
    const label = { verified: 'подтверждена', rejected: 'не подтверждена', pending: 'возвращена на проверку' }[v.status];
    await notify(db, await orgMemberIds(db, o.id), { kind: 'org.verification', title: `Организация ${label} оператором`, body: v.note, link: '/account/company' });
    await audit(db, ctx, 'org.verification', 'organization', o.id, { from: o.verification_status, to: v.status });
    return { ok: true };
  }, OP);

  // ---------- Модерация инициатив ----------
  r.get('/api/op/proposals', async (ctx) => {
    const st = ctx.query.status;
    const rows = await db.all(`SELECT * FROM station_proposals ${st && PROPOSAL_STATUS[st] ? 'WHERE status = ?' : ''} ORDER BY created_at DESC`, st && PROPOSAL_STATUS[st] ? [st] : []);
    const votes = Object.fromEntries((await db.all('SELECT proposal_id, COUNT(*) AS n FROM votes GROUP BY proposal_id')).map((x) => [x.proposal_id, Number(x.n)]));
    const authors = Object.fromEntries((await db.all('SELECT u.id, u.email, u.created_at, p.full_name FROM users u LEFT JOIN profiles p ON p.user_id = u.id')).map((u) => [u.id, u]));
    return { items: rows.map((p) => proposalDto(p, { votes: votes[p.id] || 0, author: authors[p.author_id] ? { email: authors[p.author_id].email, name: authors[p.author_id].full_name, since: authors[p.author_id].created_at } : null, transitions: (PROPOSAL_TRANSITIONS[p.status] || []).map((s) => ({ value: s, label: PROPOSAL_STATUS[s] })) })), statuses: PROPOSAL_STATUS };
  }, OP);

  r.post('/api/op/proposals/:id/status', async (ctx) => {
    const p = await db.get('SELECT * FROM station_proposals WHERE id = ?', [ctx.params.id]);
    if (!p) throw notFound('Инициатива не найдена');
    const v = validate(ctx.body, {
      status: { type: 'enum', values: Object.keys(PROPOSAL_STATUS).filter((s) => s !== 'included'), required: true, label: 'Статус' },
      note: { type: 'text', max: 1000, label: 'Комментарий модератора' },
    });
    if (!(PROPOSAL_TRANSITIONS[p.status] || []).includes(v.status)) throw conflict(`Переход «${PROPOSAL_STATUS[p.status]}» → «${PROPOSAL_STATUS[v.status]}» недопустим`);
    if (['rejected', 'hidden'].includes(v.status) && !v.note) throw new HttpError(422, 'Укажите причину решения — её увидит автор', { fields: { note: 'Обязательно' } });
    await db.tx(async (t) => {
      await t.run('UPDATE station_proposals SET status = ?, moderation_note = ?, updated_at = ? WHERE id = ?', [v.status, v.note, nowIso(), p.id]);
      await recordStatus(t, ctx, 'proposal', p.id, p.status, v.status, v.note);
      const recipients = [p.author_id, ...(await followerIds(t, 'proposal', p.id))];
      await notify(t, recipients, { kind: 'proposal.status', title: `Инициатива «${p.title}»: ${PROPOSAL_STATUS[v.status]}`, body: v.note, link: `/vote/${p.id}` });
      await audit(t, ctx, 'proposal.status_changed', 'proposal', p.id, { from: p.status, to: v.status });
    });
    return { ok: true, message: `Статус изменён: ${PROPOSAL_STATUS[v.status]}` };
  }, OP);

  // Включение инициативы в план развития: создаётся проектируемая станция и запись плана.
  r.post('/api/op/proposals/:id/promote', async (ctx) => {
    const p = await db.get('SELECT * FROM station_proposals WHERE id = ?', [ctx.params.id]);
    if (!p) throw notFound('Инициатива не найдена');
    if (p.linked_station_id) throw conflict('Инициатива уже включена в план');
    const v = validate(ctx.body, {
      name: { type: 'string', required: true, max: 160, label: 'Название объекта' },
      kind: { type: 'enum', values: Object.keys(KIND_LABELS), required: true, label: 'Тип станции' },
      plannedYear: { type: 'int', required: true, min: new Date().getFullYear(), max: 2060, label: 'Планируемый год' },
      category: { type: 'enum', values: ['under_review', 'announced', 'confirmed'], default: 'under_review', label: 'Категория плана' },
      capacityValue: { type: 'number', min: 0, max: 1e7, label: 'Проектная мощность' },
      capacityUnit: { type: 'enum', values: ['м³/ч', 'м³/сут', 'т/сут', 'тыс. м³/год'], default: 'м³/ч', label: 'Единица' },
      basis: { type: 'text', required: true, max: 1000, label: 'Основание включения в план' },
    });
    const now = nowIso();
    const stationId = uuid();
    await db.tx(async (t) => {
      await t.insert('stations', {
        id: stationId, name: v.name, kind: v.kind, fuels: v.kind === 'cryo' ? 'lng' : 'cng', status: 'planned', operator_name: 'Решение оператора платформы (демо)',
        address: `${p.settlement}${p.highway ? ', ' + p.highway : ''}`, region: p.region, lat: p.lat, lng: p.lng, capacity_value: v.capacityValue, capacity_unit: v.capacityUnit,
        photo_key: p.photo_key, description: `Объект создан на основе пользовательской инициативы «${p.title}».`, source_name: 'Инициатива пользователей GAS CONNECT', is_demo: p.is_demo,
        data_updated_at: now, created_by: ctx.user.id, created_at: now, updated_at: now,
      });
      await t.insert('station_development_plans', { id: uuid(), station_id: stationId, planned_year: v.plannedYear, category: v.category, basis: v.basis, source_name: 'Решение оператора платформы', published: 1, proposal_id: p.id, created_at: now, updated_at: now });
      await t.run('UPDATE station_proposals SET status = ?, linked_station_id = ?, updated_at = ? WHERE id = ?', ['included', stationId, now, p.id]);
      await recordStatus(t, ctx, 'proposal', p.id, p.status, 'included', `Включена в план развития на ${v.plannedYear} г. (${PLAN_CATEGORY_LABELS[v.category]})`);
      const voters = (await t.all('SELECT user_id FROM votes WHERE proposal_id = ?', [p.id])).map((x) => x.user_id);
      await notify(t, [p.author_id, ...voters, ...(await followerIds(t, 'proposal', p.id))], { kind: 'proposal.included', title: `Инициатива «${p.title}» включена в план развития`, body: `Планируемый год: ${v.plannedYear}. Статус: ${PLAN_CATEGORY_LABELS[v.category]}.`, link: `/plan` });
      await audit(t, ctx, 'proposal.promoted', 'proposal', p.id, { stationId, plannedYear: v.plannedYear });
    });
    const nearUsers = await usersWithRoutesNear(db, [p.lat, p.lng], 15);
    await notify(db, nearUsers, { kind: 'station.on_route', title: `На вашем маршруте запланирован новый объект: ${v.name}`, body: `Планируемый год: ${v.plannedYear}`, link: `/map?station=${stationId}` });
    return { ok: true, stationId };
  }, OP);

  // ---------- Модерация комментариев ----------
  r.get('/api/op/comments', async (ctx) => {
    const st = ['pending', 'hidden', 'visible'].includes(ctx.query.status) ? ctx.query.status : 'pending';
    const rows = await db.all(
      `SELECT c.*, u.email, p.title FROM comments c LEFT JOIN users u ON u.id = c.user_id JOIN station_proposals p ON p.id = c.proposal_id WHERE c.status = ? ORDER BY c.created_at DESC LIMIT 200`, [st]);
    return { items: rows.map((c) => ({ id: c.id, body: c.body, status: c.status, createdAt: c.created_at, authorEmail: c.email, proposalId: c.proposal_id, proposalTitle: c.title })) };
  }, OP);
  r.post('/api/op/comments/:id/status', async (ctx) => {
    const v = validate(ctx.body, { status: { type: 'enum', values: ['visible', 'hidden'], required: true, label: 'Статус' } });
    const n = await db.run('UPDATE comments SET status = ? WHERE id = ?', [v.status, ctx.params.id]);
    if (!n) throw notFound('Комментарий не найден');
    await audit(db, ctx, 'comment.moderated', 'comment', ctx.params.id, { status: v.status });
    return { ok: true };
  }, OP);

  // ---------- Станции и план развития ----------
  r.get('/api/op/stations', async () => {
    const rows = await db.all('SELECT s.*, p.planned_year, p.category, p.basis, p.source_name AS plan_source_name, p.source_url AS plan_source_url, p.published FROM stations s LEFT JOIN station_development_plans p ON p.station_id = s.id ORDER BY s.updated_at DESC');
    return { items: rows.map((s) => stationDto(s, { planBasis: s.basis, planSourceName: s.plan_source_name, planSourceUrl: s.plan_source_url, planPublished: s.published === null ? null : !!s.published })) };
  }, OP);

  async function savePlan(t, stationId, v, before) {
    const plan = await t.get('SELECT * FROM station_development_plans WHERE station_id = ?', [stationId]);
    const needsPlan = v.plannedYear || v.planCategory || ['planned', 'construction'].includes(v.status);
    if (!needsPlan) return { yearChanged: false };
    const row = {
      planned_year: v.plannedYear, category: v.planCategory || (v.status === 'operational' ? 'confirmed' : 'under_review'), basis: v.planBasis,
      source_name: v.planSourceName, source_url: v.planSourceUrl, published: v.planPublished === false ? 0 : 1, updated_at: nowIso(),
    };
    if (plan) await t.update('station_development_plans', plan.id, row);
    else await t.insert('station_development_plans', { id: uuid(), station_id: stationId, ...row, created_at: nowIso() });
    return { yearChanged: !!plan && plan.planned_year !== v.plannedYear, oldYear: plan?.planned_year, before };
  }

  r.post('/api/op/stations', async (ctx) => {
    const v = validate(ctx.body, STATION_SCHEMA);
    const now = nowIso();
    const id = uuid();
    await db.tx(async (t) => {
      await t.insert('stations', { id, ...stationRow(v), created_by: ctx.user.id, created_at: now, updated_at: now });
      await savePlan(t, id, v, null);
      await audit(t, ctx, 'station.created', 'station', id, { name: v.name, status: v.status });
    });
    const near = await usersWithRoutesNear(db, [v.lat, v.lng], 15);
    const what = v.status === 'operational' ? 'Открыта новая станция' : 'Опубликован новый объект';
    await notify(db, near, { kind: 'station.on_route', title: `${what} на вашем маршруте: ${v.name}`, body: `${KIND_LABELS[v.kind]} · ${STATUS_LABELS[v.status]}${v.plannedYear ? ' · ' + v.plannedYear + ' г.' : ''}`, link: `/map?station=${id}` });
    return { ok: true, id, notified: near.length };
  }, OP);

  r.put('/api/op/stations/:id', async (ctx) => {
    const s = await db.get('SELECT * FROM stations WHERE id = ?', [ctx.params.id]);
    if (!s) throw notFound('Станция не найдена');
    const v = validate(ctx.body, STATION_SCHEMA);
    let planInfo;
    await db.tx(async (t) => {
      await t.update('stations', s.id, { ...stationRow(v), updated_at: nowIso() });
      planInfo = await savePlan(t, s.id, v, s);
      await audit(t, ctx, 'station.updated', 'station', s.id, { from: s.status, to: v.status });
    });
    const followers = await followerIds(db, 'station', s.id);
    if (s.status !== v.status) await notify(db, followers, { kind: 'station.status', title: `${v.name}: статус изменён на «${STATUS_LABELS[v.status]}»`, link: `/map?station=${s.id}` });
    if (planInfo?.yearChanged) await notify(db, followers, { kind: 'station.year', title: `${v.name}: изменён планируемый срок ввода`, body: `Было: ${planInfo.oldYear || '—'}, стало: ${v.plannedYear || '—'}`, link: `/plan` });
    if (s.status !== 'operational' && v.status === 'operational') {
      const near = await usersWithRoutesNear(db, [v.lat, v.lng], 15);
      await notify(db, near.filter((u) => !followers.includes(u)), { kind: 'station.on_route', title: `На вашем маршруте открыта станция: ${v.name}`, link: `/map?station=${s.id}` });
    }
    return { ok: true };
  }, OP);

  r.delete('/api/op/stations/:id', async (ctx) => {
    const s = await db.get('SELECT id, name FROM stations WHERE id = ?', [ctx.params.id]);
    if (!s) throw notFound('Станция не найдена');
    await db.run('UPDATE station_proposals SET linked_station_id = NULL WHERE linked_station_id = ?', [s.id]);
    await db.run("DELETE FROM favorites WHERE entity_type = 'station' AND entity_id = ?", [s.id]);
    await db.run('DELETE FROM stations WHERE id = ?', [s.id]);
    await audit(db, ctx, 'station.deleted', 'station', s.id, { name: s.name });
    return { ok: true };
  }, OP);

  // ---------- Новости ----------
  const NEWS_SCHEMA = {
    title: { type: 'string', required: true, min: 5, max: 200, label: 'Заголовок' },
    summary: { type: 'string', max: 400, label: 'Анонс' },
    body: { type: 'text', required: true, min: 20, max: 20000, label: 'Текст' },
    photoKey: { type: 'string', max: 40, label: 'Изображение' },
    status: { type: 'enum', values: ['draft', 'published'], required: true, label: 'Статус' },
  };
  const slugify = (s) => {
    const map = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
    return s.toLowerCase().split('').map((ch) => map[ch] ?? ch).join('').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70) || 'news';
  };
  r.get('/api/op/news', async () => ({ items: (await db.all('SELECT * FROM news ORDER BY created_at DESC')).map((n) => newsDto(n, true)) }), OP);
  r.post('/api/op/news', async (ctx) => {
    const v = validate(ctx.body, NEWS_SCHEMA);
    const now = nowIso();
    const id = uuid();
    const slug = `${slugify(v.title)}-${id.slice(0, 6)}`;
    await db.insert('news', { id, slug, title: v.title, summary: v.summary, body: v.body, photo_key: v.photoKey, status: v.status, published_at: v.status === 'published' ? now : null, author_id: ctx.user.id, created_at: now, updated_at: now });
    await audit(db, ctx, 'news.created', 'news', id, { status: v.status });
    return { ok: true, id, slug };
  }, OP);
  r.put('/api/op/news/:id', async (ctx) => {
    const n = await db.get('SELECT * FROM news WHERE id = ?', [ctx.params.id]);
    if (!n) throw notFound('Публикация не найдена');
    const v = validate(ctx.body, NEWS_SCHEMA);
    await db.update('news', n.id, { title: v.title, summary: v.summary, body: v.body, photo_key: v.photoKey, status: v.status, published_at: v.status === 'published' ? (n.published_at || nowIso()) : null, updated_at: nowIso() });
    await audit(db, ctx, 'news.updated', 'news', n.id, { status: v.status });
    return { ok: true };
  }, OP);
  r.delete('/api/op/news/:id', async (ctx) => {
    await db.run('DELETE FROM news WHERE id = ?', [ctx.params.id]);
    await audit(db, ctx, 'news.deleted', 'news', ctx.params.id);
    return { ok: true };
  }, OP);

  // ---------- Обратная связь ----------
  r.get('/api/op/feedback', async () => {
    const rows = await db.all('SELECT * FROM feedback ORDER BY created_at DESC LIMIT 300');
    return { items: rows.map((f) => ({ id: f.id, name: f.name, email: f.email, topic: f.topic, message: f.message, related: f.related, status: f.status, createdAt: f.created_at })) };
  }, OP);
  r.post('/api/op/feedback/:id/status', async (ctx) => {
    const v = validate(ctx.body, { status: { type: 'enum', values: ['new', 'in_progress', 'closed'], required: true, label: 'Статус' } });
    await db.run('UPDATE feedback SET status = ? WHERE id = ?', [v.status, ctx.params.id]);
    await audit(db, ctx, 'feedback.status', 'feedback', ctx.params.id, { status: v.status });
    return { ok: true };
  }, OP);

  // ---------- Журнал действий ----------
  r.get('/api/op/audit', async (ctx) => {
    const limit = Math.min(500, Math.max(10, Number(ctx.query.limit) || 200));
    const rows = await db.all(`SELECT a.*, u.email FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.created_at DESC LIMIT ${limit}`);
    return { items: rows.map((a) => ({ id: a.id, action: a.action, entityType: a.entity_type, entityId: a.entity_id, details: parseJson(a.details, null), actor: a.email, ip: a.ip, createdAt: a.created_at })) };
  }, OP);

  // ---------- Инвестиционные сценарии ----------
  r.get('/api/op/scenarios', async () => ({ items: (await db.all('SELECT s.*, u.email FROM investment_scenarios s LEFT JOIN users u ON u.id = s.author_id ORDER BY s.created_at DESC LIMIT 50')).map((s) => ({ id: s.id, title: s.title, inputs: parseJson(s.inputs, {}), author: s.email, createdAt: s.created_at })) }), OP);
  r.post('/api/op/scenarios', async (ctx) => {
    const v = validate(ctx.body, { title: { type: 'string', required: true, max: 160, label: 'Название расчёта' } });
    const inputs = ctx.body.inputs && typeof ctx.body.inputs === 'object' ? ctx.body.inputs : {};
    const json = JSON.stringify(inputs);
    if (json.length > 20000) throw badRequest('Слишком большой набор параметров');
    const id = uuid();
    await db.insert('investment_scenarios', { id, author_id: ctx.user.id, title: v.title, inputs: json, created_at: nowIso() });
    await audit(db, ctx, 'scenario.saved', 'scenario', id);
    return { ok: true, id };
  }, OP);
  r.delete('/api/op/scenarios/:id', async (ctx) => { await db.run('DELETE FROM investment_scenarios WHERE id = ?', [ctx.params.id]); return { ok: true }; }, OP);

  // ---------- Выгрузка отчётов ----------
  r.get('/api/op/export/:kind', async (ctx) => {
    const kind = ctx.params.kind.replace(/\.csv$/, '');
    let csv;
    if (kind === 'offers') {
      const rows = await db.all("SELECT o.*, g.full_name, g.inn FROM commercial_offers o JOIN organizations g ON g.id = o.organization_id WHERE o.status <> 'draft' ORDER BY o.submitted_at DESC");
      csv = toCsv(rows, [
        { label: 'Организация', key: 'full_name' }, { label: 'ИНН', key: 'inn' }, { label: 'Статус', get: (r) => OFFER_STATUS[r.status] },
        { label: 'Топливо', get: (r) => (r.fuel_type === 'lng' ? 'СПГ' : 'КПГ') }, { label: 'Объём в месяц', key: 'monthly_volume' }, { label: 'Единица', key: 'volume_unit' },
        { label: 'Объём в год', key: 'annual_volume' }, { label: 'Мин. гарантированный объём', key: 'min_guaranteed_volume' }, { label: 'Срок, мес.', key: 'term_months' },
        { label: 'Автомобилей', key: 'vehicles_total' }, { label: 'Регион', key: 'main_region' }, { label: 'Отправлено', key: 'submitted_at' }, { label: 'Демо', get: (r) => (r.is_demo ? 'да' : 'нет') },
      ]);
    } else if (kind === 'proposals') {
      const dctx = await loadDemandContext(db);
      const votes = Object.fromEntries((await db.all('SELECT proposal_id, COUNT(*) AS n FROM votes GROUP BY proposal_id')).map((x) => [x.proposal_id, Number(x.n)]));
      const rows = (await db.all('SELECT * FROM station_proposals ORDER BY created_at DESC')).map((p) => ({ ...p, votes: votes[p.id] || 0, pool: poolDemand([p.lat, p.lng], dctx, p.id) }));
      csv = toCsv(rows, [
        { label: 'Инициатива', key: 'title' }, { label: 'Регион', key: 'region' }, { label: 'Трасса', key: 'highway' }, { label: 'Статус', get: (r) => PROPOSAL_STATUS[r.status] },
        { label: 'Широта', key: 'lat' }, { label: 'Долгота', key: 'lng' }, { label: 'Голосов', key: 'votes' }, { label: 'Автомобилей (без двойного учёта)', get: (r) => r.pool.vehiclesTotal },
        { label: 'Организаций', get: (r) => r.pool.organizations }, { label: 'Расчётная потребность КПГ, м³/мес.', get: (r) => r.pool.demandM3 }, { label: 'Расчётная потребность СПГ, кг/мес.', get: (r) => r.pool.demandKg },
        { label: 'Создана', key: 'created_at' }, { label: 'Демо', get: (r) => (r.is_demo ? 'да' : 'нет') },
      ]);
    } else if (kind === 'stations') {
      const rows = await db.all('SELECT s.*, p.planned_year, p.category FROM stations s LEFT JOIN station_development_plans p ON p.station_id = s.id ORDER BY s.name');
      csv = toCsv(rows, [
        { label: 'Название', key: 'name' }, { label: 'Тип', get: (r) => KIND_LABELS[r.kind] }, { label: 'Статус', get: (r) => STATUS_LABELS[r.status] }, { label: 'Топливо', key: 'fuels' },
        { label: 'Регион', key: 'region' }, { label: 'Адрес', key: 'address' }, { label: 'Широта', key: 'lat' }, { label: 'Долгота', key: 'lng' }, { label: 'Постов', key: 'dispensers' },
        { label: 'Производительность', get: (r) => (r.capacity_value ? `${r.capacity_value} ${r.capacity_unit}` : '') }, { label: 'Год ввода', key: 'planned_year' },
        { label: 'Категория плана', get: (r) => PLAN_CATEGORY_LABELS[r.category] || '' }, { label: 'Источник', key: 'source_name' }, { label: 'Обновлено', key: 'data_updated_at' }, { label: 'Демо', get: (r) => (r.is_demo ? 'да' : 'нет') },
      ]);
    } else if (kind === 'demand') {
      const t = await demandTiers(db);
      csv = toCsv(t.regions, [
        { label: 'Регион', key: 'region' }, { label: 'Ур.1 Голосов', key: 'votes' }, { label: 'Ур.1 Инициатив', key: 'proposals' }, { label: 'Ур.1 Заявлено ТС', key: 'declaredVehicles' },
        { label: 'Ур.2 ТС зарегистрировано', key: 'vehicles' }, { label: 'Ур.2 Расчёт КПГ, м³/мес.', key: 'estimatedM3' }, { label: 'Ур.2 Расчёт СПГ, кг/мес.', key: 'estimatedKg' },
        { label: 'Ур.2 Заявлено в предложениях КПГ, м³/мес.', key: 'offersM3' }, { label: 'Ур.2 Заявлено в предложениях СПГ, кг/мес.', key: 'offersKg' },
        { label: 'Ур.3 Договорной КПГ, м³/мес.', key: 'contractM3' }, { label: 'Ур.3 Договорной СПГ, кг/мес.', key: 'contractKg' },
      ]);
    } else if (kind === 'organizations') {
      const rows = await db.all('SELECT * FROM organizations ORDER BY created_at DESC');
      csv = toCsv(rows, [
        { label: 'Наименование', key: 'full_name' }, { label: 'Тип', get: (r) => (r.org_type === 'ip' ? 'ИП' : 'Юрлицо') }, { label: 'ИНН', key: 'inn' }, { label: 'Регион', key: 'region' },
        { label: 'Деятельность', key: 'activity' }, { label: 'Сотрудников', key: 'employees' }, { label: 'Автопарк', key: 'fleet_size' }, { label: 'Проверка', key: 'verification_status' },
        { label: 'Зарегистрирована', key: 'created_at' }, { label: 'Демо', get: (r) => (r.is_demo ? 'да' : 'нет') },
      ]);
    } else throw notFound('Неизвестный тип отчёта');
    await audit(db, ctx, 'report.exported', 'report', kind);
    sendText(ctx.res, 200, csv, 'text/csv; charset=utf-8', { 'Content-Disposition': `attachment; filename="gas-connect-${kind}-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' });
  }, OP);

  // ---------- Администрирование ----------
  r.get('/api/admin/users', async (ctx) => {
    const q = String(ctx.query.q || '').toLowerCase().slice(0, 100);
    let rows = await db.all('SELECT u.id, u.email, u.role, u.account_type, u.status, u.email_verified_at, u.created_at, u.last_login_at, u.is_demo, p.full_name, p.region FROM users u LEFT JOIN profiles p ON p.user_id = u.id ORDER BY u.created_at DESC');
    if (q) rows = rows.filter((u) => `${u.email} ${u.full_name || ''}`.toLowerCase().includes(q));
    return { items: rows.slice(0, 300).map((u) => ({ id: u.id, email: u.email, role: u.role, accountType: u.account_type, status: u.status, verified: !!u.email_verified_at, name: u.full_name, region: u.region, createdAt: u.created_at, lastLoginAt: u.last_login_at, isDemo: !!u.is_demo })), total: rows.length };
  }, ADMIN);
  r.post('/api/admin/users/:id', async (ctx) => {
    const u = await db.get('SELECT id, role, status FROM users WHERE id = ?', [ctx.params.id]);
    if (!u) throw notFound('Пользователь не найден');
    if (u.id === ctx.user.id) throw badRequest('Нельзя изменить собственную роль или статус');
    const v = validate(ctx.body, {
      role: { type: 'enum', values: ['user', 'operator', 'admin'], label: 'Роль' },
      status: { type: 'enum', values: ['active', 'blocked'], label: 'Статус' },
    });
    await db.update('users', u.id, { role: v.role || u.role, status: v.status || u.status, updated_at: nowIso() });
    if (v.status === 'blocked') await db.run('DELETE FROM sessions WHERE user_id = ?', [u.id]);
    await audit(db, ctx, 'admin.user_updated', 'user', u.id, { from: { role: u.role, status: u.status }, to: v });
    return { ok: true };
  }, ADMIN);
  r.get('/api/admin/outbox', async () => {
    const rows = await db.all('SELECT id, to_email, subject, body_text, status, error, created_at FROM mail_outbox ORDER BY created_at DESC LIMIT 100');
    return { items: rows.map((m) => ({ id: m.id, to: m.to_email, subject: m.subject, body: config.production ? '[скрыто]' : m.body_text, status: m.status, error: m.error, createdAt: m.created_at })) };
  }, ADMIN);

  // Метаданные для форм оператора.
  r.get('/api/op/meta', async () => ({ kinds: KIND_LABELS, statuses: STATUS_LABELS, planCategories: PLAN_CATEGORY_LABELS, offerStatuses: OFFER_STATUS, proposalStatuses: PROPOSAL_STATUS, contractStatuses: CONTRACT_STATUS, kindOptions: KIND_OPTIONS }), OP);
}
