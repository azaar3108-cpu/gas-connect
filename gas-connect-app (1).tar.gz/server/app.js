// Сборка приложения: маршруты API, сессии, CSRF, ограничения частоты, статические файлы.
import path from 'node:path';
import { ROOT } from './config.js';
import { Router } from './lib/router.js';
import { HttpError, parseCookies, serializeCookie, readBody, sendJson, makeStaticHandler, unauthorized, forbidden } from './lib/http.js';
import { securityHeaders, RateLimiter, checkOrigin, randomToken, sha256, safeEqual } from './lib/security.js';
import { createMailer } from './lib/mailer.js';

import registerAuth from './api/auth.js';
import registerProfile from './api/profile.js';
import registerVehicles from './api/vehicles.js';
import registerRoutes from './api/routes.js';
import registerStations from './api/stations.js';
import registerProposals from './api/proposals.js';
import registerOffers from './api/offers.js';
import registerUserMisc from './api/user-misc.js';
import registerPublic from './api/public.js';
import registerOperator from './api/operator.js';

export const SESSION_COOKIE = 'gc_session';
export const CSRF_COOKIE = 'gc_csrf';
const STATE_CHANGING = new Set(['POST', 'PUT', 'DELETE', 'PATCH']);

export function createApp({ config, db, logger = console }) {
  const router = new Router();
  const limiter = new RateLimiter();
  limiter.enabled = config.rateLimits;
  const mailer = createMailer(config, db, logger);
  const deps = { config, db, mailer, limiter, logger };

  registerAuth(router, deps);
  registerProfile(router, deps);
  registerVehicles(router, deps);
  registerRoutes(router, deps);
  registerStations(router, deps);
  registerProposals(router, deps);
  registerOffers(router, deps);
  registerUserMisc(router, deps);
  registerPublic(router, deps);
  registerOperator(router, deps);

  const serveStatic = makeStaticHandler(path.join(ROOT, 'public'), { production: config.production });

  async function loadSession(token) {
    if (!token || token.length > 200) return null;
    const row = await db.get(
      `SELECT s.id AS session_id, s.expires_at, s.last_seen_at, u.id, u.email, u.role, u.account_type, u.status, u.email_verified_at, u.is_demo, u.created_at
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?`, [sha256(token)]);
    if (!row) return null;
    const now = new Date();
    if (new Date(row.expires_at) < now || row.status !== 'active') {
      await db.run('DELETE FROM sessions WHERE id = ?', [row.session_id]);
      return null;
    }
    if (config.production && row.is_demo && !config.allowDemoLogin) return null;
    if (now - new Date(row.last_seen_at) > 5 * 60 * 1000) {
      await db.run('UPDATE sessions SET last_seen_at = ? WHERE id = ?', [now.toISOString(), row.session_id]);
    }
    return row;
  }

  async function handle(req, res) {
    const started = Date.now();
    securityHeaders(res, config);
    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;
    const ip = (config.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'unknown';

    if (!pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Метод не поддерживается' });
      if (serveStatic(req, res, pathname)) return;
      return sendJson(res, 404, { error: 'Не найдено' });
    }

    const cookies = parseCookies(req.headers.cookie);
    const setCookies = [];
    let csrf = cookies[CSRF_COOKIE];
    if (!csrf || csrf.length < 20) {
      csrf = randomToken(24);
      setCookies.push(serializeCookie(CSRF_COOKIE, csrf, { secure: config.cookieSecure, sameSite: 'Lax', maxAge: 60 * 60 * 24 * 30 }));
    }
    const ctx = {
      req, res, ip, url, config, db, mailer, limiter, logger,
      query: Object.fromEntries(url.searchParams),
      params: {},
      body: {},
      user: null,
      session: null,
      csrf,
      setCookie: (c) => setCookies.push(c),
      ua: String(req.headers['user-agent'] || '').slice(0, 300),
    };

    try {
      limiter.hit(`api:${ip}`, config.production ? 300 : 3000, 60_000);
      const matched = router.match(req.method, pathname);
      if (!matched) throw new HttpError(404, 'Метод API не найден');
      if (matched.methodNotAllowed) throw new HttpError(405, 'Метод не поддерживается для этого адреса');
      const { route, params } = matched;
      ctx.params = params;

      if (STATE_CHANGING.has(req.method)) {
        if (!checkOrigin(req, config.appUrl)) throw forbidden('Запрос с чужого источника отклонён');
        if (!safeEqual(req.headers['x-csrf-token'], cookies[CSRF_COOKIE])) throw forbidden('Отсутствует или неверен CSRF-токен. Обновите страницу.');
        ctx.body = await readBody(req, (route.opts.bodyLimitMb || 1) * 1024 * 1024);
      }

      const session = await loadSession(cookies[SESSION_COOKIE]);
      if (session) { ctx.user = session; ctx.session = session; }

      const auth = route.opts.auth;
      if (auth) {
        if (!ctx.user) throw unauthorized();
        if (auth === 'operator' && !['operator', 'admin'].includes(ctx.user.role)) throw forbidden('Раздел доступен только сотрудникам оператора');
        if (auth === 'admin' && ctx.user.role !== 'admin') throw forbidden('Раздел доступен только администратору');
        if (route.opts.verified && !ctx.user.email_verified_at) throw forbidden('Подтвердите адрес электронной почты, чтобы выполнить это действие');
      }

      const result = await route.handler(ctx);
      if (res.writableEnded || res.headersSent) return;
      const headers = setCookies.length ? { 'Set-Cookie': setCookies } : {};
      sendJson(res, ctx.status || 200, result === undefined ? { ok: true } : result, headers);
    } catch (e) {
      const status = e instanceof HttpError ? e.status : 500;
      if (status === 500) logger.error?.(`[${req.method} ${pathname}]`, e);
      const headers = setCookies.length ? { 'Set-Cookie': setCookies } : {};
      if (e.retryAfter) headers['Retry-After'] = String(e.retryAfter);
      if (!res.headersSent) {
        sendJson(res, status, {
          error: status === 500 ? 'Внутренняя ошибка сервера. Попробуйте позже.' : e.message,
          ...(e.details ? { details: e.details } : {}),
        }, headers);
      }
    } finally {
      if (!config.test && !config.production && Date.now() - started > 1500) logger.log?.(`[slow] ${req.method} ${pathname} ${Date.now() - started} мс`);
    }
  }

  return { handle, router, limiter, mailer };
}
