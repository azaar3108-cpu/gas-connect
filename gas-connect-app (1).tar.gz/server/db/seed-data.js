// Демонстрационные данные GAS CONNECT. ВСЕ записи вымышленные и помечены is_demo = 1.
// Названия станций, организаций и людей придуманы; координаты — условные, в районах городов и трасс.
import { hashPassword, uuid, randomToken } from '../lib/security.js';
import { findCity } from '../data/cities.js';
import { straightLine, downsample, polylineLength } from '../../public/assets/js/shared/geo.js';
import { toRow as vehicleRow } from '../api/vehicles.js';
import { DETOUR_FACTOR } from '../services/routing.js';

export const DEMO_DOMAIN = 'demo.gas-connect.ru';
export const DEMO_ACCOUNTS = {
  person: `driver@${DEMO_DOMAIN}`,
  ip: `ip@${DEMO_DOMAIN}`,
  company: `company@${DEMO_DOMAIN}`,
  companyManager: `manager@${DEMO_DOMAIN}`,
  company2: `logistics@${DEMO_DOMAIN}`,
  operator: `operator@${DEMO_DOMAIN}`,
  admin: `admin@${DEMO_DOMAIN}`,
};

function rng(seed) {
  let a = seed >>> 0;
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// ИНН с корректной контрольной суммой и кодом региона «00» (такого кода не существует — ИНН заведомо вымышленный).
export function fakeInn(len, rand) {
  const d = [0, 0, ...Array.from({ length: len === 10 ? 7 : 8 }, () => Math.floor(rand() * 10))];
  const cs = (coefs) => (coefs.reduce((s, c, i) => s + c * d[i], 0) % 11) % 10;
  if (len === 10) d.push(cs([2, 4, 10, 3, 5, 9, 4, 6, 8]));
  else { d.push(cs([7, 2, 4, 10, 3, 5, 9, 4, 6, 8])); d.push(cs([3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8])); }
  return d.join('');
}

const daysAgo = (n, base = Date.now()) => new Date(base - n * 86400_000).toISOString();

const STATIONS = [
  // [name, kind, fuels, status, region, lat, lng, address, dispensers, capacity, unit, hours, photo, year, category]
  ['Демо-АГНКС «Северная» (Москва)', 'agnks', 'cng', 'operational', 'Москва', 55.885, 37.53, 'условно: МКАД, северный сектор', 8, 2000, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Юго-Восток» (Москва)', 'agnks', 'cng', 'operational', 'Москва', 55.66, 37.78, 'условно: юго-восточная промзона', 6, 1500, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-КриоАЗС «Подмосковье»', 'cryo', 'lng,cng', 'operational', 'Московская область', 55.45, 37.56, 'условно: трасса М-2, район Подольска', 2, 12, 'т/сут', 'Круглосуточно', 'lng-station', null, 'confirmed'],
  ['Демо-АГНКС «Химки»', 'agnks', 'cng', 'operational', 'Московская область', 55.92, 37.39, 'условно: трасса М-11, выезд из Москвы', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-dispenser', null, 'confirmed'],
  ['Демо-модульная АГНКС «Тверь»', 'modular', 'cng', 'operational', 'Тверская область', 56.83, 35.85, 'условно: трасса М-10, южный въезд в Тверь', 2, 500, 'м³/ч', '06:00–23:00', 'cng-dispenser', null, 'confirmed'],
  ['Демо-АГНКС «Санкт-Петербург, Юг»', 'agnks', 'cng', 'operational', 'Санкт-Петербург', 59.83, 30.4, 'условно: КАД, южный сектор', 6, 1500, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Нижний Новгород»', 'agnks', 'cng', 'operational', 'Нижегородская область', 56.29, 43.92, 'условно: трасса М-7, западный обход', 4, 1200, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-АГНКС «Казань-Восток»', 'agnks', 'cng', 'operational', 'Республика Татарстан', 55.82, 49.25, 'условно: трасса М-7, восточный въезд', 6, 1500, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Тольятти»', 'agnks', 'cng', 'operational', 'Самарская область', 53.53, 49.35, 'условно: трасса М-5', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-dispenser', null, 'confirmed'],
  ['Демо-КриоАЗС «Самара»', 'cryo', 'lng', 'operational', 'Самарская область', 53.25, 50.25, 'условно: логистический узел', 2, 10, 'т/сут', 'Круглосуточно', 'lng-station', null, 'confirmed'],
  ['Демо-АГНКС «Уфа»', 'agnks', 'cng', 'operational', 'Республика Башкортостан', 54.78, 56.05, 'условно: трасса М-5, северный обход', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-АГНКС «Екатеринбург»', 'agnks', 'cng', 'operational', 'Свердловская область', 56.79, 60.53, 'условно: ЕКАД, южный участок', 6, 1500, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Челябинск»', 'agnks', 'cng', 'operational', 'Челябинская область', 55.2, 61.33, 'условно: трасса М-5, западный въезд', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-dispenser', null, 'confirmed'],
  ['Демо-АГНКС «Тюмень»', 'agnks', 'cng', 'operational', 'Тюменская область', 57.12, 65.47, 'условно: Р-402', 3, 800, 'м³/ч', '06:00–00:00', 'cng-station-2', null, 'confirmed'],
  ['Демо-АГНКС «Новосибирск»', 'agnks', 'cng', 'operational', 'Новосибирская область', 54.97, 82.85, 'условно: трасса Р-254, западный въезд', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Воронеж»', 'agnks', 'cng', 'operational', 'Воронежская область', 51.73, 39.24, 'условно: трасса М-4, обход Воронежа', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-АГНКС «Ростов-на-Дону»', 'agnks', 'cng', 'operational', 'Ростовская область', 47.29, 39.78, 'условно: трасса М-4, северный въезд', 6, 1500, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Краснодар»', 'agnks', 'cng', 'operational', 'Краснодарский край', 45.08, 38.94, 'условно: трасса М-4, обход Краснодара', 4, 1200, 'м³/ч', 'Круглосуточно', 'cng-dispenser', null, 'confirmed'],
  ['Демо-АГНКС «Волгоград»', 'agnks', 'cng', 'operational', 'Волгоградская область', 48.78, 44.6, 'условно: Р-22', 3, 800, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-АГНКС «Хабаровск»', 'agnks', 'cng', 'operational', 'Хабаровский край', 48.52, 135.12, 'условно: А-370, северный выезд', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-station', null, 'confirmed'],
  ['Демо-АГНКС «Владивосток»', 'agnks', 'cng', 'operational', 'Приморский край', 43.17, 131.94, 'условно: А-370, въезд во Владивосток', 4, 1000, 'м³/ч', 'Круглосуточно', 'cng-station-2', null, 'confirmed'],
  ['Демо-ПАГЗ «Уссурийск» (мобильная)', 'pagz', 'cng', 'operational', 'Приморский край', 43.8, 131.98, 'зона работы: Уссурийск и окрестности, по графику', 2, 300, 'м³/ч', 'По графику', 'trucks-road', null, 'confirmed'],
  ['Демо-ПАГЗ «Клин» (мобильная)', 'pagz', 'cng', 'operational', 'Московская область', 56.33, 36.72, 'зона работы: трасса М-11, район Клина, по графику', 2, 300, 'м³/ч', 'По графику', 'trucks-road', null, 'confirmed'],
  ['Демо-модульная АГНКС «Торжок» (строится)', 'modular', 'cng', 'construction', 'Тверская область', 57.05, 34.97, 'условно: трасса М-10', 2, 500, 'м³/ч', null, 'compressor', 2027, 'announced'],
  ['Демо-АГНКС «Вышний Волочёк» (строится)', 'agnks', 'cng', 'construction', 'Тверская область', 57.58, 34.6, 'условно: трасса М-11 «Нева»', 4, 1000, 'м³/ч', null, 'compressor', 2027, 'announced'],
  ['Демо-КриоАЗС «Челябинск» (проект)', 'cryo', 'lng', 'planned', 'Челябинская область', 55.12, 61.5, 'условно: логистический узел', 2, 15, 'т/сут', null, 'lng-station', 2028, 'under_review'],
  ['Демо-АГНКС «Иркутск» (проект)', 'agnks', 'cng', 'planned', 'Иркутская область', 52.32, 104.2, 'условно: трасса Р-258 «Байкал»', 4, 1000, 'м³/ч', null, 'highway', 2028, 'under_review'],
  ['Демо-модульная станция «Чита» (проект)', 'modular', 'cng', 'planned', 'Забайкальский край', 52.07, 113.42, 'условно: трасса Р-297 «Амур»', 2, 500, 'м³/ч', null, 'highway', 2029, 'under_review'],
  ['Демо-КриоАЗС «Свободный» (проект)', 'cryo', 'lng', 'planned', 'Амурская область', 51.37, 128.15, 'условно: трасса Р-297 «Амур»', 2, 20, 'т/сут', null, 'lng-station', 2030, 'under_review'],
];

const PROPOSALS = [
  // [title, region, settlement, highway, lat, lng, kind, status, justification, freq, transport, nearestKm]
  ['АГНКС — Комсомольск-на-Амуре, А-376', 'Хабаровский край', 'Комсомольск-на-Амуре', 'А-376', 50.52, 136.95, 'agnks', 'published', 'В Комсомольске-на-Амуре нет действующей станции КПГ: при поездках из Хабаровска (около 380 км) приходится возвращаться на бензин. Регулярно ездят и частные автомобили, и коммерческий транспорт.', 'Несколько раз в месяц', 'Легковой автомобиль на КПГ', 380],
  ['КриоАЗС — участок А-370 между Хабаровском и Уссурийском', 'Приморский край', 'Дальнереченск', 'А-370 «Уссури»', 45.93, 133.73, 'cryo', 'under_review', 'Магистральные тягачи на СПГ проходят участок Хабаровск — Владивосток (около 760 км) без промежуточной заправки СПГ. Нужна точка примерно на середине пути.', 'Ежедневно', 'Магистральный тягач на СПГ', 330],
  ['Модульная АГНКС — Великий Новгород, М-11', 'Новгородская область', 'Великий Новгород', 'М-11 «Нева»', 58.47, 31.33, 'modular', 'published', 'На участке М-11 между Тверью и Санкт-Петербургом мало точек заправки метаном, водители газовых автомобилей вынуждены планировать маршрут с большим запасом.', 'Еженедельно', 'Лёгкий коммерческий транспорт', 170],
  ['АГНКС — Набережные Челны, М-7', 'Республика Татарстан', 'Набережные Челны', 'М-7 «Волга»', 55.71, 52.3, 'agnks', 'published', 'Большой поток грузового транспорта на восток от Казани; автопарки готовы переводить технику на КПГ при наличии станции на выезде из города.', 'Ежедневно', 'Грузовые автомобили', 230],
  ['АГНКС — Кемерово, Р-255', 'Кемеровская область — Кузбасс', 'Кемерово', 'Р-255 «Сибирь»', 55.33, 85.95, 'agnks', 'published', 'Регулярные поездки Новосибирск — Кемерово (около 260 км). Хотелось бы заправляться на обоих концах маршрута.', 'Несколько раз в неделю', 'Легковой автомобиль', 250],
  ['ПАГЗ — Находка (на период подтверждения спроса)', 'Приморский край', 'Находка', 'Р-447', 42.85, 132.85, 'pagz', 'published', 'Портовая логистика: грузовики на КПГ курсируют между Владивостоком и Находкой. Мобильный заправщик позволит проверить спрос до строительства стационарной станции.', 'Ежедневно', 'Грузовые автомобили на КПГ', 150],
  ['АГНКС — Ставрополь, Р-217', 'Ставропольский край', 'Ставрополь', 'Р-217 «Кавказ»', 45.06, 41.92, 'agnks', 'published', 'Пассажирские перевозчики региона рассматривают закупку автобусов на КПГ, но нужна заправка в черте города.', 'Ежедневно', 'Автобусы', 260],
  ['КриоАЗС — Улан-Удэ, Р-258', 'Республика Бурятия', 'Улан-Удэ', 'Р-258 «Байкал»', 51.8, 107.5, 'cryo', 'published', 'Транзитный грузовой поток Иркутск — Чита. Без СПГ на этом участке переход перевозчиков на газ невозможен.', 'Несколько раз в неделю', 'Магистральный тягач на СПГ', 900],
  ['АГНКС — Псков', 'Псковская область', 'Псков', 'Р-23', 57.78, 28.37, 'agnks', 'pending', 'Прошу рассмотреть станцию в Пскове: в области нет заправок метаном, а таксопарки готовы перейти на газ.', 'Ежедневно', 'Такси', 280],
  ['АГНКС — участок М-4 у Ростова (дубль)', 'Ростовская область', 'Аксай', 'М-4 «Дон»', 47.27, 39.86, 'agnks', 'rejected', 'Нужна ещё одна станция у Ростова.', 'Еженедельно', 'Легковой автомобиль', 6],
];

const CORRIDORS = [
  ['Хабаровск', 'Комсомольск-на-Амуре'], ['Хабаровск', 'Владивосток'], ['Владивосток', 'Находка'], ['Москва', 'Тверь'], ['Тверь', 'Санкт-Петербург'],
  ['Москва', 'Нижний Новгород'], ['Нижний Новгород', 'Казань'], ['Казань', 'Набережные Челны'], ['Новосибирск', 'Кемерово'], ['Ростов-на-Дону', 'Краснодар'],
  ['Ставрополь', 'Пятигорск'], ['Иркутск', 'Улан-Удэ'], ['Самара', 'Тольятти'], ['Екатеринбург', 'Челябинск'], ['Москва', 'Тула'], ['Уссурийск', 'Владивосток'],
];

function routeRow(from, to, extra) {
  const a = findCity(from), b = findCity(to);
  const line = straightLine([[a.lat, a.lng], [b.lat, b.lng]], 10);
  return {
    origin_name: a.name, origin_lat: a.lat, origin_lng: a.lng, dest_name: b.name, dest_lat: b.lat, dest_lng: b.lng, waypoints: '[]',
    distance_km: Math.round(polylineLength(line) * DETOUR_FACTOR), distance_source: 'estimate', geometry: JSON.stringify(downsample(line, 120)), is_demo: 1, ...extra,
  };
}

export async function seedDemo(db, { password = 'GasDemo2026!', syntheticUsers = 60 } = {}) {
  const already = await db.get('SELECT id FROM users WHERE email = ?', [DEMO_ACCOUNTS.operator]);
  if (already) return { skipped: true };
  const rand = rng(20261030);
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const base = Date.now();
  const hash = await hashPassword(password);
  const lockedHash = await hashPassword(randomToken(24)); // синтетические пользователи не могут войти
  const ids = {};

  await db.tx(async (t) => {
    const user = async (key, email, accountType, role, name, region, city, createdDaysAgo, pw = hash) => {
      const id = uuid();
      const created = daysAgo(createdDaysAgo, base);
      await t.insert('users', { id, email, password_hash: pw, role, account_type: accountType, status: 'active', email_verified_at: created, is_demo: 1, created_at: created, updated_at: created });
      await t.insert('profiles', { user_id: id, full_name: name, region, city, preferred_fuel: 'cng', updated_at: created });
      await t.insert('consents', { id: uuid(), user_id: id, document: 'privacy_policy', version: '2026-10', accepted_at: created });
      if (key) ids[key] = id;
      return id;
    };
    const org = async (key, type, fullName, shortName, legalForm, region, activity, employees, fleet, extra = {}) => {
      const id = uuid();
      const created = daysAgo(120, base);
      await t.insert('organizations', {
        id, org_type: type, full_name: fullName, short_name: shortName, legal_form: legalForm, inn: fakeInn(type === 'ip' ? 12 : 10, rand), region, activity,
        employees, fleet_size: fleet, verification_status: 'verified', verified_at: daysAgo(100, base), is_demo: 1, created_at: created, updated_at: created, ...extra,
      });
      ids[key] = id;
      return id;
    };
    const vehicle = async (owner, orgId, v, createdDaysAgo = 90) => {
      const id = uuid();
      const created = daysAgo(createdDaysAgo, base);
      await t.insert('vehicles', { id, owner_user_id: owner, organization_id: orgId, ...vehicleRow({ workingPressureBar: 200, quantity: 1, ...v }), is_demo: 1, created_at: created, updated_at: created });
      return id;
    };
    const route = async (owner, orgId, vehicleId, from, to, trips, purpose, extra = {}) => {
      const id = uuid();
      const created = daysAgo(60, base);
      await t.insert('user_routes', { id, owner_user_id: owner, organization_id: orgId, vehicle_id: vehicleId, ...routeRow(from, to, { trips_per_month: trips, purpose, ...extra }), created_at: created, updated_at: created });
      return id;
    };

    // --- Сотрудники оператора ---
    await user('operator', DEMO_ACCOUNTS.operator, 'staff', 'operator', 'Ольга Операторова (демо)', 'Москва', 'Москва', 200);
    await user('admin', DEMO_ACCOUNTS.admin, 'staff', 'admin', 'Администратор (демо)', 'Москва', 'Москва', 210);

    // --- Физическое лицо ---
    const person = await user('person', DEMO_ACCOUNTS.person, 'person', 'user', 'Алексей Демидов (демо)', 'Хабаровский край', 'Хабаровск', 75);
    const vesta = await vehicle(person, null, { make: 'Lada', model: 'Vesta CNG', year: 2023, vehicleType: 'Легковой', fuelType: 'bifuel_cng', equipmentType: 'Заводская газовая версия', cylinderCount: 2, cylinderVolumeL: 50, consumptionValue: 8.5, monthlyMileageKm: 2200 });
    await vehicle(person, null, { make: 'ГАЗ', model: 'ГАЗель NEXT CNG', year: 2021, vehicleType: 'Лёгкий коммерческий', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 2 (металлокомпозит)', cylinderCount: 4, cylinderVolumeL: 80, consumptionValue: 18, monthlyMileageKm: 1500 });
    const pr1 = await route(person, null, vesta, 'Хабаровск', 'Комсомольск-на-Амуре', 4, 'Работа / командировки', { station_issues: 'В Комсомольске-на-Амуре нет заправки КПГ — обратно еду на бензине.', preferred_stops: 'Селихино', alternatives: 'Нет' });
    await route(person, null, vesta, 'Хабаровск', 'Владивосток', 1, 'Личные поездки', { station_issues: 'Нет заправок КПГ на середине пути.' });
    ids.personRoute = pr1;

    // --- ИП ---
    const ipUser = await user('ip', DEMO_ACCOUNTS.ip, 'ip', 'user', 'Смирнова Елена Андреевна (демо)', 'Тверская область', 'Тверь', 95);
    const ipOrg = await org('ipOrg', 'ip', 'ИП Смирнова Е. А. (демо)', 'ИП Смирнова Е. А. (демо)', 'ИП', 'Тверская область', 'Доставка грузов, лёгкий коммерческий транспорт', 9, 6, {
      vehicle_types: 'Фургоны до 3,5 т', transport_directions: 'Тверь — Москва, Тверь — Великий Новгород', trip_frequency: 'Ежедневно', est_monthly_gas: 9000, est_monthly_gas_unit: 'м³',
      contact_person: 'Смирнова Е. А.', contact_email: DEMO_ACCOUNTS.ip,
    });
    await t.insert('organization_members', { organization_id: ipOrg, user_id: ipUser, member_role: 'owner', created_at: daysAgo(95, base) });
    const gz = await vehicle(ipUser, ipOrg, { make: 'ГАЗ', model: 'ГАЗель NEXT CNG', year: 2022, vehicleType: 'Лёгкий коммерческий', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 2 (металлокомпозит)', cylinderCount: 4, cylinderVolumeL: 80, consumptionValue: 18, monthlyMileageKm: 5200, payloadT: 1.5, quantity: 4 });
    await vehicle(ipUser, ipOrg, { make: 'Ford', model: 'Transit', year: 2019, vehicleType: 'Лёгкий коммерческий', fuelType: 'diesel', consumptionValue: 11, monthlyMileageKm: 4000, payloadT: 1.2, quantity: 2, convertible: true, note: 'Рассматривается перевод на газодизель' });
    await route(ipUser, ipOrg, gz, 'Тверь', 'Москва', 40, 'Грузовые перевозки', { station_issues: 'На обратном пути длинная очередь на заправке.' });
    await route(ipUser, ipOrg, gz, 'Тверь', 'Великий Новгород', 8, 'Грузовые перевозки', { station_issues: 'Нет станций КПГ на М-11 севернее Твери.' });

    // --- Юридическое лицо 1: Дальний Восток ---
    const coUser = await user('company', DEMO_ACCOUNTS.company, 'company', 'user', 'Кравцов Игорь Петрович (демо)', 'Приморский край', 'Владивосток', 110);
    const coOrg = await org('coOrg', 'company', 'Общество с ограниченной ответственностью «Демо-Логистик Восток»', 'ООО «Демо-Логистик Восток»', 'ООО', 'Приморский край', 'Магистральные грузоперевозки, портовая логистика', 240, 64, {
      legal_address: 'вымышленный адрес для демонстрации', vehicle_types: 'Магистральные тягачи, среднетоннажные грузовики', transport_directions: 'Владивосток — Хабаровск, Владивосток — Находка',
      trip_frequency: 'Ежедневно, 30–40 рейсов в месяц', est_monthly_gas: 180000, est_monthly_gas_unit: 'кг', contact_person: 'Кравцов И. П.', contact_position: 'Директор по логистике', contact_email: DEMO_ACCOUNTS.company, contact_phone: '+7 900 000-00-01',
    });
    await t.insert('organization_members', { organization_id: coOrg, user_id: coUser, member_role: 'owner', created_at: daysAgo(110, base) });
    const mgr = await user('companyManager', DEMO_ACCOUNTS.companyManager, 'company', 'user', 'Белова Марина (демо)', 'Приморский край', 'Владивосток', 80);
    await t.insert('organization_members', { organization_id: coOrg, user_id: mgr, member_role: 'manager', created_at: daysAgo(80, base) });
    const kLng = await vehicle(coUser, coOrg, { make: 'КАМАЗ', model: '54901 (СПГ)', year: 2023, vehicleType: 'Магистральный тягач', fuelType: 'lng', equipmentType: 'СПГ: криогенный бак', lngTankL: 450, consumptionValue: 28, monthlyMileageKm: 11000, payloadT: 20, quantity: 18 });
    const kCng = await vehicle(coUser, coOrg, { make: 'КАМАЗ', model: '65115 (КПГ)', year: 2021, vehicleType: 'Грузовой (до 12 т)', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 1 (сталь)', cylinderCount: 8, cylinderVolumeL: 100, consumptionValue: 38, monthlyMileageKm: 6000, payloadT: 15, quantity: 12 });
    await vehicle(coUser, coOrg, { make: 'КАМАЗ', model: '5490 (дизель)', year: 2018, vehicleType: 'Магистральный тягач', fuelType: 'diesel', consumptionValue: 33, monthlyMileageKm: 10000, payloadT: 20, quantity: 34, convertible: true, note: 'Кандидаты на замену техникой на СПГ' });
    await route(coUser, coOrg, kLng, 'Владивосток', 'Хабаровск', 36, 'Грузовые перевозки', { station_issues: 'Нет заправки СПГ на участке протяжённостью около 760 км.', alternatives: 'Нет альтернативы А-370' });
    await route(coUser, coOrg, kCng, 'Владивосток', 'Находка', 60, 'Портовая логистика', { station_issues: 'В Находке нет станции КПГ.' });

    // --- Юридическое лицо 2: Центр / Поволжье (тот же коридор М-7, для объединения спроса) ---
    const c2User = await user('company2', DEMO_ACCOUNTS.company2, 'company', 'user', 'Орлов Дмитрий (демо)', 'Нижегородская область', 'Нижний Новгород', 130);
    const c2Org = await org('c2Org', 'company', 'Акционерное общество «Тестовые Перевозки Центр»', 'АО «Тестовые Перевозки Центр»', 'АО', 'Нижегородская область', 'Междугородние грузоперевозки', 410, 120, {
      vehicle_types: 'Тягачи, рефрижераторы', transport_directions: 'Москва — Нижний Новгород — Казань — Набережные Челны', trip_frequency: 'Ежедневно', est_monthly_gas: 260000, est_monthly_gas_unit: 'м³',
      contact_person: 'Орлов Д.', contact_position: 'Руководитель автопарка', contact_email: DEMO_ACCOUNTS.company2,
    });
    await t.insert('organization_members', { organization_id: c2Org, user_id: c2User, member_role: 'owner', created_at: daysAgo(130, base) });
    const sc = await vehicle(c2User, c2Org, { make: 'Scania', model: 'G340 CNG', year: 2020, vehicleType: 'Магистральный тягач', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 1 (сталь)', cylinderCount: 12, cylinderVolumeL: 80, consumptionValue: 34, monthlyMileageKm: 12000, payloadT: 20, quantity: 22 });
    const kk = await vehicle(c2User, c2Org, { make: 'КАМАЗ', model: '5490 NEO (КПГ)', year: 2022, vehicleType: 'Магистральный тягач', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 1 (сталь)', cylinderCount: 10, cylinderVolumeL: 100, consumptionValue: 36, monthlyMileageKm: 11000, payloadT: 20, quantity: 30 });
    await route(c2User, c2Org, sc, 'Москва', 'Нижний Новгород', 50, 'Грузовые перевозки');
    await route(c2User, c2Org, kk, 'Нижний Новгород', 'Казань', 45, 'Грузовые перевозки');
    await route(c2User, c2Org, kk, 'Казань', 'Набережные Челны', 30, 'Грузовые перевозки', { station_issues: 'Нет станции на выезде из Набережных Челнов на восток.' });

    // --- Третья организация на коридоре Казань — Набережные Челны (для демонстрации объединения спроса) ---
    const c3User = await user(null, `kama@${DEMO_DOMAIN}`, 'company', 'user', 'Сафин Руслан (демо)', 'Республика Татарстан', 'Набережные Челны', 70, lockedHash);
    const c3Org = await org('c3Org', 'company', 'ООО «Кама-Демо-Транс»', 'ООО «Кама-Демо-Транс»', 'ООО', 'Республика Татарстан', 'Перевозка автокомпонентов', 150, 45, { verification_status: 'pending', verified_at: null, transport_directions: 'Набережные Челны — Казань', trip_frequency: 'Ежедневно' });
    await t.insert('organization_members', { organization_id: c3Org, user_id: c3User, member_role: 'owner', created_at: daysAgo(70, base) });
    const kt = await vehicle(c3User, c3Org, { make: 'КАМАЗ', model: '65207 (КПГ)', year: 2023, vehicleType: 'Магистральный тягач', fuelType: 'cng', equipmentType: 'КПГ: баллоны тип 1 (сталь)', cylinderCount: 10, cylinderVolumeL: 100, consumptionValue: 35, monthlyMileageKm: 9000, payloadT: 18, quantity: 15 });
    await route(c3User, c3Org, kt, 'Набережные Челны', 'Казань', 50, 'Грузовые перевозки');

    // --- Синтетические участники (не могут войти: случайный пароль) ---
    const synth = [];
    const names = ['Иван', 'Пётр', 'Мария', 'Анна', 'Сергей', 'Ольга', 'Николай', 'Татьяна', 'Андрей', 'Екатерина', 'Михаил', 'Наталья'];
    const cars = [['Lada', 'Vesta CNG', 'bifuel_cng', 2, 50, 8.5], ['Lada', 'Largus CNG', 'bifuel_cng', 2, 60, 9.5], ['ГАЗ', 'ГАЗель NEXT CNG', 'cng', 4, 80, 18], ['УАЗ', 'Профи CNG', 'cng', 4, 60, 17], ['Škoda', 'Octavia G-TEC', 'bifuel_cng', 3, 40, 5.5]];
    for (let i = 0; i < syntheticUsers; i++) {
      const [from, to] = pick(CORRIDORS);
      const c = findCity(from);
      const id = await user(null, `participant-${String(i + 1).padStart(3, '0')}@${DEMO_DOMAIN}`, 'person', 'user', `${pick(names)} (демо-участник)`, c.region, c.name, Math.floor(rand() * 330), lockedHash);
      const [mk, md, fuel, n, vol, cons] = pick(cars);
      const vid = await vehicle(id, null, { make: mk, model: md, year: 2015 + Math.floor(rand() * 10), vehicleType: fuel === 'cng' ? 'Лёгкий коммерческий' : 'Легковой', fuelType: fuel, cylinderCount: n, cylinderVolumeL: vol, consumptionValue: cons, monthlyMileageKm: 800 + Math.round(rand() * 3000) }, Math.floor(rand() * 200));
      if (rand() < 0.8) await route(id, null, vid, from, to, 1 + Math.round(rand() * 12), pick(['Работа / командировки', 'Личные поездки', 'Такси', 'Доставка']));
      synth.push({ id, region: c.region, near: [c.lat, c.lng] });
    }
    // Небольшой «хвост» участников-ИП (без входа).
    for (let i = 0; i < 6; i++) {
      const city = pick(['Казань', 'Самара', 'Екатеринбург', 'Краснодар', 'Новосибирск', 'Хабаровск']);
      const c = findCity(city);
      const id = await user(null, `ip-${i + 1}@${DEMO_DOMAIN}`, 'ip', 'user', `ИП-участник ${i + 1} (демо)`, c.region, c.name, 30 + Math.floor(rand() * 200), lockedHash);
      const o = await org(`synthIp${i}`, 'ip', `ИП Демо-участник ${i + 1}`, `ИП Демо-участник ${i + 1}`, 'ИП', c.region, 'Грузоперевозки', 3, 2 + Math.floor(rand() * 5));
      await t.insert('organization_members', { organization_id: o, user_id: id, member_role: 'owner', created_at: daysAgo(30, base) });
      await vehicle(id, o, { make: 'ГАЗ', model: 'ГАЗон NEXT CNG', year: 2022, vehicleType: 'Грузовой (до 12 т)', fuelType: 'cng', cylinderCount: 6, cylinderVolumeL: 80, consumptionValue: 26, monthlyMileageKm: 4000, quantity: 1 + Math.floor(rand() * 4) });
    }

    // --- Станции и план развития ---
    for (const [name, kind, fuels, status, region, lat, lng, address, dispensers, cap, unit, hours, photo, year, category] of STATIONS) {
      const id = uuid();
      const created = daysAgo(150, base);
      await t.insert('stations', {
        id, name, kind, fuels, status, operator_name: 'Демонстрационный оператор (вымышленный)', address, region, lat, lng, service_radius_km: kind === 'pagz' ? 40 : null,
        dispensers, capacity_value: cap, capacity_unit: unit, hours, hours_confirmed: 0, photo_key: photo,
        description: kind === 'pagz' ? 'Передвижной автомобильный газозаправщик: работает по графику в указанной зоне, точное место стоянки меняется.' : 'Демонстрационная запись для показа работы карты. Не является реальным объектом.',
        source_name: 'Демонстрационный набор GAS CONNECT (вымышленные данные)', source_url: null, data_updated_at: daysAgo(Math.floor(rand() * 40), base), is_demo: 1, created_at: created, updated_at: created,
      });
      await t.insert('station_development_plans', {
        id: uuid(), station_id: id, planned_year: year, category, published: 1,
        basis: status === 'operational' ? 'Действующий объект (демо)' : status === 'construction' ? 'Демо: объект в стадии строительства' : 'Демо: рассматривается оператором по данным о спросе на платформе',
        source_name: 'Демонстрационный набор GAS CONNECT', created_at: created, updated_at: created,
      });
      if (status === 'operational' && rand() < 0.3) ids.favStation = ids.favStation || id;
    }

    // --- Инициативы, голоса, комментарии ---
    const proposalIds = [];
    for (const [title, region, settlement, highway, lat, lng, kind, status, justification, freq, transport, nearest] of PROPOSALS) {
      const id = uuid();
      const created = daysAgo(20 + Math.floor(rand() * 60), base);
      const author = pick(synth).id;
      await t.insert('station_proposals', {
        id, author_id: author, title: `${title} (демо)`, region, settlement, highway, lat, lng, justification, travel_frequency: freq, transport_type: transport,
        has_alternatives: 0, distance_to_nearest_km: nearest, preferred_kind: kind, author_vehicles: 1, author_fuel: kind === 'cryo' ? 'lng' : 'cng', status,
        moderation_note: status === 'rejected' ? 'Дублирует действующую демо-станцию в 6 км.' : null,
        photo_key: { cryo: 'lng-station', pagz: 'trucks-road', modular: 'cng-dispenser', agnks: 'highway' }[kind], is_demo: 1, created_at: created, updated_at: created,
      });
      await t.insert('status_history', { id: uuid(), entity_type: 'proposal', entity_id: id, from_status: null, to_status: 'pending', comment: 'Создана пользователем', created_at: created });
      if (status !== 'pending') await t.insert('status_history', { id: uuid(), entity_type: 'proposal', entity_id: id, from_status: 'pending', to_status: status === 'under_review' ? 'published' : status, comment: status === 'rejected' ? 'Дублирует действующую демо-станцию' : 'Прошла модерацию', actor_id: ids.operator, created_at: daysAgo(15, base) });
      if (status === 'under_review') await t.insert('status_history', { id: uuid(), entity_type: 'proposal', entity_id: id, from_status: 'published', to_status: 'under_review', comment: 'Набрано достаточно голосов, участок передан на рассмотрение', actor_id: ids.operator, created_at: daysAgo(5, base) });
      proposalIds.push({ id, status, region, lat, lng, kind });
    }
    const votable = proposalIds.filter((p) => ['published', 'under_review'].includes(p.status));
    const voted = new Set();
    const vote = async (pid, uid, orgId, vehicles, fuel) => {
      const k = `${pid}:${uid}`;
      if (voted.has(k)) return;
      voted.add(k);
      await t.insert('votes', { proposal_id: pid, user_id: uid, organization_id: orgId, vehicles_count: vehicles, fuel_type: fuel, trips_per_month: Math.round(rand() * 10), created_at: daysAgo(Math.floor(rand() * 20), base) });
    };
    for (const s of synth) {
      for (const p of votable) {
        const d = Math.hypot(s.near[0] - p.lat, (s.near[1] - p.lng) * 0.6);
        const prob = d < 4 ? 0.55 : d < 10 ? 0.12 : 0.02;
        if (rand() < prob) await vote(p.id, s.id, null, 1, p.kind === 'cryo' ? 'lng' : 'cng');
      }
    }
    const byTitle = (part) => proposalIds[PROPOSALS.findIndex((x) => x[0].includes(part))];
    await vote(byTitle('Комсомольск').id, ids.person, null, 1, 'cng');
    await vote(byTitle('А-370').id, ids.company, ids.coOrg, 18, 'lng');
    await vote(byTitle('Находка').id, ids.company, ids.coOrg, 12, 'cng');
    await vote(byTitle('Набережные').id, ids.company2, ids.c2Org, 30, 'cng');
    await vote(byTitle('Набережные').id, c3User, ids.c3Org, 15, 'cng');
    await vote(byTitle('Великий Новгород').id, ids.ip, ids.ipOrg, 4, 'cng');
    ids.proposalKomsomolsk = byTitle('Комсомольск').id;
    ids.proposalPending = byTitle('Псков').id;

    const comments = [
      [byTitle('Комсомольск').id, synth[0].id, 'Поддерживаю! Езжу раз в две недели, обратно приходится на бензине.'],
      [byTitle('Комсомольск').id, synth[1].id, 'Важно, чтобы станция работала круглосуточно — многие выезжают рано утром.'],
      [byTitle('А-370').id, ids.company, 'Наш парк на СПГ — 18 тягачей, готовы обсуждать долгосрочный договор при появлении точки на трассе.'],
      [byTitle('Набережные').id, ids.company2, 'Подтверждаем интерес: 30 тягачей на КПГ проходят этот участок ежедневно.'],
    ];
    for (const [pid, uid, body] of comments) await t.insert('comments', { id: uuid(), proposal_id: pid, user_id: uid, body, status: 'visible', is_demo: 1, created_at: daysAgo(Math.floor(rand() * 10), base) });
    await t.insert('comments', { id: uuid(), proposal_id: byTitle('Великий Новгород').id, user_id: synth[2].id, body: 'Подробности на моём сайте https://example.com — там всё расписано.', status: 'pending', is_demo: 1, created_at: daysAgo(1, base) });

    // --- Коммерческие предложения и договорённости ---
    const offer = async (orgId, by, status, fields, history) => {
      const id = uuid();
      const created = daysAgo(40, base);
      const details = {
        orgName: fields.orgName, orgInn: fields.orgInn, orgRegion: fields.orgRegion, representative: fields.representative, contactEmail: fields.contactEmail, contactPhone: fields.contactPhone || null,
        activity: fields.activity, makesModels: fields.makesModels, fuelTypesNow: fields.fuelTypesNow, avgMileageKm: fields.avgMileageKm, conversionTimeline: fields.conversionTimeline,
        mainDirections: fields.mainDirections, tripFrequency: fields.tripFrequency, avgDistanceKm: fields.avgDistanceKm, alternativePaths: fields.alternativePaths || null,
        seasonalLimits: fields.seasonalLimits || null, weightLimits: fields.weightLimits || null, unavailableSections: null, mandatoryStops: fields.mandatoryStops || null,
        underservedAreas: fields.underservedAreas || null, deliveryTerms: fields.deliveryTerms || null, restrictions: null, locationWishes: fields.locationWishes || null, comments: fields.comments || null, specialRequirements: null,
      };
      await t.insert('commercial_offers', {
        id, organization_id: orgId, created_by: by, status, title: fields.title, fuel_type: fields.fuelType, volume_unit: fields.volumeUnit, monthly_volume: fields.monthlyVolume,
        annual_volume: fields.monthlyVolume * 12, min_guaranteed_volume: fields.minGuaranteed || null, term_months: fields.termMonths, vehicles_total: fields.vehiclesTotal,
        vehicles_convertible: fields.vehiclesConvertible, main_region: fields.orgRegion, details: JSON.stringify(details), submitted_at: status === 'draft' ? null : daysAgo(35, base),
        is_demo: 1, created_at: created, updated_at: daysAgo(history.length ? 3 : 40, base),
      });
      let prev = null;
      let day = 40;
      for (const [to, comment, side] of history) {
        await t.insert('status_history', { id: uuid(), entity_type: 'offer', entity_id: id, from_status: prev, to_status: to, comment, actor_id: side === 'operator' ? ids.operator : by, created_at: daysAgo(day, base) });
        if (comment && side === 'operator') await t.insert('offer_messages', { id: uuid(), offer_id: id, author_id: ids.operator, author_side: 'operator', body: comment, created_at: daysAgo(day, base) });
        prev = to;
        day -= 8;
      }
      return id;
    };
    const coOffer = await offer(ids.coOrg, ids.company, 'needs_info', {
      title: 'Поставка СПГ — Приморский край, 180 000 кг/мес. (демо)', orgName: 'ООО «Демо-Логистик Восток»', orgRegion: 'Приморский край', representative: 'Кравцов И. П.', contactEmail: DEMO_ACCOUNTS.company,
      activity: 'Магистральные грузоперевозки', makesModels: 'КАМАЗ 54901 (СПГ), КАМАЗ 65115 (КПГ), КАМАЗ 5490 (дизель)', fuelTypesNow: 'СПГ, КПГ, дизель', avgMileageKm: 9500, conversionTimeline: '34 тягача — в течение 2027–2028 гг. при наличии заправки СПГ на А-370',
      mainDirections: 'Владивосток — Уссурийск — Хабаровск (А-370)', tripFrequency: '36 рейсов в месяц', avgDistanceKm: 760, alternativePaths: 'Отсутствуют', seasonalLimits: 'Весенние ограничения нагрузки на ось', underservedAreas: 'Участок Уссурийск — Хабаровск: нет заправки СПГ',
      locationWishes: 'Район Дальнереченска или Бикина', deliveryTerms: 'Заправка по топливным картам, ежемесячные расчёты', fuelType: 'lng', volumeUnit: 'кг', monthlyVolume: 180000, minGuaranteed: 120000, termMonths: 60, vehiclesTotal: 64, vehiclesConvertible: 34,
    }, [['draft', 'Черновик создан', 'client'], ['submitted', 'Предложение отправлено оператору', 'client'], ['in_review', 'Предложение принято к рассмотрению', 'operator'], ['needs_info', 'Уточните, пожалуйста, график перевода дизельных тягачей по кварталам и готовность к минимальному гарантированному объёму с 2028 года.', 'operator']]);
    const c2Offer = await offer(ids.c2Org, ids.company2, 'preliminarily_approved', {
      title: 'Поставка КПГ — коридор М-7, 260 000 м³/мес. (демо)', orgName: 'АО «Тестовые Перевозки Центр»', orgRegion: 'Нижегородская область', representative: 'Орлов Д.', contactEmail: DEMO_ACCOUNTS.company2,
      activity: 'Междугородние грузоперевозки', makesModels: 'Scania G340 CNG, КАМАЗ 5490 NEO (КПГ)', fuelTypesNow: 'КПГ', avgMileageKm: 11400, conversionTimeline: 'Парк уже на КПГ',
      mainDirections: 'Москва — Нижний Новгород — Казань — Набережные Челны (М-7)', tripFrequency: 'Ежедневно', avgDistanceKm: 420, mandatoryStops: 'Казань (отдых водителей)', underservedAreas: 'Выезд из Набережных Челнов на восток',
      deliveryTerms: 'Топливные карты, фиксированная скидка от объёма', fuelType: 'cng', volumeUnit: 'м³', monthlyVolume: 260000, minGuaranteed: 200000, termMonths: 36, vehiclesTotal: 52, vehiclesConvertible: 0,
    }, [['draft', 'Черновик создан', 'client'], ['submitted', 'Предложение отправлено оператору', 'client'], ['in_review', 'Принято к рассмотрению', 'operator'], ['preliminarily_approved', 'Условия предварительно согласованы. Подписание договора — вне платформы после проверки контрагента.', 'operator']]);
    await offer(ids.ipOrg, ids.ip, 'draft', {
      title: 'Поставка КПГ — Тверская область (черновик, демо)', orgName: 'ИП Смирнова Е. А. (демо)', orgRegion: 'Тверская область', representative: 'Смирнова Е. А.', contactEmail: DEMO_ACCOUNTS.ip,
      activity: 'Доставка грузов', makesModels: 'ГАЗель NEXT CNG, Ford Transit', fuelTypesNow: 'КПГ, дизель', avgMileageKm: 4800, mainDirections: 'Тверь — Москва', tripFrequency: 'Ежедневно', avgDistanceKm: 180,
      fuelType: 'cng', volumeUnit: 'м³', monthlyVolume: 9000, termMonths: 24, vehiclesTotal: 6, vehiclesConvertible: 2,
    }, [['draft', 'Черновик создан', 'client']]);
    await t.insert('contracts', { id: uuid(), organization_id: ids.c2Org, offer_id: c2Offer, status: 'preliminary', fuel_type: 'cng', volume_unit: 'м³', contracted_monthly_volume: 200000, region: 'Нижегородская область', start_date: '2027-01-01', term_months: 36, note: 'Демо: предварительная договорённость, юридически не обязывает стороны.', created_by: ids.operator, is_demo: 1, created_at: daysAgo(4, base), updated_at: daysAgo(4, base) });
    ids.coOffer = coOffer;

    // --- Избранное и уведомления ---
    await t.insert('favorites', { user_id: ids.person, entity_type: 'proposal', entity_id: ids.proposalKomsomolsk, created_at: daysAgo(20, base) });
    if (ids.favStation) await t.insert('favorites', { user_id: ids.person, entity_type: 'station', entity_id: ids.favStation, created_at: daysAgo(18, base) });
    await t.insert('favorites', { user_id: ids.person, entity_type: 'route', entity_id: ids.personRoute, created_at: daysAgo(18, base) });
    const n = async (uid, kind, title, body, link, d, read = false) => t.insert('notifications', { id: uuid(), user_id: uid, kind, title, body, link, read_at: read ? daysAgo(d - 1, base) : null, created_at: daysAgo(d, base) });
    await n(ids.person, 'proposal.status', 'Инициатива «АГНКС — Комсомольск-на-Амуре» опубликована', 'Голосование открыто — расскажите о ней попутчикам.', `/vote/${ids.proposalKomsomolsk}`, 12, true);
    await n(ids.person, 'station.on_route', 'На вашем маршруте запланирован новый объект', 'Демо-уведомление: так выглядит сообщение о станции на маршруте.', '/plan', 2);
    await n(ids.company, 'offer.status', 'Статус предложения изменён: Требуется уточнение', 'Уточните график перевода дизельных тягачей по кварталам.', `/account/offers/${coOffer}`, 3);
    await n(ids.company2, 'offer.status', 'Статус предложения изменён: Предварительно согласовано', null, `/account/offers/${c2Offer}`, 4);

    // --- Новости ---
    const news = [
      ['Платформа GAS CONNECT запущена в демонстрационном режиме', 'Водители, предприниматели и транспортные компании могут зарегистрироваться, указать маршруты и проголосовать за новые станции.', 'cng-station', 3,
        'GAS CONNECT — концепция единой цифровой платформы, которая собирает информацию о потребностях пользователей газомоторного транспорта.\n\nНа платформе можно зарегистрировать автомобиль или автопарк, указать регулярные маршруты, найти станции на карте, поддержать строительство новых объектов и направить коммерческое предложение о долгосрочном сотрудничестве.\n\nВсе станции, организации, голоса и показатели в текущей версии — демонстрационные и не отражают реальных планов какой-либо компании.'],
      ['Как устроено голосование за новые станции', 'Один пользователь — один голос; голоса не считаются гарантированным спросом.', 'highway', 7,
        'Поддержать инициативу могут только пользователи с подтверждённым адресом электронной почты. Проверка «один голос на инициативу» выполняется на сервере.\n\nДля оценки участков оператор использует три уровня спроса: интерес (голоса и предложения), расчётный спрос (по автопаркам и маршрутам) и договорной спрос (подтверждённые договорённости). Эти показатели не смешиваются в одно число.'],
      ['Объединение спроса: несколько перевозчиков на одном участке', 'Платформа показывает, когда маршруты разных компаний проходят через одну точку, и считает автомобили без двойного учёта.', 'trucks-road', 12,
        'Если через предлагаемую точку проходят маршруты нескольких организаций, платформа суммирует их автомобили и расчётную потребность в газе. Автомобиль учитывается один раз, даже если через точку проходят несколько его маршрутов.\n\nТакой подход помогает оператору увидеть участки, где строительство станции может быть оправдано совместным спросом.'],
      ['Демо: обновлены данные о планируемых объектах', 'В разделе «План развития» разделены подтверждённые объекты, объявленные проекты, проекты на рассмотрении и инициативы пользователей.', 'compressor', 20,
        'Раздел «План развития газозаправочной сети» показывает объекты по годам. Каждая запись содержит категорию, основание включения в план и источник данных.\n\nПользовательские инициативы отображаются отдельно и не являются официальными планами.'],
    ];
    for (const [title, summary, photo, d, body] of news) {
      const id = uuid();
      await t.insert('news', { id, slug: `demo-${id.slice(0, 8)}`, title, summary, body, photo_key: photo, status: 'published', published_at: daysAgo(d, base), author_id: ids.operator, is_demo: 1, created_at: daysAgo(d, base), updated_at: daysAgo(d, base) });
    }
    await t.insert('feedback', { id: uuid(), name: 'Демо-пользователь', email: `participant-001@${DEMO_DOMAIN}`, topic: 'data_error', message: 'Демо-обращение: на карте у станции «Тюмень» указаны неверные часы работы.', status: 'new', created_at: daysAgo(2, base) });
    await t.insert('audit_logs', { id: uuid(), actor_id: ids.operator, action: 'seed.demo_loaded', entity_type: 'system', details: JSON.stringify({ note: 'Загружены демонстрационные данные' }), created_at: new Date(base).toISOString() });
  });
  return { skipped: false, ids };
}
