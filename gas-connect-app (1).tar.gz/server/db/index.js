// Единый интерфейс доступа к БД для SQLite (node:sqlite) и PostgreSQL (собственный клиент).
// В SQL используются плейсхолдеры «?», для PostgreSQL они автоматически превращаются в $1..$n.
import fs from 'node:fs';
import path from 'node:path';
import { PgPool } from './pg-client.js';

function toPgPlaceholders(sql) {
  let i = 0;
  let out = '';
  let inStr = false;
  for (let k = 0; k < sql.length; k++) {
    const ch = sql[k];
    if (ch === "'") inStr = !inStr;
    if (ch === '?' && !inStr) { out += '$' + (++i); continue; }
    out += ch;
  }
  return out;
}

function normalizeSqliteParam(v) {
  if (v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v instanceof Date) return v.toISOString();
  if (v !== null && typeof v === 'object') return JSON.stringify(v);
  return v;
}

class Mutex {
  constructor() { this.p = Promise.resolve(); }
  lock() {
    let release;
    const next = new Promise((r) => { release = r; });
    const prev = this.p;
    this.p = prev.then(() => next);
    return prev.then(() => release);
  }
}

class SqliteDb {
  constructor(file) {
    this.dialect = 'sqlite';
    this.file = file;
  }
  async init() {
    const { DatabaseSync } = await import('node:sqlite');
    if (this.file !== ':memory:') fs.mkdirSync(path.dirname(this.file), { recursive: true });
    this.db = new DatabaseSync(this.file);
    this.db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
    this.cache = new Map();
    this.mutex = new Mutex();
    return this;
  }
  _stmt(sql) {
    let s = this.cache.get(sql);
    if (!s) {
      s = this.db.prepare(sql);
      if (this.cache.size > 500) this.cache.clear();
      this.cache.set(sql, s);
    }
    return s;
  }
  _exec(sql, params = []) {
    const p = params.map(normalizeSqliteParam);
    try {
      const st = this._stmt(sql);
      if (/^\s*(select|with|pragma)/i.test(sql)) return { rows: st.all(...p).map((r) => ({ ...r })), rowCount: 0 };
      const r = st.run(...p);
      return { rows: [], rowCount: Number(r.changes) };
    } catch (e) {
      if (/UNIQUE constraint failed/i.test(e.message)) e.code = 'UNIQUE';
      else if (/FOREIGN KEY constraint failed/i.test(e.message)) e.code = 'FOREIGN_KEY';
      throw e;
    }
  }
  async query(sql, params) {
    const release = await this.mutex.lock();
    try { return this._exec(sql, params); } finally { release(); }
  }
  async exec(sqlScript) {
    const release = await this.mutex.lock();
    try { this.db.exec(sqlScript); } finally { release(); }
  }
  async tx(fn) {
    const release = await this.mutex.lock();
    const t = makeApi({ dialect: 'sqlite', query: async (sql, params) => this._exec(sql, params) });
    try {
      this.db.exec('BEGIN IMMEDIATE');
      const result = await fn(t);
      this.db.exec('COMMIT');
      return result;
    } catch (e) {
      try { this.db.exec('ROLLBACK'); } catch { /* ignore */ }
      throw e;
    } finally { release(); }
  }
  async close() { this.db.close(); }
}

class PostgresDb {
  constructor(url, poolSize) {
    this.dialect = 'postgres';
    this.pool = new PgPool(url, poolSize);
  }
  async init() {
    await this.pool.query('SELECT 1', []);
    return this;
  }
  async query(sql, params = []) {
    return this.pool.query(toPgPlaceholders(sql), params);
  }
  async exec(sqlScript) {
    const c = await this.pool.acquire();
    try { await c.simpleQuery(sqlScript); } finally { this.pool.release(c); }
  }
  async tx(fn) {
    const c = await this.pool.acquire();
    const t = makeApi({ dialect: 'postgres', query: (sql, params = []) => c.query(toPgPlaceholders(sql), params) });
    try {
      await c.query('BEGIN', []);
      const result = await fn(t);
      await c.query('COMMIT', []);
      return result;
    } catch (e) {
      try { await c.query('ROLLBACK', []); } catch { /* ignore */ }
      throw e;
    } finally { this.pool.release(c); }
  }
  async close() { await this.pool.end(); }
}

function makeApi(base) {
  const api = {
    dialect: base.dialect,
    query: base.query,
    async all(sql, params = []) { return (await base.query(sql, params)).rows; },
    async get(sql, params = []) { return (await base.query(sql, params)).rows[0] || null; },
    async run(sql, params = []) { return (await base.query(sql, params)).rowCount; },
    async count(sql, params = []) {
      const row = (await base.query(sql, params)).rows[0];
      return row ? Number(Object.values(row)[0]) || 0 : 0;
    },
    async insert(table, obj) {
      const keys = Object.keys(obj).filter((k) => obj[k] !== undefined);
      const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${keys.map(() => '?').join(', ')})`;
      await base.query(sql, keys.map((k) => obj[k]));
      return obj;
    },
    async update(table, id, obj, idCol = 'id') {
      const keys = Object.keys(obj).filter((k) => obj[k] !== undefined);
      if (!keys.length) return 0;
      const sql = `UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE ${idCol} = ?`;
      return (await base.query(sql, [...keys.map((k) => obj[k]), id])).rowCount;
    },
  };
  return api;
}

export async function openDatabase(dbConfig) {
  const impl = dbConfig.driver === 'postgres'
    ? await new PostgresDb(dbConfig.url, dbConfig.poolSize).init()
    : await new SqliteDb(dbConfig.sqlitePath).init();
  const api = makeApi({ dialect: impl.dialect, query: (sql, params) => impl.query(sql, params) });
  api.exec = (s) => impl.exec(s);
  api.tx = (fn) => impl.tx(fn);
  api.close = () => impl.close();
  return api;
}

export { toPgPlaceholders };
