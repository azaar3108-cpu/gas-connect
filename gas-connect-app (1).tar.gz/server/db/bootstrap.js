// Первичная настройка при запуске сервера — для хостингов без доступа к консоли (Amvera, Render и т.п.).
//  • AUTO_SEED_DEMO=true  — если база пустая, загрузить демонстрационные данные (станции, инициативы и т.п.,
//    всё помечено как тестовое). При ALLOW_DEMO_LOGIN=false демо-аккаунтам ставится случайный пароль,
//    поэтому войти под ними невозможно, а общеизвестный тестовый пароль на сервер не попадает.
//  • ADMIN_EMAIL + ADMIN_PASSWORD — создать администратора, если пользователя с таким e-mail ещё нет.
//    Существующий аккаунт не изменяется, поэтому пароль, сменённый в личном кабинете, не сбрасывается при перезапуске.
import { hashPassword, uuid, randomToken } from '../lib/security.js';
import { seedDemo } from './seed-data.js';

export async function bootstrap(db, config, log = console.log) {
  if (config.autoSeedDemo && config.allowDemoSeed) {
    const users = await db.count('SELECT COUNT(*) AS n FROM users');
    if (!users) {
      const password = config.allowDemoLogin ? (config.seedPassword || 'GasDemo2026!') : randomToken(24);
      const res = await seedDemo(db, { password });
      if (!res.skipped) log(`[первичная настройка] Загружены демонстрационные данные${config.allowDemoLogin ? '' : ' (вход демо-аккаунтов отключён)'}.`);
    }
  }

  const { email, password } = config.bootstrapAdmin;
  if (email && password) {
    const existing = await db.get('SELECT id FROM users WHERE email = ?', [email]);
    if (!existing) {
      const { checkPasswordPolicy } = await import('../api/auth.js');
      try {
        checkPasswordPolicy(password, email);
      } catch (e) {
        log(`[первичная настройка] Администратор НЕ создан: ${e.message || 'пароль не соответствует требованиям'} (нужно не менее 10 символов, буквы и цифры).`);
        return;
      }
      const now = new Date().toISOString();
      const id = uuid();
      await db.insert('users', { id, email, password_hash: await hashPassword(password), role: 'admin', account_type: 'staff', status: 'active', email_verified_at: now, created_at: now, updated_at: now });
      await db.insert('profiles', { user_id: id, full_name: 'Администратор платформы', region: null, updated_at: now });
      log(`[первичная настройка] Создан администратор ${email}.`);
    }
  }
}
