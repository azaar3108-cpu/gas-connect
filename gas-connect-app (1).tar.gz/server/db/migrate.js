// Применение SQL-миграций из migrations/<dialect>/NNN_*.sql с учётом уже применённых.
import fs from 'node:fs';
import path from 'node:path';
import { ROOT } from '../config.js';

export async function migrate(db, { log = () => {} } = {}) {
  await db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TEXT NOT NULL)`);
  const dir = path.join(ROOT, 'migrations', db.dialect);
  const files = fs.readdirSync(dir).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
  const applied = new Set((await db.all('SELECT id FROM schema_migrations')).map((r) => r.id));
  const done = [];
  for (const f of files) {
    if (applied.has(f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    // Миграция и отметка о ней выполняются атомарно.
    if (db.dialect === 'postgres') {
      await db.exec(`BEGIN;\n${sql}\nINSERT INTO schema_migrations (id, applied_at) VALUES ('${f}', '${new Date().toISOString()}');\nCOMMIT;`);
    } else {
      await db.exec(`BEGIN;\n${sql}\nINSERT INTO schema_migrations (id, applied_at) VALUES ('${f}', '${new Date().toISOString()}');\nCOMMIT;`);
    }
    log(`Применена миграция ${f}`);
    done.push(f);
  }
  return done;
}

export async function dropAll(db) {
  if (db.dialect === 'postgres') {
    await db.exec('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  } else {
    const objs = await db.all("SELECT type, name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' AND type IN ('table','view')");
    const stmts = ['PRAGMA foreign_keys = OFF;'];
    for (const o of objs.filter((x) => x.type === 'view')) stmts.push(`DROP VIEW IF EXISTS ${o.name};`);
    for (const o of objs.filter((x) => x.type === 'table')) stmts.push(`DROP TABLE IF EXISTS ${o.name};`);
    stmts.push('PRAGMA foreign_keys = ON;');
    await db.exec(stmts.join('\n'));
  }
}
