// Минимальный клиент PostgreSQL (протокол v3) без внешних зависимостей.
// Поддерживает: SCRAM-SHA-256 / MD5 / cleartext, TLS (sslmode=require|verify-full),
// расширенный протокол запросов с параметрами, простой протокол (для миграций), пул соединений.
import net from 'node:net';
import tls from 'node:tls';
import crypto from 'node:crypto';

const TYPE_PARSERS = {
  16: (v) => v === 't', // bool
  20: (v) => Number(v), // int8
  21: (v) => Number(v), // int2
  23: (v) => Number(v), // int4
  700: (v) => Number(v), // float4
  701: (v) => Number(v), // float8
  1700: (v) => Number(v), // numeric
  1082: (v) => v, // date
  1114: (v) => new Date(v.replace(' ', 'T') + 'Z').toISOString(), // timestamp
  1184: (v) => new Date(v.replace(' ', 'T').replace(/([+-]\d\d)$/, '$1:00')).toISOString(), // timestamptz
};

export class PgError extends Error {
  constructor(fields) {
    super(fields.M || 'Ошибка PostgreSQL');
    this.name = 'PgError';
    this.severity = fields.S;
    this.pgCode = fields.C;
    this.detail = fields.D;
    this.constraint = fields.n;
    if (fields.C === '23505') this.code = 'UNIQUE';
    else if (fields.C === '23503') this.code = 'FOREIGN_KEY';
  }
}

export function parseDatabaseUrl(url) {
  const u = new URL(url);
  return {
    host: u.hostname || 'localhost',
    port: Number(u.port || 5432),
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: decodeURIComponent(u.pathname.replace(/^\//, '')) || decodeURIComponent(u.username),
    sslmode: u.searchParams.get('sslmode') || 'disable',
  };
}

function cstr(s) {
  return Buffer.concat([Buffer.from(s, 'utf8'), Buffer.from([0])]);
}
function msg(type, body) {
  const head = Buffer.alloc(type ? 5 : 4);
  if (type) {
    head.write(type, 0, 'ascii');
    head.writeInt32BE(body.length + 4, 1);
  } else head.writeInt32BE(body.length + 4, 0);
  return Buffer.concat([head, body]);
}
function int16(n) { const b = Buffer.alloc(2); b.writeInt16BE(n); return b; }
function int32(n) { const b = Buffer.alloc(4); b.writeInt32BE(n); return b; }

function serializeParam(v) {
  if (v === null || v === undefined) return null;
  if (v instanceof Date) return v.toISOString();
  if (typeof v === 'boolean') return v ? '1' : '0';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

export class PgConnection {
  constructor(opts) {
    this.opts = opts;
    this.buf = Buffer.alloc(0);
    this.queue = [];
    this.waiters = [];
    this.dead = false;
    this.busy = false;
  }

  async connect() {
    const { host, port, sslmode } = this.opts;
    let socket = await new Promise((resolve, reject) => {
      const s = net.connect({ host, port });
      s.once('connect', () => resolve(s));
      s.once('error', reject);
    });
    if (sslmode && sslmode !== 'disable') {
      socket.write(msg(null, Buffer.concat([int32(80877103)])));
      const answer = await new Promise((resolve, reject) => {
        socket.once('data', (d) => resolve(String.fromCharCode(d[0])));
        socket.once('error', reject);
      });
      if (answer === 'S') {
        socket = await new Promise((resolve, reject) => {
          const t = tls.connect({ socket, servername: host, rejectUnauthorized: sslmode === 'verify-full' || sslmode === 'verify-ca' });
          t.once('secureConnect', () => resolve(t));
          t.once('error', reject);
        });
      } else if (sslmode === 'require' || sslmode.startsWith('verify')) {
        throw new Error('Сервер PostgreSQL не поддерживает SSL, а sslmode требует его');
      }
    }
    this.socket = socket;
    socket.on('data', (d) => this._onData(d));
    socket.on('error', (e) => this._fail(e));
    socket.on('close', () => this._fail(new Error('Соединение с PostgreSQL закрыто')));

    const params = Buffer.concat([cstr('user'), cstr(this.opts.user), cstr('database'), cstr(this.opts.database), cstr('client_encoding'), cstr('UTF8'), cstr('TimeZone'), cstr('UTC'), Buffer.from([0])]);
    socket.write(msg(null, Buffer.concat([int32(196608), params])));
    await this._authenticate();
    return this;
  }

  _onData(chunk) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    while (this.buf.length >= 5) {
      const len = this.buf.readInt32BE(1);
      if (this.buf.length < 1 + len) break;
      const type = String.fromCharCode(this.buf[0]);
      const body = this.buf.subarray(5, 1 + len);
      this.buf = this.buf.subarray(1 + len);
      if (type === 'N' || type === 'A' || type === 'S') continue; // notice, notification, parameter status
      const w = this.waiters.shift();
      if (w) w.resolve({ type, body });
      else this.queue.push({ type, body });
    }
  }

  _fail(err) {
    if (this.dead) return;
    this.dead = true;
    for (const w of this.waiters.splice(0)) w.reject(err);
  }

  _next() {
    if (this.queue.length) return Promise.resolve(this.queue.shift());
    if (this.dead) return Promise.reject(new Error('Соединение с PostgreSQL недоступно'));
    return new Promise((resolve, reject) => this.waiters.push({ resolve, reject }));
  }

  _write(buf) { this.socket.write(buf); }

  async _authenticate() {
    let scram = null;
    for (;;) {
      const m = await this._next();
      if (m.type === 'E') throw new PgError(parseFields(m.body));
      if (m.type === 'R') {
        const code = m.body.readInt32BE(0);
        if (code === 0) continue; // AuthenticationOk
        if (code === 3) { this._write(msg('p', cstr(this.opts.password))); continue; }
        if (code === 5) {
          const salt = m.body.subarray(4, 8);
          const inner = crypto.createHash('md5').update(this.opts.password + this.opts.user).digest('hex');
          const outer = 'md5' + crypto.createHash('md5').update(Buffer.concat([Buffer.from(inner), salt])).digest('hex');
          this._write(msg('p', cstr(outer)));
          continue;
        }
        if (code === 10) {
          const mechs = m.body.subarray(4).toString('utf8').split('\0').filter(Boolean);
          if (!mechs.includes('SCRAM-SHA-256')) throw new Error('Сервер не предлагает SCRAM-SHA-256');
          const nonce = crypto.randomBytes(18).toString('base64');
          const clientFirstBare = `n=*,r=${nonce}`;
          const clientFirst = Buffer.from('n,,' + clientFirstBare, 'utf8');
          scram = { nonce, clientFirstBare };
          this._write(msg('p', Buffer.concat([cstr('SCRAM-SHA-256'), int32(clientFirst.length), clientFirst])));
          continue;
        }
        if (code === 11) {
          const serverFirst = m.body.subarray(4).toString('utf8');
          const attrs = Object.fromEntries(serverFirst.split(',').map((p) => [p[0], p.slice(2)]));
          if (!attrs.r || !attrs.r.startsWith(scram.nonce)) throw new Error('Некорректный SCRAM nonce');
          const salt = Buffer.from(attrs.s, 'base64');
          const iterations = Number(attrs.i);
          const salted = crypto.pbkdf2Sync(this.opts.password.normalize('NFKC'), salt, iterations, 32, 'sha256');
          const clientKey = crypto.createHmac('sha256', salted).update('Client Key').digest();
          const storedKey = crypto.createHash('sha256').update(clientKey).digest();
          const clientFinalNoProof = `c=biws,r=${attrs.r}`;
          const authMessage = `${scram.clientFirstBare},${serverFirst},${clientFinalNoProof}`;
          const clientSig = crypto.createHmac('sha256', storedKey).update(authMessage).digest();
          const proof = Buffer.from(clientKey.map((b, i) => b ^ clientSig[i]));
          const serverKey = crypto.createHmac('sha256', salted).update('Server Key').digest();
          scram.serverSig = crypto.createHmac('sha256', serverKey).update(authMessage).digest('base64');
          this._write(msg('p', Buffer.from(`${clientFinalNoProof},p=${proof.toString('base64')}`, 'utf8')));
          continue;
        }
        if (code === 12) {
          const final = m.body.subarray(4).toString('utf8');
          const v = final.split(',').find((p) => p.startsWith('v='));
          if (!v || v.slice(2) !== scram.serverSig) throw new Error('Подпись сервера SCRAM не совпала');
          continue;
        }
        throw new Error(`Неподдерживаемый метод аутентификации PostgreSQL: ${code}`);
      }
      if (m.type === 'K') continue;
      if (m.type === 'Z') return;
    }
  }

  async query(sql, params = []) {
    const values = params.map(serializeParam);
    const bindParts = [cstr(''), cstr(''), int16(0), int16(values.length)];
    for (const v of values) {
      if (v === null) bindParts.push(int32(-1));
      else { const b = Buffer.from(v, 'utf8'); bindParts.push(int32(b.length), b); }
    }
    bindParts.push(int16(0));
    this._write(Buffer.concat([
      msg('P', Buffer.concat([cstr(''), cstr(sql), int16(0)])),
      msg('B', Buffer.concat(bindParts)),
      msg('D', Buffer.concat([Buffer.from('P'), cstr('')])),
      msg('E', Buffer.concat([cstr(''), int32(0)])),
      msg('S', Buffer.alloc(0)),
    ]));
    return this._collect();
  }

  async simpleQuery(sql) {
    this._write(msg('Q', cstr(sql)));
    return this._collect();
  }

  async _collect() {
    let fields = null;
    const rows = [];
    let rowCount = 0;
    let error = null;
    for (;;) {
      const m = await this._next();
      switch (m.type) {
        case 'T': fields = parseRowDescription(m.body); break;
        case 'D': if (fields) rows.push(parseDataRow(m.body, fields)); break;
        case 'C': {
          const tag = m.body.toString('utf8', 0, m.body.length - 1);
          const n = Number(tag.split(' ').pop());
          if (!Number.isNaN(n)) rowCount = n;
          break;
        }
        case 'E': error = new PgError(parseFields(m.body)); break;
        case 'Z': if (error) throw error; return { rows, rowCount };
        default: break; // '1','2','n','I','s'
      }
    }
  }

  close() {
    try { this.socket.write(msg('X', Buffer.alloc(0))); this.socket.end(); } catch { /* ignore */ }
    this.dead = true;
  }
}

function parseFields(body) {
  const fields = {};
  let i = 0;
  while (i < body.length && body[i] !== 0) {
    const code = String.fromCharCode(body[i]);
    const end = body.indexOf(0, i + 1);
    fields[code] = body.toString('utf8', i + 1, end);
    i = end + 1;
  }
  return fields;
}

function parseRowDescription(body) {
  const n = body.readInt16BE(0);
  const fields = [];
  let i = 2;
  for (let k = 0; k < n; k++) {
    const end = body.indexOf(0, i);
    const name = body.toString('utf8', i, end);
    i = end + 1;
    const typeOid = body.readInt32BE(i + 6);
    i += 18;
    fields.push({ name, typeOid });
  }
  return fields;
}

function parseDataRow(body, fields) {
  const n = body.readInt16BE(0);
  const row = {};
  let i = 2;
  for (let k = 0; k < n; k++) {
    const len = body.readInt32BE(i);
    i += 4;
    const f = fields[k];
    if (len === -1) { row[f.name] = null; continue; }
    const raw = body.toString('utf8', i, i + len);
    i += len;
    const parser = TYPE_PARSERS[f.typeOid];
    row[f.name] = parser ? parser(raw) : raw;
  }
  return row;
}

export class PgPool {
  constructor(url, size = 10) {
    this.opts = parseDatabaseUrl(url);
    this.size = size;
    this.idle = [];
    this.all = new Set();
    this.waiting = [];
  }

  async acquire() {
    while (this.idle.length) {
      const c = this.idle.pop();
      if (!c.dead) return c;
      this.all.delete(c);
    }
    if (this.all.size < this.size) {
      const c = new PgConnection(this.opts);
      this.all.add(c);
      try { await c.connect(); } catch (e) { this.all.delete(c); throw e; }
      return c;
    }
    return new Promise((resolve) => this.waiting.push(resolve));
  }

  release(c) {
    if (c.dead) { this.all.delete(c); }
    const w = this.waiting.shift();
    if (w) {
      if (c.dead) this.acquire().then(w);
      else w(c);
      return;
    }
    if (!c.dead) this.idle.push(c);
  }

  async query(sql, params) {
    const c = await this.acquire();
    try { return await c.query(sql, params); } finally { this.release(c); }
  }

  async end() {
    for (const c of this.all) c.close();
    this.all.clear();
    this.idle = [];
  }
}
