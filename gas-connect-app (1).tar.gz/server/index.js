// Точка входа: загрузка конфигурации, миграции, запуск HTTP-сервера.
import http from 'node:http';
import { loadDotEnv, buildConfig } from './config.js';
import { openDatabase } from './db/index.js';
import { migrate } from './db/migrate.js';
import { bootstrap } from './db/bootstrap.js';
import { createApp } from './app.js';

loadDotEnv();
const config = buildConfig();
const db = await openDatabase(config.db);
await migrate(db, { log: (m) => console.log(m) });
await bootstrap(db, config);

if (config.production) {
  const demoUsers = await db.count('SELECT COUNT(*) AS n FROM users WHERE is_demo = 1');
  if (demoUsers && !config.allowDemoLogin) console.warn(`[безопасность] В базе ${demoUsers} демонстрационных аккаунтов — вход для них отключён (ALLOW_DEMO_LOGIN=false).`);
  if (config.mail.driver !== 'smtp') console.warn('[почта] В production рекомендуется MAIL_DRIVER=smtp: сейчас письма только записываются в журнал.');
}

const app = createApp({ config, db });
const server = http.createServer((req, res) => { app.handle(req, res); });
server.headersTimeout = 20_000;
server.requestTimeout = 60_000;
server.listen(config.port, config.host, () => {
  console.log(`GAS CONNECT запущен: ${config.appUrl}  (БД: ${config.db.driver}, режим: ${config.env})`);
});

// Периодическая очистка просроченных сессий и токенов.
const cleanup = setInterval(async () => {
  const now = new Date().toISOString();
  try {
    await db.run('DELETE FROM sessions WHERE expires_at < ?', [now]);
    await db.run('DELETE FROM auth_tokens WHERE expires_at < ?', [now]);
    app.limiter.sweep();
  } catch (e) { console.error('Ошибка очистки', e.message); }
}, 3600_000);
cleanup.unref();

const shutdown = async (sig) => {
  console.log(`Получен ${sig}, завершаем работу…`);
  server.close();
  await db.close().catch(() => {});
  process.exit(0);
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
