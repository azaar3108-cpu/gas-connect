Границы стран: world.geo.json (https://github.com/johan/world.geo.json), лицензия UNLICENSE (общественное достояние), данные основаны на Natural Earth (общественное достояние).
