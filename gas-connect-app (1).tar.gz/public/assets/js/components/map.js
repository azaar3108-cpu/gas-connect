// Обёртки над Leaflet: создание карты, маркеры станций и инициатив, выбор точки.
import { stationColor, STATION_COLORS, esc } from '../core.js';

export const RUSSIA_CENTER = [58, 75];

export async function leaflet() {
  for (let i = 0; i < 100 && !window.L; i++) await new Promise((r) => setTimeout(r, 50));
  if (!window.L) throw new Error('Картографическая библиотека не загрузилась');
  return window.L;
}

export async function createMap(el, { center = RUSSIA_CENTER, zoom = 4, scrollWheelZoom = true, dim = true } = {}) {
  const L = await leaflet();
  const map = L.map(el, { zoomControl: true, scrollWheelZoom, worldCopyJump: true, minZoom: 2, preferCanvas: false });
  // Векторная подложка границ стран — видна всегда под тайлами, а без интернета заменяет их.
  map.createPane('basePane');
  map.getPane('basePane').style.zIndex = 150;
  baseLayer(L, map);
  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 18,
    attribution: '&copy; участники <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
  }).addTo(map);
  if (dim) el.classList.add('map-tiles-dim');
  el.style.background = '#0a1236';
  let tileErrors = 0;
  tiles.on('tileerror', () => {
    tileErrors++;
    if (tileErrors === 6) {
      el.classList.remove('map-tiles-dim');
      const note = L.control({ position: 'bottomleft' });
      note.onAdd = () => { const d = L.DomUtil.create('div'); d.style.cssText = 'background:#13204d;color:#f8e2b8;padding:6px 10px;border-radius:6px;font-size:12px;border:1px solid rgba(231,170,68,.4)'; d.textContent = 'Нет связи с OpenStreetMap — показана упрощённая карта границ.'; return d; };
      note.addTo(map);
    }
  });
  map.setView(center, zoom);
  setTimeout(() => map.invalidateSize(), 60);
  return map;
}

let geoCache = null;
async function baseLayer(L, map) {
  try {
    geoCache ||= fetch('/assets/data/countries.geo.json').then((r) => r.json());
    const geo = await geoCache;
    L.geoJSON(geo, {
      pane: 'basePane',
      interactive: false,
      style: (f) => (f.properties.id === 'RUS'
        ? { color: '#47c8f5', weight: 1.2, opacity: .55, fillColor: '#1a2b62', fillOpacity: 1 }
        : { color: '#2c3d75', weight: .8, opacity: .8, fillColor: '#131f4a', fillOpacity: 1 }),
    }).addTo(map);
  } catch { /* подложка необязательна */ }
}

export function stationIcon(L, s, { active = false } = {}) {
  const color = stationColor(s);
  return L.divIcon({ className: '', html: `<span class="gc-marker ${active ? 'pulse' : ''}" style="background:${color}"></span>`, iconSize: [18, 18], iconAnchor: [9, 9] });
}
export function proposalIcon(L) {
  return L.divIcon({ className: '', html: `<span class="gc-marker proposal" style="background:${STATION_COLORS.proposal}"></span>`, iconSize: [16, 16], iconAnchor: [8, 8] });
}
export function pointIcon(L, color = '#47c8f5', label = '') {
  return L.divIcon({ className: '', html: `<span style="display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:${color};border:3px solid #fff;color:#0b1230;font-weight:700;font-size:12px;box-shadow:0 2px 10px rgba(0,0,0,.5)">${esc(label)}</span>`, iconSize: [26, 26], iconAnchor: [13, 13] });
}

/** Карта для выбора точки (клик ставит маркер и вызывает onPick). */
export async function pickerMap(el, { lat, lng, onPick }) {
  const L = await leaflet();
  const has = Number.isFinite(lat) && Number.isFinite(lng);
  const map = await createMap(el, { center: has ? [lat, lng] : RUSSIA_CENTER, zoom: has ? 6 : 3 });
  let marker = has ? L.marker([lat, lng], { icon: pointIcon(L, '#e9eef9') }).addTo(map) : null;
  map.on('click', (e) => {
    const p = [Math.round(e.latlng.lat * 1e5) / 1e5, Math.round(L.Util.wrapNum(e.latlng.lng, [-180, 180], true) * 1e5) / 1e5];
    if (marker) marker.setLatLng(p); else marker = L.marker(p, { icon: pointIcon(L, '#e9eef9') }).addTo(map);
    onPick(p[0], p[1]);
  });
  return { map, setPoint(la, ln) { const p = [la, ln]; if (marker) marker.setLatLng(p); else marker = L.marker(p, { icon: pointIcon(L, '#e9eef9') }).addTo(map); map.setView(p, Math.max(map.getZoom(), 6)); } };
}

export function legendHtml() {
  return `<div class="legend">
    <span><i class="dot" style="background:${STATION_COLORS.operational}"></i>Действующие</span>
    <span><i class="dot" style="background:${STATION_COLORS.mobile}"></i>Модульные и мобильные</span>
    <span><i class="dot" style="background:${STATION_COLORS.construction}"></i>Строящиеся</span>
    <span><i class="dot" style="background:${STATION_COLORS.planned}"></i>Проектируемые</span>
    <span><i class="dot" style="background:${STATION_COLORS.proposal};border-radius:3px"></i>Предложения пользователей</span>
  </div>`;
}
