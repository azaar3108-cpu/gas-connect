// Простые SVG-графики без внешних библиотек.
import { html, raw, esc, fmt } from '../core.js';

export const PALETTE = ['#47c8f5', '#008ed6', '#9b7bff', '#22a779', '#e7aa44', '#f08a3c', '#f06272', '#7fa3ff'];

/** Горизонтальные полосы: [{label, value, note}] */
export function bars(items, { unit = '', max = null, colors = null } = {}) {
  if (!items.length) return html`<div class="empty small">Нет данных</div>`;
  const m = max ?? Math.max(...items.map((x) => x.value), 1);
  return html`<div class="bars">${items.map((x, i) => html`<div class="row"><span class="name" title="${x.label}">${x.label}</span><div class="track"><div class="fill" style="width:${Math.max(2, (x.value / m) * 100).toFixed(1)}%;${colors ? `background:${colors[i % colors.length]}` : ''}"></div></div><b class="nowrap">${fmt(x.value)}${unit ? ' ' + unit : ''}</b></div>`)}</div>`;
}

/** Кольцевая диаграмма: [{label, value}] */
export function donut(items, { size = 200, title = '' } = {}) {
  const total = items.reduce((a, x) => a + x.value, 0);
  if (!total) return html`<div class="empty small">Нет данных</div>`;
  const r = 70, c = 2 * Math.PI * r;
  let acc = 0;
  const arcs = items.map((x, i) => {
    const len = (x.value / total) * c;
    const s = `<circle r="${r}" cx="100" cy="100" fill="none" stroke="${PALETTE[i % PALETTE.length]}" stroke-width="26" stroke-dasharray="${len.toFixed(2)} ${(c - len).toFixed(2)}" stroke-dashoffset="${(-acc).toFixed(2)}" transform="rotate(-90 100 100)"><title>${esc(x.label)}: ${fmt(x.value)}</title></circle>`;
    acc += len;
    return s;
  }).join('');
  return html`<div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap">
    <svg class="chart" viewBox="0 0 200 200" style="width:${size}px;max-width:100%" role="img" aria-label="${title}">${raw(arcs)}<text x="100" y="96" text-anchor="middle" class="lbl" style="font-size:26px;font-weight:600">${fmt(total)}</text><text x="100" y="118" text-anchor="middle">${title}</text></svg>
    <div class="legend-row" style="flex-direction:column">${items.map((x, i) => html`<span><i style="background:${PALETTE[i % PALETTE.length]}"></i>${x.label} — <b style="color:#fff">${fmt(x.value)}</b> (${fmt((x.value / total) * 100, 0)}%)</span>`)}</div>
  </div>`;
}

/** Столбчатая диаграмма с несколькими сериями (накопительно): labels[], series [{name, values[]}] */
export function columns(labels, series, { height = 220, stacked = true } = {}) {
  const W = 640, H = height, pad = { l: 40, r: 10, t: 10, b: 28 };
  const n = labels.length;
  const totals = labels.map((_, i) => (stacked ? series.reduce((a, s) => a + (s.values[i] || 0), 0) : Math.max(...series.map((s) => s.values[i] || 0))));
  const max = Math.max(1, ...totals);
  const bw = ((W - pad.l - pad.r) / n) * 0.62;
  const x = (i) => pad.l + ((W - pad.l - pad.r) / n) * (i + 0.5);
  const y = (v) => H - pad.b - (v / max) * (H - pad.t - pad.b);
  let out = '';
  for (let k = 0; k <= 4; k++) {
    const v = (max / 4) * k;
    out += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(v)}" y2="${y(v)}" stroke="rgba(174,187,213,.12)"/><text x="${pad.l - 6}" y="${y(v) + 4}" text-anchor="end">${fmt(v)}</text>`;
  }
  labels.forEach((lab, i) => {
    let base = 0;
    series.forEach((s, j) => {
      const v = s.values[i] || 0;
      if (!v) return;
      const y0 = y(base), y1 = y(base + v);
      out += `<rect x="${x(i) - bw / 2}" y="${y1}" width="${bw}" height="${Math.max(0, y0 - y1)}" rx="3" fill="${PALETTE[j % PALETTE.length]}"><title>${esc(s.name)} · ${esc(lab)}: ${fmt(v)}</title></rect>`;
      if (stacked) base += v;
    });
    if (n <= 14 || i % 2 === 0) out += `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(lab)}</text>`;
  });
  return html`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img">${raw(out)}</svg>
    <div class="legend-row" style="margin-top:8px">${series.map((s, j) => html`<span><i style="background:${PALETTE[j % PALETTE.length]}"></i>${s.name}</span>`)}</div>`;
}

/** Линии (например, накопленный денежный поток по сценариям): labels[], series [{name, values[], color}] */
export function lines(labels, series, { height = 260, money = false } = {}) {
  const W = 680, H = height, pad = { l: 64, r: 12, t: 12, b: 28 };
  const all = series.flatMap((s) => s.values);
  let min = Math.min(0, ...all), max = Math.max(0, ...all);
  if (min === max) max = min + 1;
  const x = (i) => pad.l + ((W - pad.l - pad.r) * i) / Math.max(1, labels.length - 1);
  const y = (v) => H - pad.b - ((v - min) / (max - min)) * (H - pad.t - pad.b);
  const f = (v) => (money ? `${fmt(v / 1e6, 0)} млн` : fmt(v));
  let out = '';
  for (let k = 0; k <= 4; k++) {
    const v = min + ((max - min) / 4) * k;
    out += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(v)}" y2="${y(v)}" stroke="rgba(174,187,213,.12)"/><text x="${pad.l - 6}" y="${y(v) + 4}" text-anchor="end">${f(v)}</text>`;
  }
  out += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(0)}" y2="${y(0)}" stroke="rgba(255,255,255,.35)" stroke-dasharray="4 4"/>`;
  labels.forEach((l, i) => { if (labels.length <= 16 || i % 2 === 0) out += `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(l)}</text>`; });
  series.forEach((s, j) => {
    const col = s.color || PALETTE[j % PALETTE.length];
    const d = s.values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
    out += `<path d="${d}" fill="none" stroke="${col}" stroke-width="2.5" stroke-linejoin="round"/>`;
    s.values.forEach((v, i) => { out += `<circle cx="${x(i)}" cy="${y(v)}" r="3" fill="${col}"><title>${esc(s.name)}, ${esc(labels[i])}: ${f(v)}</title></circle>`; });
  });
  return html`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img">${raw(out)}</svg>
    <div class="legend-row" style="margin-top:8px">${series.map((s, j) => html`<span><i style="background:${s.color || PALETTE[j % PALETTE.length]}"></i>${s.name}</span>`)}</div>`;
}
