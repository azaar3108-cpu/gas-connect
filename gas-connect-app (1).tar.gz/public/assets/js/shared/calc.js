// Общие расчётные функции (используются и сервером, и браузером).
// Все коэффициенты вынесены в константы и показываются пользователю как допущения.

export const PHYS = {
  P_ATM_BAR: 1.01325,
  T_STD_K: 293.15, // стандартные условия в РФ: 20 °C, 101,325 кПа
  T_CYL_K: 288.15, // ориентировочная температура газа в баллоне после заправки, 15 °C
  Z_CNG_200: 0.83, // коэффициент сжимаемости метана ≈ при 200 бар и 15 °C (оценка)
  CNG_FILL_FACTOR: 0.9, // недозаправка из-за нагрева газа при быстрой заправке
  LNG_DENSITY_KG_L: 0.42, // плотность СПГ, кг/л (диапазон 0,41–0,45)
  LNG_USABLE: 0.9, // доля полезного объёма криобака (остаток и паровая подушка)
  M3_PER_KG_GAS: 1.39, // м³ природного газа (ст. усл.) на 1 кг при плотности ~0,72 кг/м³
};

export const FUELS = {
  cng: { label: 'КПГ (компримированный метан)', short: 'КПГ', methane: 'cng', stockUnit: 'м³', consUnit: 'm3_100km' },
  bifuel_cng: { label: 'Битопливный: бензин + КПГ', short: 'Бензин/КПГ', methane: 'cng', stockUnit: 'м³', consUnit: 'm3_100km' },
  gasdiesel_cng: { label: 'Газодизель (дизель + КПГ)', short: 'Газодизель', methane: 'cng', stockUnit: 'м³', consUnit: 'm3_100km' },
  lng: { label: 'СПГ (сжиженный метан)', short: 'СПГ', methane: 'lng', stockUnit: 'кг', consUnit: 'kg_100km' },
  lpg: { label: 'Пропан-бутан (СУГ)', short: 'СУГ', methane: null, stockUnit: 'л', consUnit: 'l_100km' },
  petrol: { label: 'Бензин (кандидат на перевод)', short: 'Бензин', methane: null, stockUnit: 'л', consUnit: 'l_100km' },
  diesel: { label: 'Дизель (кандидат на перевод)', short: 'Дизель', methane: null, stockUnit: 'л', consUnit: 'l_100km' },
  other: { label: 'Другое', short: 'Другое', methane: null, stockUnit: '—', consUnit: 'l_100km' },
};

export const CONS_UNITS = { m3_100km: 'м³/100 км', kg_100km: 'кг/100 км', l_100km: 'л/100 км' };

const round = (x, d = 1) => (x === null || x === undefined || !Number.isFinite(x) ? null : Math.round(x * 10 ** d) / 10 ** d);
const num = (x) => (x === null || x === undefined || x === '' ? null : Number(x));

/** Запас КПГ в м³ (ст. условия) по геометрическому объёму баллонов. */
export function cngStockM3(cylinderCount, cylinderVolumeL, pressureBar = 200) {
  const n = num(cylinderCount), v = num(cylinderVolumeL), p = num(pressureBar) || 200;
  if (!n || !v) return null;
  const geomM3 = (n * v) / 1000;
  const z = p >= 180 ? PHYS.Z_CNG_200 : 0.9; // при меньшем давлении газ ближе к идеальному
  const stock = geomM3 * ((p + PHYS.P_ATM_BAR) / PHYS.P_ATM_BAR) * (PHYS.T_STD_K / PHYS.T_CYL_K) / z * PHYS.CNG_FILL_FACTOR;
  return round(stock, 1);
}

/** Запас СПГ в кг по геометрическому объёму криобака (л). */
export function lngStockKg(tankL) {
  const v = num(tankL);
  if (!v) return null;
  return round(v * PHYS.LNG_DENSITY_KG_L * PHYS.LNG_USABLE, 1);
}

/** Сводные расчётные показатели транспортного средства. */
export function vehicleMetrics(v) {
  const fuel = FUELS[v.fuel_type] || FUELS.other;
  const qty = Math.max(1, Number(v.quantity) || 1);
  const out = { methane: fuel.methane, stockValue: null, stockUnit: fuel.stockUnit, rangeKm: null, monthlyDemand: null, demandUnit: null, notes: [] };
  const cons = num(v.consumption_value);
  const mileage = num(v.monthly_mileage_km);
  if (fuel.methane === 'cng') {
    const stock = v.stock_is_manual ? num(v.gas_stock_m3) : cngStockM3(v.cylinder_count, v.cylinder_volume_l, v.working_pressure_bar);
    out.stockValue = stock;
    out.demandUnit = 'м³';
    if (stock && cons) out.rangeKm = round((stock / cons) * 100, 0);
    if (cons && mileage) {
      // Для газодизеля учитывается только газовая доля, указанная в расходе м³/100 км.
      out.monthlyDemand = round(((mileage * cons) / 100) * qty, 0);
    }
    if (!v.stock_is_manual && stock) out.notes.push('Запас газа рассчитан по геометрическому объёму баллонов и рабочему давлению (оценка).');
  } else if (fuel.methane === 'lng') {
    const stock = v.stock_is_manual ? num(v.gas_stock_kg) : lngStockKg(v.lng_tank_l);
    out.stockValue = stock;
    out.demandUnit = 'кг';
    if (stock && cons) out.rangeKm = round((stock / cons) * 100, 0);
    if (cons && mileage) out.monthlyDemand = round(((mileage * cons) / 100) * qty, 0);
    if (!v.stock_is_manual && stock) out.notes.push('Масса СПГ рассчитана по объёму криобака, плотности 0,42 кг/л и доле полезного объёма 90 %.');
  } else {
    out.notes.push('Транспорт не использует метан: учитывается только как потенциал перевода.');
  }
  return out;
}

/** Калькулятор экономии: газомоторное топливо против бензина/дизеля. Цены вводит пользователь. */
export function savings(input) {
  const km = num(input.monthlyKm) || 0;
  const gasCons = num(input.gasConsumption) || 0; // м³ или кг на 100 км
  const gasPrice = num(input.gasPrice) || 0; // руб. за м³ или кг
  const liqCons = num(input.liquidConsumption) || 0; // л/100 км
  const liqPrice = num(input.liquidPrice) || 0; // руб./л
  const share = Math.min(1, Math.max(0, (num(input.gasShare) ?? 100) / 100)); // доля пробега на газе
  const conversion = num(input.conversionCost) || 0;
  const vehicles = Math.max(1, num(input.vehicles) || 1);
  const liquidOnly = (km * liqCons / 100) * liqPrice;
  const mixed = share * (km * gasCons / 100) * gasPrice + (1 - share) * (km * liqCons / 100) * liqPrice;
  const monthlySaving = (liquidOnly - mixed) * vehicles;
  return {
    monthlyLiquid: round(liquidOnly * vehicles, 0),
    monthlyGas: round(mixed * vehicles, 0),
    monthlySaving: round(monthlySaving, 0),
    annualSaving: round(monthlySaving * 12, 0),
    savingPct: liquidOnly > 0 ? round(((liquidOnly - mixed) / liquidOnly) * 100, 1) : null,
    paybackMonths: conversion > 0 && monthlySaving > 0 ? round((conversion * vehicles) / monthlySaving, 1) : null,
    monthlyGasVolume: round(share * km * gasCons / 100 * vehicles, 0),
  };
}

export const SCENARIO_DEFAULTS = {
  conservative: { label: 'Консервативный', volume: 0.75, price: 0.97, capex: 1.15, opex: 1.1, rampShift: 1 },
  base: { label: 'Базовый', volume: 1, price: 1, capex: 1, opex: 1, rampShift: 0 },
  optimistic: { label: 'Оптимистичный', volume: 1.15, price: 1.03, capex: 0.95, opex: 0.95, rampShift: 0 },
};

export const INVESTMENT_DEFAULTS = {
  capex: 180_000_000, // руб., без НДС — условное значение для примера
  opexAnnual: 15_000_000, // руб./год постоянных расходов
  annualVolume: 6_000_000, // м³/год при выходе на плановую загрузку
  purchasePrice: 16, // руб./м³ — вводится оператором
  salePrice: 30, // руб./м³ — вводится оператором
  variableCost: 2.5, // руб./м³ — электроэнергия компрессоров и пр.
  discountRate: 16, // % годовых
  horizonYears: 15,
  ramp: [35, 55, 75, 90, 100],
  capacityM3h: 1500,
  maxUtilization: 70, // % от теоретической производительности 24×365
  taxRate: 25, // налог на прибыль, %
  usefulLifeYears: 15,
};

export function npv(rate, flows) {
  return flows.reduce((s, cf, t) => s + cf / (1 + rate) ** t, 0);
}

export function irr(flows) {
  let signChanges = 0;
  for (let i = 1; i < flows.length; i++) if (Math.sign(flows[i]) !== 0 && Math.sign(flows[i]) !== Math.sign(flows[i - 1])) signChanges++;
  if (signChanges === 0) return { value: null, reason: 'Денежные потоки не меняют знак — IRR не определяется.' };
  let lo = -0.99, hi = 10;
  let fLo = npv(lo, flows), fHi = npv(hi, flows);
  if (Math.sign(fLo) === Math.sign(fHi)) return { value: null, reason: 'Не удалось найти корень NPV(r)=0 в диапазоне −99…1000 %.' };
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fMid = npv(mid, flows);
    if (Math.abs(fMid) < 1e-6) { lo = hi = mid; break; }
    if (Math.sign(fMid) === Math.sign(fLo)) { lo = mid; fLo = fMid; } else { hi = mid; fHi = fMid; }
  }
  return { value: (lo + hi) / 2, reason: signChanges > 1 ? 'Знак денежного потока меняется несколько раз — возможны несколько значений IRR.' : null };
}

function payback(flows, rate = null) {
  let cum = 0;
  for (let t = 0; t < flows.length; t++) {
    const cf = rate === null ? flows[t] : flows[t] / (1 + rate) ** t;
    const prev = cum;
    cum += cf;
    if (t > 0 && prev < 0 && cum >= 0) return round(t - 1 + (-prev / cf), 1);
  }
  return null;
}

/** Упрощённая инвестиционная модель АГНКС. Возвращает таблицу по годам и показатели. */
export function investmentModel(inputs, scenario = SCENARIO_DEFAULTS.base) {
  const p = { ...INVESTMENT_DEFAULTS, ...inputs };
  const H = Math.min(40, Math.max(1, Math.round(num(p.horizonYears) || 15)));
  const r = (num(p.discountRate) || 0) / 100;
  const ramp = (Array.isArray(p.ramp) && p.ramp.length ? p.ramp : [100]).map((x) => Math.min(100, Math.max(0, Number(x) || 0)) / 100);
  const shift = Math.max(0, Math.round(scenario.rampShift || 0));
  const effRamp = [...Array(shift).fill(ramp[0] * 0.7), ...ramp];
  const capacityLimit = (num(p.capacityM3h) || 0) > 0 ? num(p.capacityM3h) * 8760 * (num(p.maxUtilization) || 100) / 100 : Infinity;
  const capex = (num(p.capex) || 0) * scenario.capex;
  const tax = (num(p.taxRate) || 0) / 100;
  const dep = capex / Math.max(1, num(p.usefulLifeYears) || H);
  const years = [];
  const flows = [-capex];
  let capped = false;
  for (let t = 1; t <= H; t++) {
    const load = effRamp[t - 1] ?? effRamp[effRamp.length - 1];
    let volume = (num(p.annualVolume) || 0) * load * scenario.volume;
    if (volume > capacityLimit) { volume = capacityLimit; capped = true; }
    const revenue = volume * (num(p.salePrice) || 0) * scenario.price;
    const purchase = volume * (num(p.purchasePrice) || 0);
    const variable = volume * (num(p.variableCost) || 0);
    const gross = revenue - purchase - variable;
    const opex = (num(p.opexAnnual) || 0) * scenario.opex;
    const ebitda = gross - opex;
    const taxable = ebitda - (t <= (num(p.usefulLifeYears) || H) ? dep : 0);
    const taxPaid = taxable > 0 ? taxable * tax : 0;
    const ocf = ebitda - taxPaid;
    flows.push(ocf);
    years.push({ year: t, load: round(load * 100, 0), volume: round(volume, 0), revenue: round(revenue, 0), grossMargin: round(gross, 0), opex: round(opex, 0), ebitda: round(ebitda, 0), tax: round(taxPaid, 0), cashFlow: round(ocf, 0) });
  }
  const irrRes = irr(flows);
  const totals = years.reduce((a, y) => ({ revenue: a.revenue + y.revenue, gross: a.gross + y.grossMargin, cash: a.cash + y.cashFlow }), { revenue: 0, gross: 0, cash: 0 });
  return {
    scenario: scenario.label,
    capex: round(capex, 0),
    years,
    flows: flows.map((x) => round(x, 0)),
    npv: round(npv(r, flows), 0),
    irr: irrRes.value === null ? null : round(irrRes.value * 100, 2),
    irrNote: irrRes.reason,
    simplePayback: payback(flows),
    discountedPayback: payback(flows, r),
    totalRevenue: round(totals.revenue, 0),
    totalGrossMargin: round(totals.gross, 0),
    avgAnnualCashFlow: round(totals.cash / H, 0),
    capacityLimit: Number.isFinite(capacityLimit) ? round(capacityLimit, 0) : null,
    capacityCapped: capped,
  };
}

export const MODEL_LIMITATIONS = [
  'Модель упрощённая: денежные потоки годовые, без учёта инфляции, НДС, оборотного капитала и стоимости земли.',
  'Налог на прибыль рассчитан от EBITDA за вычетом линейной амортизации, без переноса убытков прошлых лет.',
  'Цены закупки и реализации, CAPEX и OPEX вводятся оператором и не являются рыночными данными платформы.',
  'Объём отпуска ограничивается производительностью станции и предельной загрузкой.',
  'Голоса и пользовательские заявки не являются гарантированным спросом и не должны напрямую подставляться в объём отпуска.',
  'Для инвестиционного решения требуется полноценная финансовая модель, обследование площадки и согласование подключения к газораспределительной сети.',
];
