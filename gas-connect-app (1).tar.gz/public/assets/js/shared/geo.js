// Геометрические расчёты: расстояния, привязка станций к маршруту, поиск участков дефицита заправок.
const R = 6371.0088;
const rad = (d) => (d * Math.PI) / 180;

export function haversine(a, b) {
  const dLat = rad(b[0] - a[0]);
  const dLng = rad(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function polylineLength(line) {
  let s = 0;
  for (let i = 1; i < line.length; i++) s += haversine(line[i - 1], line[i]);
  return s;
}

// Расстояние от точки до отрезка в локальной равнопромежуточной проекции (достаточно для десятков км).
export function pointSegment(p, a, b) {
  const lat0 = rad((a[0] + b[0] + p[0]) / 3);
  const k = Math.cos(lat0);
  const ax = a[1] * k, ay = a[0], bx = b[1] * k, by = b[0], px = p[1] * k, py = p[0];
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = len2 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const proj = [ay + t * dy, (ax + t * dx) / k];
  return { distanceKm: haversine(p, proj), t, proj };
}

/** Ближайшая точка маршрута: отклонение (км) и положение вдоль маршрута (км от начала). */
export function locateOnPolyline(p, line) {
  let best = { distanceKm: Infinity, alongKm: 0 };
  let acc = 0;
  for (let i = 1; i < line.length; i++) {
    const seg = haversine(line[i - 1], line[i]);
    const r = pointSegment(p, line[i - 1], line[i]);
    if (r.distanceKm < best.distanceKm) best = { distanceKm: r.distanceKm, alongKm: acc + seg * r.t };
    acc += seg;
  }
  if (line.length === 1) best = { distanceKm: haversine(p, line[0]), alongKm: 0 };
  return best;
}

export function pointAlong(line, km) {
  let acc = 0;
  for (let i = 1; i < line.length; i++) {
    const seg = haversine(line[i - 1], line[i]);
    if (acc + seg >= km) {
      const t = seg ? (km - acc) / seg : 0;
      return [line[i - 1][0] + (line[i][0] - line[i - 1][0]) * t, line[i - 1][1] + (line[i][1] - line[i - 1][1]) * t];
    }
    acc += seg;
  }
  return line[line.length - 1];
}

/** Прореживание ломаной до maxPoints точек (для хранения и передачи). */
export function downsample(line, maxPoints = 400) {
  if (line.length <= maxPoints) return line;
  const step = (line.length - 1) / (maxPoints - 1);
  const out = [];
  for (let i = 0; i < maxPoints; i++) out.push(line[Math.round(i * step)]);
  return out;
}

/** Ломаная между точками маршрута по прямой с интерполяцией (если маршрутизатор недоступен). */
export function straightLine(points, stepKm = 10) {
  const out = [points[0]];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    const n = Math.max(1, Math.ceil(haversine(a, b) / stepKm));
    for (let k = 1; k <= n; k++) out.push([a[0] + ((b[0] - a[0]) * k) / n, a[1] + ((b[1] - a[1]) * k) / n]);
  }
  return out;
}

/**
 * Анализ коридора маршрута.
 * stations: [{id, lat, lng, ...}] — только подходящие по топливу и статусу.
 * opts: { startRangeKm, fullRangeKm, maxDeviationKm, reservePct }
 * Возвращает станции на маршруте, план остановок и участки, где запаса хода не хватает.
 */
export function analyzeCorridor(line, stations, opts) {
  const total = polylineLength(line);
  const dev = Math.max(0, Number(opts.maxDeviationKm) || 0);
  const reserve = Math.min(0.5, Math.max(0, (Number(opts.reservePct) || 0) / 100));
  const fullRange = Math.max(1, Number(opts.fullRangeKm) || 1) * (1 - reserve);
  const startRange = Math.max(0, Number(opts.startRangeKm ?? opts.fullRangeKm) || 0) * (1 - reserve);
  const onRoute = [];
  for (const s of stations) {
    const loc = locateOnPolyline([s.lat, s.lng], line);
    if (loc.distanceKm <= dev) onRoute.push({ ...s, alongKm: Math.round(loc.alongKm * 10) / 10, deviationKm: Math.round(loc.distanceKm * 10) / 10 });
  }
  onRoute.sort((a, b) => a.alongKm - b.alongKm);

  // Жадная симуляция: едем до самой дальней достижимой станции (с учётом съезда туда и обратно).
  const stops = [];
  const gaps = [];
  let pos = 0;
  let reach = startRange; // абсолютная координата (км), до которой хватает газа
  let guard = 0;
  while (reach < total && guard++ < 500) {
    const candidates = onRoute.filter((s) => s.alongKm > pos + 0.001 && s.alongKm + s.deviationKm <= reach);
    if (!candidates.length) {
      const next = onRoute.find((s) => s.alongKm > reach);
      const end = next ? next.alongKm : total;
      gaps.push({ fromKm: Math.round(reach), toKm: Math.round(end), lengthKm: Math.round(end - reach), mid: pointAlong(line, (reach + end) / 2) });
      if (!next) break;
      // Считаем, что водитель дозаправился бы на следующей станции (для поиска остальных разрывов).
      pos = next.alongKm;
      reach = next.alongKm + fullRange;
      stops.push({ ...next, unreachable: true });
      continue;
    }
    const best = candidates[candidates.length - 1];
    stops.push(best);
    pos = best.alongKm;
    const newReach = best.alongKm - best.deviationKm + fullRange;
    if (newReach <= reach) {
      // Дальше не продвинуться: запас хода меньше расстояния до следующих станций.
      const next = onRoute.find((s) => s.alongKm > reach);
      const end = next ? next.alongKm : total;
      gaps.push({ fromKm: Math.round(reach), toKm: Math.round(end), lengthKm: Math.round(end - reach), mid: pointAlong(line, (reach + end) / 2) });
      if (!next) break;
      pos = next.alongKm;
      reach = next.alongKm + fullRange;
      stops.push({ ...next, unreachable: true });
      continue;
    }
    reach = newReach;
  }
  return {
    totalKm: Math.round(total * 10) / 10,
    stationsOnRoute: onRoute,
    refuelStops: stops.map((s) => ({ id: s.id, name: s.name, alongKm: s.alongKm, deviationKm: s.deviationKm, unreachable: !!s.unreachable })),
    gaps,
    feasible: gaps.length === 0,
    effectiveRangeKm: Math.round(fullRange),
  };
}
