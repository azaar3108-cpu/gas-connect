// Оболочка приложения: шапка, подвал, маршрутизация страниц (History API).
import { html, raw, $, $$, api, state, refreshSession, onSession, setNavigator, toast, icon, initials, observeReveal, isStaff, setTitle, LABELS } from './core.js';

const ROUTES = [
  ['/', () => import('./pages/home.js'), 'home'],
  ['/map', () => import('./pages/map.js'), 'map'],
  ['/plan', () => import('./pages/plan.js'), 'plan'],
  ['/vote', () => import('./pages/vote.js'), 'list'],
  ['/vote/new', () => import('./pages/vote.js'), 'create'],
  ['/vote/:id', () => import('./pages/vote.js'), 'detail'],
  ['/routes', () => import('./pages/planner.js'), 'planner'],
  ['/savings', () => import('./pages/planner.js'), 'savings'],
  ['/business', () => import('./pages/info.js'), 'business'],
  ['/analytics', () => import('./pages/info.js'), 'analytics'],
  ['/about', () => import('./pages/info.js'), 'about'],
  ['/credits', () => import('./pages/info.js'), 'credits'],
  ['/privacy', () => import('./pages/info.js'), 'privacy'],
  ['/feedback', () => import('./pages/info.js'), 'feedback'],
  ['/news', () => import('./pages/info.js'), 'newsList'],
  ['/news/:slug', () => import('./pages/info.js'), 'newsItem'],
  ['/learn', () => import('./pages/learn.js'), 'index'],
  ['/learn/:slug', () => import('./pages/learn.js'), 'article'],
  ['/login', () => import('./pages/auth.js'), 'login'],
  ['/register', () => import('./pages/auth.js'), 'register'],
  ['/forgot', () => import('./pages/auth.js'), 'forgot'],
  ['/reset', () => import('./pages/auth.js'), 'reset'],
  ['/verify', () => import('./pages/auth.js'), 'verify'],
  ['/account', () => import('./pages/account.js'), 'page'],
  ['/account/:tab', () => import('./pages/account.js'), 'page'],
  ['/account/:tab/:id', () => import('./pages/account.js'), 'page'],
  ['/operator', () => import('./pages/operator.js'), 'page'],
  ['/operator/:tab', () => import('./pages/operator.js'), 'page'],
  ['/operator/:tab/:id', () => import('./pages/operator.js'), 'page'],
].map(([path, load, fn]) => {
  const keys = [];
  const re = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  return { path, re, keys, load, fn };
});

const NAV = [
  ['/', 'Главная'], ['/map', 'Карта заправок'], ['/plan', 'Развитие инфраструктуры'], ['/vote', 'Голосование'],
  ['/routes', 'Маршруты'], ['/business', 'Для бизнеса'], ['/analytics', 'Аналитика'], ['/about', 'О проекте'],
];

const LOGO = raw(`<svg class="logo-mark" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#47c8f5"/><stop offset="1" stop-color="#008ed6"/></linearGradient></defs><rect x="1" y="1" width="46" height="46" rx="11" fill="#0f1a45" stroke="url(#lg)" stroke-width="2"/><path d="M24 9c4 6 9 10 9 17a9 9 0 0 1-18 0c0-4 2-7 4-9 0 3 1 5 3 6-1-5 0-9 2-14Z" fill="url(#lg)"/><circle cx="24" cy="29" r="3.2" fill="#0f1a45"/><path d="M24 29H9M24 29h15M24 29v12" stroke="#0f1a45" stroke-width="2"/><circle cx="9" cy="29" r="2.2" fill="#47c8f5"/><circle cx="39" cy="29" r="2.2" fill="#47c8f5"/><circle cx="24" cy="41" r="2.2" fill="#47c8f5"/></svg>`);

function renderHeader() {
  const u = state.user;
  const path = location.pathname;
  const active = (href) => (href === '/' ? path === '/' : path === href || path.startsWith(href + '/'));
  $('#header').innerHTML = String(html`
    ${state.meta?.demoData ? html`<div class="demo-ribbon">Демонстрационная версия: станции, организации, голоса и показатели — тестовые данные. Сайт не является официальным ресурсом ПАО «Газпром».</div>` : ''}
    <div class="topline"></div>
    <header class="header"><div class="wrap header-row">
      <a href="/" class="logo" aria-label="GAS CONNECT — на главную">${LOGO}<span class="logo-text"><strong>GAS CONNECT</strong><small>Платформа газомоторной инфраструктуры</small></span></a>
      <nav class="nav" id="nav" aria-label="Основное меню">
        ${NAV.map(([href, label]) => html`<a href="${href}" class="${active(href) ? 'active' : ''}">${label}</a>`)}
        ${!u ? html`<a href="/login" class="mobile-only">Войти</a><a href="/register" class="mobile-only">Зарегистрироваться</a>` : ''}
      </nav>
      <div class="header-actions">
        ${u ? html`
          <a href="/account/notifications" class="bell" aria-label="Уведомления">${icon('bell')}${u.unreadNotifications ? html`<span class="count">${u.unreadNotifications}</span>` : ''}</a>
          <div class="usermenu">
            <button class="usermenu-btn" id="userBtn" aria-haspopup="true" aria-expanded="false"><span class="avatar">${initials(u.name)}</span><span class="name">${u.name}</span></button>
            <div class="dropdown" id="userDrop">
              <div style="padding:8px 12px 10px"><div style="font-weight:600">${u.name}</div><div class="tiny muted">${LABELS.account[u.accountType] || ''}${u.organization ? ' · ' + u.organization.name : ''}</div></div>
              <hr>
              <a href="/account">Личный кабинет</a>
              ${['ip', 'company'].includes(u.accountType) ? html`<a href="/account/fleet">Мой автопарк</a><a href="/account/offers">Договоры и предложения</a>` : html`<a href="/account/vehicles">Мои автомобили</a>`}
              <a href="/account/routes">Мои маршруты</a>
              <a href="/account/favorites">Избранное</a>
              ${isStaff() ? html`<hr><a href="/operator">Панель оператора</a>` : ''}
              <hr><button id="logoutBtn">Выйти</button>
            </div>
          </div>` : html`
          <a href="/login" class="btn sm ghost auth-btn">Войти</a>
          <a href="/register" class="btn sm primary auth-btn">Зарегистрироваться</a>`}
        <button class="burger" id="burger" aria-label="Меню" aria-controls="nav" aria-expanded="false">${icon('menu', 22)}</button>
      </div>
    </div></header>`);
  const burger = $('#burger');
  burger.onclick = () => { const open = $('#nav').classList.toggle('open'); burger.setAttribute('aria-expanded', open); };
  const ub = $('#userBtn');
  if (ub) {
    ub.onclick = (e) => { e.stopPropagation(); const d = $('#userDrop'); d.classList.toggle('open'); ub.setAttribute('aria-expanded', d.classList.contains('open')); };
    $('#logoutBtn').onclick = async () => { await api.post('/api/auth/logout').catch(() => {}); await refreshSession(); toast('Вы вышли из аккаунта'); navigate('/'); };
  }
}
document.addEventListener('click', () => $('#userDrop')?.classList.remove('open'));

function renderFooter() {
  $('#footer').innerHTML = String(html`<footer class="footer"><div class="wrap">
    <div class="cols">
      <div><a href="/" class="logo" style="margin-bottom:14px">${LOGO}<span class="logo-text"><strong>GAS CONNECT</strong><small>Единая цифровая платформа газомоторной инфраструктуры</small></span></a>
        <p class="small muted" style="max-width:360px">Объединяем водителей, перевозчиков и операторов инфраструктуры, чтобы развивать газомоторную сеть там, где она действительно нужна.</p></div>
      <div><h4>Платформа</h4><a href="/map">Карта заправок</a><a href="/vote">Где нужна новая АГНКС?</a><a href="/plan">План развития сети</a><a href="/routes">Планировщик маршрута</a><a href="/analytics">Аналитика</a></div>
      <div><h4>Участникам</h4><a href="/register">Регистрация</a><a href="/business">Для бизнеса</a><a href="/savings">Калькулятор экономии</a><a href="/learn">Обучающий раздел</a><a href="/news">Новости</a></div>
      <div><h4>О проекте</h4><a href="/about">О платформе</a><a href="/feedback">Обратная связь</a><a href="/privacy">Политика конфиденциальности</a><a href="/credits">Авторство фотографий</a></div>
    </div>
    <div class="legal">
      <div>GAS CONNECT — демонстрационная концепция цифровой платформы. Не является официальным ресурсом ПАО «Газпром» или иных компаний и не содержит их обязательств. Логотипы и товарные знаки третьих лиц не используются.</div>
      <div>Картографические данные © участники OpenStreetMap. Фотографии — Wikimedia Commons, авторы и лицензии указаны на странице «Авторство фотографий».</div>
      <div>© ${new Date().getFullYear()} GAS CONNECT (учебно-демонстрационный проект)</div>
    </div>
  </div></footer>`);
}

let current = null;
export async function navigate(url, { replace = false } = {}) {
  const u = new URL(url, location.origin);
  if (u.origin !== location.origin) { location.href = url; return; }
  if (replace) history.replaceState({}, '', u.pathname + u.search + u.hash);
  else history.pushState({}, '', u.pathname + u.search + u.hash);
  await route();
}
setNavigator(navigate);

async function route() {
  const path = location.pathname;
  const query = Object.fromEntries(new URLSearchParams(location.search));
  const r = ROUTES.find((x) => x.re.test(path));
  const app = $('#app');
  current?.cleanup?.();
  current = null;
  $('#nav')?.classList.remove('open');
  renderHeader();
  if (!r) {
    setTitle('Страница не найдена');
    app.innerHTML = String(html`<section class="section"><div class="wrap"><div class="empty"><h3>Страница не найдена</h3><p>Проверьте адрес или вернитесь на главную.</p><a class="btn primary" href="/">На главную</a></div></div></section>`);
    return;
  }
  const m = r.re.exec(path);
  const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
  app.innerHTML = '<div class="wrap" style="padding:60px 0"><div class="skeleton" style="min-height:260px"></div></div>';
  try {
    const mod = await r.load();
    const ctx = { params, query, app, cleanup: null };
    current = ctx;
    app.classList.remove('page-enter');
    void app.offsetWidth;
    app.classList.add('page-enter');
    await mod[r.fn](ctx);
    if (!location.hash) window.scrollTo({ top: 0, behavior: 'instant' });
    observeReveal(app);
  } catch (e) {
    console.error(e);
    app.innerHTML = String(html`<section class="section"><div class="wrap"><div class="empty"><h3>Не удалось загрузить страницу</h3><p>${e.message || ''}</p><a class="btn" href="${path}">Повторить</a></div></div></section>`);
  }
}

// Перехват внутренних ссылок.
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href]');
  if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  const href = a.getAttribute('href');
  if (!href.startsWith('/') || href.startsWith('//') || a.target === '_blank' || a.hasAttribute('download') || href.startsWith('/api/')) return;
  e.preventDefault();
  navigate(href);
});
window.addEventListener('popstate', route);
onSession(() => renderHeader());

(async function boot() {
  try {
    const [meta] = await Promise.all([api.get('/api/meta'), refreshSession()]);
    state.meta = meta;
  } catch (e) {
    toast('Сервер недоступен: ' + e.message, 'error', 8000);
  }
  renderFooter();
  await route();
  // Периодически обновляем счётчик уведомлений.
  setInterval(() => { if (state.user && document.visibilityState === 'visible') refreshSession().catch(() => {}); }, 60_000);
})();

export { route, $$ };
