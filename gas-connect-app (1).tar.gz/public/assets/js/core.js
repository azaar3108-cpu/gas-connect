// Ядро клиентского приложения: безопасные шаблоны, API-клиент, состояние сессии, уведомления, модальные окна, формы.

// ---------- Безопасные HTML-шаблоны (все подстановки экранируются) ----------
export class Raw { constructor(s) { this.s = String(s); } toString() { return this.s; } }
export const raw = (s) => new Raw(s);
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);
function val(v) {
  if (v === null || v === undefined || v === false) return '';
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(val).join('');
  return esc(v);
}
export function html(strings, ...values) {
  let out = '';
  strings.forEach((s, i) => { out += s; if (i < values.length) out += val(values[i]); });
  return new Raw(out);
}
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

// ---------- Форматирование ----------
export const fmt = (n, d = 0) => (n === null || n === undefined || n === '' || Number.isNaN(Number(n)) ? '—' : Number(n).toLocaleString('ru-RU', { maximumFractionDigits: d, minimumFractionDigits: 0 }));
export const money = (n) => (n === null || n === undefined ? '—' : `${fmt(Math.round(n))} ₽`);
export const mln = (n) => (n === null || n === undefined ? '—' : `${fmt(n / 1e6, 1)} млн ₽`);
export const date = (s) => (s ? new Date(s).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) : '—');
export const dateTime = (s) => (s ? new Date(s).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');
export const plural = (n, one, few, many) => { const a = Math.abs(n) % 100, b = a % 10; return a > 10 && a < 20 ? many : b > 1 && b < 5 ? few : b === 1 ? one : many; };
export const initials = (name) => String(name || '?').replace(/\(.*?\)/g, '').trim().split(/\s+/).slice(0, 2).map((x) => x[0]).join('').toUpperCase() || '?';

// ---------- Справочники интерфейса ----------
export const LABELS = {
  kind: { agnks: 'АГНКС', cryo: 'КриоАЗС', modular: 'Модульная АГНКС', pagz: 'ПАГЗ (передвижной)', multi: 'АЗС с метаном' },
  stationStatus: { operational: 'Действующая', construction: 'Строится', planned: 'Проектируется', closed: 'Закрыта' },
  fuel: { cng: 'КПГ', lng: 'СПГ', both: 'КПГ и СПГ', undecided: 'Пока не выбрано' },
  account: { person: 'Физическое лицо', ip: 'Индивидуальный предприниматель', company: 'Юридическое лицо', staff: 'Сотрудник оператора' },
  role: { user: 'Пользователь', operator: 'Оператор', admin: 'Администратор' },
  member: { owner: 'Владелец', manager: 'Менеджер (редактирование)', viewer: 'Наблюдатель (просмотр)' },
  planCategory: { confirmed: 'Подтверждённый действующий объект', announced: 'Официально объявленный проект', under_review: 'Рассматривается оператором', user_initiative: 'Инициатива пользователей' },
  verification: { unverified: 'Не проверена', pending: 'На проверке', verified: 'Проверена оператором', rejected: 'Проверка не пройдена' },
  feedbackTopic: { question: 'Вопрос', suggestion: 'Предложение', data_error: 'Ошибка в данных', other: 'Другое' },
};
export const STATION_COLORS = { operational: '#22a779', mobile: '#47c8f5', construction: '#f08a3c', planned: '#9b7bff', proposal: '#e9eef9', closed: '#6b7799' };
export function stationColor(s) {
  if (s.status === 'operational') return ['modular', 'pagz'].includes(s.kind) ? STATION_COLORS.mobile : STATION_COLORS.operational;
  return STATION_COLORS[s.status] || STATION_COLORS.closed;
}
export function statusBadge(status, label) {
  const cls = { operational: 'ok', construction: 'construction', planned: 'designed', closed: 'gray', published: 'info', pending: 'plan', under_review: 'designed', included: 'ok', rejected: 'danger', hidden: 'gray',
    draft: 'gray', submitted: 'info', in_review: 'designed', needs_info: 'plan', preliminarily_approved: 'ok', verified: 'ok', unverified: 'gray', preliminary: 'plan', signed_offline: 'ok', terminated: 'gray',
    new: 'info', in_progress: 'plan', closed_fb: 'gray', confirmed: 'ok', announced: 'construction', user_initiative: 'gray' }[status] || 'gray';
  return html`<span class="badge ${cls}">${label || status}</span>`;
}
export const demoBadge = (on) => (on ? html`<span class="badge demo" title="Демонстрационные данные">Демо</span>` : '');

// ---------- Фотографии (Wikimedia Commons) с резервным оформлением ----------
const commons = (file, w = 1600) => `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(file)}?width=${w}`;
const page = (file) => `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(file.replace(/ /g, '_'))}`;
export const MEDIA = {
  'cng-station': { file: 'CNG station in Armenia.jpg', title: 'Газозаправочная станция КПГ', fallback: 'station' },
  'cng-station-2': { file: 'Metropolitan Utilities District CNG Filling Station.jpg', title: 'Станция заправки КПГ', fallback: 'station' },
  'cng-dispenser': { file: 'Fiat Panda CNG Compressed Natural Gas (7321176438).jpg', title: 'Заправка автомобиля КПГ', fallback: 'dispenser' },
  'lng-station': { file: '2022-11-13 LNG-Tankstelle.JPG', title: 'Станция заправки СПГ', fallback: 'cryo' },
  'lng-truck': { file: 'Vos Logistics LNG truck.jpg', title: 'Грузовик на СПГ', fallback: 'truck' },
  'trucks-road': { file: 'Russia - Trucks on the road.jpg', title: 'Грузовой транспорт на трассе', fallback: 'road' },
  'highway': { file: 'Russia - Trucks on the road.jpg', title: 'Автомобильная магистраль', fallback: 'road' },
  'bus': { file: 'Solaris Urbino 15 III CNG Bratislava.JPG', title: 'Газомоторный автобус', fallback: 'bus' },
  'bus-2': { file: "MAN Lion's City G CNG Oldenburg Grotepool.jpg", title: 'Автобус на КПГ', fallback: 'bus' },
  'compressor': { file: 'Gas compressor station, Bacton - geograph.org.uk - 228631.jpg', title: 'Компрессорная станция', fallback: 'industry' },
  'compressor-2': { file: 'Strilkove Compressor Station.jpg', title: 'Газовая инфраструктура', fallback: 'industry' },
  'lng-terminal': { file: 'LNG Terminal.jpg', title: 'Промышленный газовый объект', fallback: 'industry' },
  'cylinders': { file: 'CNG Storage Cylinders and Micarta.jpg', title: 'Баллоны КПГ', fallback: 'dispenser' },
  'truck-2': { file: 'Blue Energy Motors truck.jpg', title: 'Магистральный тягач на СПГ', fallback: 'truck' },
};
export function photo(key, w = 1600) {
  const m = MEDIA[key] || MEDIA['cng-station'];
  return { url: commons(m.file, w), page: page(m.file), title: m.title, fallback: `/assets/img/fallback-${m.fallback}.svg`, file: m.file };
}
/** CSS-фон: градиент + фотография + резервная иллюстрация (видна, если фото недоступно). */
export function photoBg(key, w = 1200, overlay = '') {
  const p = photo(key, w);
  return `background-image:${overlay ? overlay + ',' : ''}url('${p.url}'),url('${p.fallback}');`;
}

// ---------- Иконки ----------
const I = {
  map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z"/><path d="M9 4v14M15 6v14"/>',
  vote: '<path d="M7 11V20H4V11h3Z"/><path d="M7 11l4-7c1.5 0 2.5 1 2.2 2.6L12.6 10H19a2 2 0 0 1 2 2.3l-1.2 6A2 2 0 0 1 17.8 20H7"/>',
  route: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h7.5a3.5 3.5 0 0 0 0-7h-7a3.5 3.5 0 0 1 0-7H16"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  car: '<path d="M5 16h14l-1.6-6.2A2 2 0 0 0 15.5 8h-7a2 2 0 0 0-1.9 1.8L5 16Z"/><path d="M3 16h18v3H3zM7 19v2M17 19v2"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4l2-2Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  doc: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9l-6-6Z"/><path d="M14 3v6h6M8 13h8M8 17h6"/>',
  building: '<path d="M4 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16M16 9h2a2 2 0 0 1 2 2v10M2 21h20M8 7h4M8 11h4M8 15h4"/>',
  fuel: '<path d="M4 21V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v16M3 21h12M14 9h2a2 2 0 0 1 2 2v5a1.5 1.5 0 0 0 3 0V8l-3-3M7 7h4"/>',
  check: '<path d="m5 12 5 5 9-11"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  warn: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4M12 17h.01"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l4-4-4-4M14 12H4"/>',
  book: '<path d="M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2Zm0 0a2 2 0 0 0 2 2h13"/>',
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2V5Z"/><path d="M17 9h3v8a2 2 0 0 1-2 2M8 9h5M8 13h5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  pin: '<path d="M12 21s7-6 7-12a7 7 0 1 0-14 0c0 6 7 12 7 12Z"/><circle cx="12" cy="9" r="2.5"/>',
  people: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.4.6 4 2.8 4 6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
};
export const icon = (name, size = 18) => raw(`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[name] || I.info}</svg>`);

// ---------- Состояние ----------
export const state = { user: null, csrf: null, meta: null, listeners: new Set() };
export function onSession(fn) { state.listeners.add(fn); return () => state.listeners.delete(fn); }
function emit() { state.listeners.forEach((fn) => fn(state)); }

function cookie(name) {
  const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]) : null;
}

export class ApiError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}

export async function api(method, url, body) {
  const opts = { method, headers: { Accept: 'application/json' }, credentials: 'same-origin' };
  if (method !== 'GET') {
    opts.headers['X-CSRF-Token'] = cookie('gc_csrf') || state.csrf || '';
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  }
  let res;
  try { res = await fetch(url, opts); } catch { throw new ApiError(0, 'Нет связи с сервером. Проверьте подключение.'); }
  let data = null;
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) data = await res.json();
  if (!res.ok) {
    if (res.status === 401 && state.user && !url.startsWith('/api/auth/')) { state.user = null; emit(); }
    throw new ApiError(res.status, data?.error || `Ошибка ${res.status}`, data?.details);
  }
  return data;
}
api.get = (u) => api('GET', u);
api.post = (u, b = {}) => api('POST', u, b);
api.put = (u, b = {}) => api('PUT', u, b);
api.del = (u) => api('DELETE', u);

export async function refreshSession() {
  const s = await api.get('/api/session');
  state.csrf = s.csrf;
  state.user = s.user;
  emit();
  return s.user;
}
export function setUser(user) { state.user = user; emit(); }
export const isStaff = () => ['operator', 'admin'].includes(state.user?.role);
export const isBusiness = () => ['ip', 'company'].includes(state.user?.accountType);

// ---------- Навигация ----------
let navigateImpl = (u) => { location.href = u; };
export function setNavigator(fn) { navigateImpl = fn; }
export const go = (url, opts) => navigateImpl(url, opts);

// ---------- Всплывающие сообщения ----------
export function toast(message, type = 'info', ms = 4200) {
  let box = $('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.append(box); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  box.append(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 320); }, ms);
}
export function showError(e) { toast(e?.message || 'Произошла ошибка', 'error', 6000); }

// ---------- Модальные окна ----------
export function modal({ title, body, wide = false, onMount }) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-head"><h2>${esc(title)}</h2><button class="x" type="button" aria-label="Закрыть">×</button></div><div class="modal-body">${String(body)}</div></div>`;
  const prevFocus = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; prevFocus?.focus?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  back.querySelector('.x').onclick = close;
  document.addEventListener('keydown', onKey);
  document.body.append(back);
  document.body.style.overflow = 'hidden';
  const root = back.querySelector('.modal-body');
  setTimeout(() => (root.querySelector('input,select,textarea,button') || back.querySelector('.x')).focus(), 30);
  onMount?.(root, close);
  return { root, close };
}
export function confirmDialog(text, { ok = 'Подтвердить', danger = false } = {}) {
  return new Promise((resolve) => {
    const m = modal({ title: 'Подтверждение', body: html`<p>${text}</p><div class="form-actions"><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${ok}</button><button class="btn ghost" data-cancel>Отмена</button></div>` });
    m.root.querySelector('[data-ok]').onclick = () => { m.close(); resolve(true); };
    m.root.querySelector('[data-cancel]').onclick = () => { m.close(); resolve(false); };
  });
}

// ---------- Формы ----------
/** Собирает значения формы с учётом типов: number → число, checkbox → boolean, data-list → массив. */
export function formValues(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled) continue;
    if (el.type === 'checkbox') {
      if (el.dataset.group) { (out[el.name] ||= []); if (el.checked) out[el.name].push(el.value); }
      else out[el.name] = el.checked;
    } else if (el.type === 'radio') { if (el.checked) out[el.name] = el.value; }
    else if (el.type === 'number') out[el.name] = el.value === '' ? null : Number(el.value);
    else if (el.tagName === 'SELECT' && el.multiple) out[el.name] = Array.from(el.selectedOptions).map((o) => o.value);
    else out[el.name] = el.value.trim() === '' ? null : el.value;
  }
  return out;
}
export function setFormValues(form, data) {
  for (const el of form.elements) {
    if (!el.name || !(el.name in data)) continue;
    const v = data[el.name];
    if (el.type === 'checkbox') el.checked = el.dataset.group ? (v || []).includes(el.value) : !!v;
    else if (el.type === 'radio') el.checked = el.value === v;
    else el.value = v ?? '';
  }
}
export function clearErrors(form) {
  $$('.field.invalid', form).forEach((f) => f.classList.remove('invalid'));
  $$('.field .err', form).forEach((e) => e.remove());
}
export function showFieldErrors(form, err) {
  clearErrors(form);
  const fields = err?.details?.fields || {};
  let first = null;
  for (const [name, msg] of Object.entries(fields)) {
    const input = form.querySelector(`[name="${CSS.escape(name)}"]`);
    const field = input?.closest('.field');
    if (!field) continue;
    field.classList.add('invalid');
    const e = document.createElement('div');
    e.className = 'err';
    e.textContent = msg;
    field.append(e);
    first ||= input;
  }
  first?.focus();
  toast(err.message || 'Проверьте данные формы', 'error', 6000);
}
/** Подключает обработчик отправки формы с блокировкой кнопки и показом ошибок. */
export function bindForm(form, handler) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.submitter || form.querySelector('[type=submit]');
    const label = btn?.innerHTML;
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spin"></span> Отправка…'; }
    clearErrors(form);
    try { await handler(formValues(form), form, e.submitter); }
    catch (err) { if (err instanceof ApiError && err.details?.fields) showFieldErrors(form, err); else showError(err); }
    finally { if (btn && btn.isConnected) { btn.disabled = false; btn.innerHTML = label; } }
  });
}

// ---------- Конструкторы полей ----------
export function field(name, label, { type = 'text', required = false, value = '', hint = '', placeholder = '', options = null, full = false, min, max, step, list, attrs = '', rows } = {}) {
  const id = `f-${name}-${Math.random().toString(36).slice(2, 7)}`;
  let control;
  const common = `id="${id}" name="${esc(name)}" ${required ? 'required' : ''} ${attrs}`;
  if (options) {
    const opts = Array.isArray(options) ? options.map((o) => (Array.isArray(o) ? o : [o, o])) : Object.entries(options);
    control = `<select ${common}>${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value ?? '') ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
  } else if (type === 'textarea') {
    control = `<textarea ${common} placeholder="${esc(placeholder)}" ${rows ? `rows="${rows}"` : ''}>${esc(value ?? '')}</textarea>`;
  } else {
    control = `<input ${common} type="${type}" value="${esc(value ?? '')}" placeholder="${esc(placeholder)}" ${min !== undefined ? `min="${min}"` : ''} ${max !== undefined ? `max="${max}"` : ''} ${step !== undefined ? `step="${step}"` : ''} ${list ? `list="${list}"` : ''}>`;
  }
  return raw(`<div class="field ${full ? 'full' : ''}"><label for="${id}">${esc(label)}${required ? ' <span class="req">*</span>' : ''}</label>${control}${hint ? `<div class="hint">${esc(hint)}</div>` : ''}</div>`);
}
export const checkbox = (name, label, checked = false, attrs = '') => html`<label class="check"><input type="checkbox" name="${name}" ${checked ? raw('checked') : ''} ${raw(attrs)}><span>${label}</span></label>`;

// ---------- Анимации появления ----------
let io;
export function observeReveal(root = document) {
  if (!('IntersectionObserver' in window)) { $$('.reveal', root).forEach((el) => el.classList.add('revealed')); return; }
  io ||= new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('revealed'); io.unobserve(en.target); } }), { threshold: 0.12 });
  $$('.reveal:not(.revealed)', root).forEach((el) => io.observe(el));
}
export function animateCount(el, to, ms = 1200) {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !Number.isFinite(to)) { el.textContent = fmt(to); return; }
  const start = performance.now();
  const step = (t) => { const k = Math.min(1, (t - start) / ms); el.textContent = fmt(Math.round(to * (1 - (1 - k) ** 3))); if (k < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}

export const skeleton = (n = 3, h = 140) => raw(Array.from({ length: n }, () => `<div class="skeleton" style="min-height:${h}px"></div>`).join(''));
export function setTitle(t) { document.title = t ? `${t} — GAS CONNECT` : 'GAS CONNECT — единая цифровая платформа газомоторной инфраструктуры'; }
export function qs(params) { const u = new URLSearchParams(); for (const [k, v] of Object.entries(params)) if (v !== null && v !== undefined && v !== '') u.set(k, v); const s = u.toString(); return s ? `?${s}` : ''; }
export function cityDatalist(id = 'cities') {
  return raw(`<datalist id="${id}">${(state.cities || []).map((c) => `<option value="${esc(c.name)}">${esc(c.region)}</option>`).join('')}</datalist>`);
}
export function regionDatalist(id = 'regions') {
  return raw(`<datalist id="${id}">${(state.meta?.regions || []).map((r) => `<option value="${esc(r)}">`).join('')}</datalist>`);
}
export async function loadCities() {
  if (!state.cities) state.cities = (await api.get('/api/geo/cities')).items;
  return state.cities;
}
