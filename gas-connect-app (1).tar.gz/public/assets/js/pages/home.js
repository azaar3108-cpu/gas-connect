// Главная страница.
import { html, raw, api, $, $$, fmt, photo, photoBg, icon, statusBadge, demoBadge, animateCount, setTitle, LABELS, date } from '../core.js';

const OVERLAY = 'linear-gradient(180deg,rgba(11,18,48,.05),rgba(11,18,48,.25))';

export async function home(ctx) {
  setTitle('');
  const hero = photo('cng-station', 1920);
  ctx.app.innerHTML = String(html`
  <section class="hero">
    <div class="hero-bg" style="${raw(photoBg('cng-station', 1920))}"></div>
    <img class="hero-rings" src="/assets/img/hero-rings.svg" alt="">
    <div class="wrap"><div class="hero-content">
      <span class="eyebrow">Единая цифровая платформа газомоторной инфраструктуры</span>
      <h1><span class="brand">GAS CONNECT</span>Строим газомоторную инфраструктуру вместе</h1>
      <p class="lead">Объединяем водителей, перевозчиков и операторов инфраструктуры. Отмечайте востребованные маршруты, голосуйте за новые газозаправочные станции и участвуйте в развитии газомоторной сети России.</p>
      <div class="actions">
        <a class="btn primary lg" href="/map">${icon('map')} Найти заправку</a>
        <a class="btn light lg" href="/vote/new">${icon('plus')} Предложить новую станцию</a>
      </div>
    </div></div>
    <div class="hero-credit">Фото: <a href="${hero.page}" target="_blank" rel="noopener">Wikimedia Commons</a></div>
  </section>

  <section class="section tight" style="margin-top:-40px;position:relative;z-index:2"><div class="wrap">
    <div class="stats reveal" id="stats">
      ${['Зарегистрированные пользователи', 'Транспортные компании и ИП', 'Действующие газозаправочные станции', 'Предложения по развитию инфраструктуры'].map((l) => html`<div class="stat"><div class="value">—</div><div class="label">${l}</div><div class="note">&nbsp;</div></div>`)}
    </div>
    <p class="tiny muted" style="margin-top:10px">Показатели рассчитываются автоматически по данным платформы. В демонстрационной версии большая часть записей — тестовые данные (указано в карточках).</p>
  </div></section>

  <section class="section"><div class="wrap">
    <div class="section-head reveal"><div><span class="eyebrow">Как это работает</span><h2 style="margin-top:12px">Четыре шага к новой станции на вашем маршруте</h2></div><p>Каждое действие пользователя превращается в данные о спросе, которые оператор использует для планирования сети.</p></div>
    <div class="steps reveal">
      ${[
        ['user', 'Зарегистрируйтесь', 'Выберите тип участника: физическое лицо, ИП или компания. Подтвердите e-mail.'],
        ['car', 'Добавьте автомобиль и маршруты', 'Укажите транспорт, топливо, пробег и регулярные поездки — система рассчитает потребность в газе.'],
        ['vote', 'Голосуйте за развитие', 'Поддержите инициативы или предложите точку, где не хватает заправки.'],
        ['clock', 'Следите за реализацией', 'Получайте уведомления о статусах, новых станциях и изменении сроков строительства.'],
      ].map(([ic, t, d]) => html`<div class="step"><div class="icon">${icon(ic, 28)}</div><h3>${t}</h3><p>${d}</p><span class="bar"></span></div>`)}
    </div>
  </div></section>

  <section class="section" style="padding-top:20px"><div class="wrap">
    <div class="section-head reveal"><div><span class="eyebrow">Возможности</span><h2 style="margin-top:12px">Всё о газомоторной сети — в одном месте</h2></div></div>
    <div class="grid g3 reveal">
      ${[
        ['/map', 'trucks-road', 'Карта', 'Карта газомоторной инфраструктуры', 'Действующие АГНКС, КриоАЗС, модульные станции, ПАГЗ, проекты и инициативы.'],
        ['/vote', 'highway', 'Сообщество', 'Где нужна новая АГНКС?', 'Голосуйте за участки трасс без заправок и предлагайте свои точки.'],
        ['/business', 'lng-truck', 'Бизнесу', 'Предложить договор сотрудничества', 'Автопарк, маршруты и объёмы газа — для долгосрочного сотрудничества с оператором.'],
        ['/routes', 'cng-dispenser', 'Маршруты', 'Планировщик газомоторного маршрута', 'Станции по пути, расход газа и участки, где запаса хода может не хватить.'],
        ['/plan', 'compressor', 'Развитие', 'План развития сети по годам', 'Подтверждённые объекты, проекты и инициативы — с указанием источника данных.'],
        ['/learn', 'bus', 'Знания', 'Обучающий раздел', 'Что такое КПГ и СПГ, виды станций, как перейти на метан и рассчитать потребность.'],
      ].map(([href, ph, tag, t, d]) => html`<a class="tile" href="${href}" style="${raw(photoBg(ph, 900))}"><span class="arrow">${icon('arrow')}</span><span class="badge info plain">${tag}</span><h3>${t}</h3><p>${d}</p></a>`)}
    </div>
  </div></section>

  <section class="section" style="padding-top:10px"><div class="wrap">
    <div class="section-head reveal"><div><span class="eyebrow">Новости и развитие сети</span><h2 style="margin-top:12px">Перспективные объекты</h2></div><a class="btn" href="/plan">Весь план развития ${icon('arrow')}</a></div>
    <div class="grid g3" id="featured">${[1, 2, 3].map(() => raw('<div class="skeleton" style="min-height:330px"></div>'))}</div>
    <div class="notice warn" style="margin-top:18px">${icon('info')}<p>Все объекты в этом блоке — демонстрационные предложения и сценарии. Они не являются утверждёнными планами ПАО «Газпром» или какой-либо другой компании.</p></div>
  </div></section>

  <section class="section"><div class="wrap">
    <div class="grid g2 reveal" style="align-items:stretch">
      <div class="card pad" style="${raw(photoBg('trucks-road', 1200, 'linear-gradient(90deg,rgba(13,22,58,.96),rgba(13,22,58,.75))'))};background-size:cover;background-position:center;min-height:320px;display:flex;flex-direction:column;justify-content:flex-end">
        <span class="eyebrow">Для бизнеса</span>
        <h2 style="margin:14px 0 10px">Объединяем спрос перевозчиков на одном участке</h2>
        <p class="muted">Если маршруты нескольких компаний проходят через одну точку, платформа суммирует их автомобили и расчётную потребность без двойного учёта — так проще обосновать строительство станции.</p>
        <div class="form-actions"><a class="btn primary" href="/business">Предложить сотрудничество</a><a class="btn" href="/savings">Калькулятор экономии</a></div>
      </div>
      <div class="card pad"><span class="eyebrow">Новости</span><h2 style="margin:14px 0 18px">Публикации</h2><div id="news" class="grid" style="gap:0"></div><a class="btn sm" href="/news" style="margin-top:14px">Все новости</a></div>
    </div>
  </div></section>`);

  const [stats, plans, news] = await Promise.all([api.get('/api/stats/public'), api.get('/api/plans'), api.get('/api/news')]).catch(() => [null, null, null]);
  if (stats) {
    const vals = [stats.users, stats.companies, stats.stations, stats.proposals];
    $$('#stats .stat').forEach((el, i) => {
      animateCount(el.querySelector('.value'), vals[i].total);
      el.querySelector('.note').textContent = vals[i].demo ? `в т. ч. демонстрационных: ${fmt(vals[i].demo)}` : 'реальные записи платформы';
    });
  }
  if (plans) {
    const planned = plans.stations.filter((s) => s.status !== 'operational').sort((a, b) => (a.plannedYear || 0) - (b.plannedYear || 0));
    const pick = [planned.find((s) => s.plannedYear === 2027), planned.find((s) => s.plannedYear === 2028 && s.kind === 'modular') || planned.find((s) => s.plannedYear === 2028)].filter(Boolean);
    const initiative = plans.initiatives.sort((a, b) => b.votes - a.votes)[0];
    $('#featured').innerHTML = String(html`
      ${pick.map((s) => html`<a class="card hover photo-card" href="/map?station=${s.id}">
        <div class="ph" style="${raw(photoBg(s.photoKey || 'compressor', 900))}"><div class="badges">${statusBadge(s.status, s.status === 'construction' ? 'Строится' : 'Проектируется')}${demoBadge(s.isDemo)}</div></div>
        <div class="body"><span class="tiny muted">${LABELS.kind[s.kind]} · ${s.region}</span><h3>${s.status === 'construction' ? 'Строящийся объект' : 'Перспективная станция'} — ${s.plannedYear || '—'} год</h3><p class="small muted" style="margin:0">${s.name}</p>
        <div class="foot"><span class="badge gray plain">${LABELS.planCategory[s.planCategory] || 'План'}</span><span class="small">Подробнее →</span></div></div></a>`)}
      ${initiative ? html`<a class="card hover photo-card" href="/vote/${initiative.id}">
        <div class="ph" style="${raw(photoBg(initiative.photoKey || 'highway', 900))}"><div class="badges">${statusBadge('published', 'Инициатива пользователей')}${demoBadge(initiative.isDemo)}</div></div>
        <div class="body"><span class="tiny muted">${initiative.region}${initiative.highway ? ' · ' + initiative.highway : ''}</span><h3>Предложение пользователей: новая станция на трассе</h3><p class="small muted" style="margin:0">${initiative.title}</p>
        <div class="foot"><span><b style="font-size:20px">${fmt(initiative.votes)}</b> <span class="muted small">голосов</span></span><span class="small">Поддержать →</span></div></div></a>` : ''}`);
  }
  if (news) {
    $('#news').innerHTML = String(html`${news.items.slice(0, 4).map((n) => html`<a href="/news/${n.slug}" style="display:block;padding:14px 0;border-bottom:1px solid var(--line);color:#fff"><div class="tiny muted">${date(n.publishedAt)} ${n.isDemo ? '· демо-публикация' : ''}</div><div style="font-weight:600;margin-top:3px">${n.title}</div></a>`)}`);
  }
}
