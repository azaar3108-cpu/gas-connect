// Планировщик газомоторного маршрута и калькулятор экономии.
import { html, raw, api, $, $$, fmt, money, photoBg, icon, setTitle, state, LABELS, toast, showError, field, bindForm, formValues, cityDatalist, loadCities, qs } from '../core.js';
import { createMap, stationIcon, pointIcon, leaflet } from '../components/map.js';
import { savings as calcSavings } from '../shared/calc.js';

export async function planner(ctx) {
  setTitle('Планировщик газомоторного маршрута');
  await loadCities().catch(() => {});
  let vehicles = [];
  if (state.user) {
    const [a, b] = await Promise.all([api.get('/api/vehicles').catch(() => ({ items: [] })), state.user.organization ? api.get('/api/vehicles?scope=fleet').catch(() => ({ items: [] })) : { items: [] }]);
    vehicles = [...a.items, ...b.items].filter((v) => v.metrics?.methane);
  }
  const q = ctx.query;
  ctx.app.innerHTML = String(html`
  <section class="page-hero photo" style="${raw(photoBg('trucks-road', 1800))}"><div class="wrap">
    <span class="eyebrow">Маршруты</span><h1>Планировщик газомоторного маршрута</h1>
    <p class="lead">Постройте маршрут и узнайте, где по пути есть подходящие станции, сколько газа понадобится и на каких участках может не хватить запаса хода.</p>
  </div></section>
  <section class="section tight"><div class="wrap">
    <div class="grid" style="grid-template-columns:minmax(0,380px) minmax(0,1fr);gap:22px" id="pgrid">
      <form class="card pad form" id="pf">
        ${field('originName', 'Начальный пункт', { required: true, list: 'cities', value: q.fromName || (state.user?.city && state.user.city !== (q.toName || 'Владивосток') ? state.user.city : 'Хабаровск') })}
        <div id="wps"></div>
        <button type="button" class="linkbtn small" id="addWp" style="justify-self:start">${icon('plus', 14)} Добавить промежуточную точку</button>
        ${field('destName', 'Конечный пункт', { required: true, list: 'cities', value: q.toName || 'Владивосток' })}
        <input type="hidden" name="destLat" value="${q.toLat || ''}"><input type="hidden" name="destLng" value="${q.toLng || ''}">
        ${vehicles.length ? field('vehicleId', 'Автомобиль', { options: [['', '— указать параметры вручную —'], ...vehicles.map((v) => [v.id, `${v.make} ${v.model} (${v.fuelLabel}${v.organizationId ? ', автопарк' : ''})`])] }) : ''}
        <div class="form-grid" id="manual">
          ${field('fuel', 'Топливо', { options: { cng: 'КПГ (м³)', lng: 'СПГ (кг)' } })}
          ${field('fullStock', 'Полный запас газа', { type: 'number', min: 1, step: 'any', value: 80, hint: 'м³ для КПГ, кг для СПГ' })}
          ${field('consumption', 'Средний расход на 100 км', { type: 'number', min: 1, step: 'any', value: 18 })}
          ${field('startStockPct', 'Запас на старте, %', { type: 'number', min: 0, max: 100, value: 100 })}
        </div>
        <div class="form-grid">
          ${field('deviationKm', 'Допустимое отклонение, км', { type: 'number', min: 0, max: 100, value: 10 })}
          ${field('reservePct', 'Резерв запаса хода, %', { type: 'number', min: 0, max: 40, value: 10 })}
        </div>
        <button class="btn primary lg" type="submit">${icon('route')} Построить маршрут</button>
        <p class="tiny muted" style="margin:0">Расстояния считаются по дорожному графу OpenStreetMap (OSRM). Если маршрутизатор недоступен, расчёт явно помечается как демонстрационная оценка.</p>
      </form>
      <div class="grid" style="gap:18px;align-content:start">
        <div class="card" style="overflow:hidden"><div id="rmap" class="leaflet-host" style="height:460px"></div></div>
        <div id="result"><div class="empty">Заполните параметры и нажмите «Построить маршрут».</div></div>
      </div>
    </div>
    ${cityDatalist()}
  </div></section>`);
  if (matchMedia('(max-width: 980px)').matches) $('#pgrid').style.gridTemplateColumns = '1fr';
  const L = await leaflet();
  const m = await createMap($('#rmap'), { zoom: 3 });
  const layer = L.layerGroup().addTo(m);
  ctx.cleanup = () => m.remove();

  let wpN = 0;
  $('#addWp').onclick = () => {
    if (wpN >= 6) return;
    wpN++;
    const div = document.createElement('div');
    div.className = 'field';
    div.innerHTML = `<label>Промежуточная точка</label><div style="display:flex;gap:6px"><input name="wp${wpN}" list="cities" placeholder="Город"><button type="button" class="btn sm ghost" aria-label="Удалить">×</button></div>`;
    div.querySelector('button').onclick = () => div.remove();
    $('#wps').append(div);
  };
  const vSel = $('#pf [name=vehicleId]');
  const syncManual = () => { $('#manual').style.opacity = vSel?.value ? '.45' : '1'; };
  vSel?.addEventListener('change', syncManual);
  $('#pf [name=destName]').addEventListener('input', () => { $('#pf [name=destLat]').value = ''; $('#pf [name=destLng]').value = ''; });

  bindForm($('#pf'), async (v) => {
    const body = { ...v, waypoints: Object.keys(v).filter((k) => /^wp\d+$/.test(k) && v[k]).map((k) => ({ name: v[k] })) };
    Object.keys(body).filter((k) => /^wp\d+$/.test(k)).forEach((k) => delete body[k]);
    if (body.vehicleId) { delete body.fullStock; delete body.consumption; } else delete body.vehicleId;
    const r = await api.post('/api/planner', body);
    draw(r);
  });

  function draw(r) {
    layer.clearLayers();
    const a = r.analysis;
    for (const alt of r.alternatives) L.polyline(alt.line, { color: '#9b7bff', weight: 4, opacity: .5, dashArray: '6 8' }).addTo(layer).bindTooltip(`Альтернатива: ${fmt(alt.distanceKm)} км`);
    const line = L.polyline(r.route.line, { color: '#47c8f5', weight: 5, opacity: .95 }).addTo(layer);
    for (const g of a.gaps) {
      L.circleMarker(g.mid, { radius: 10, color: '#f06272', fillColor: '#f06272', fillOpacity: .6 }).addTo(layer).bindTooltip(`Участок дефицита: ${g.fromKm}–${g.toKm} км`);
    }
    L.marker([r.points.origin.lat, r.points.origin.lng], { icon: pointIcon(L, '#22a779', 'А') }).addTo(layer).bindTooltip(r.points.origin.name);
    L.marker([r.points.destination.lat, r.points.destination.lng], { icon: pointIcon(L, '#47c8f5', 'Б') }).addTo(layer).bindTooltip(r.points.destination.name);
    r.points.waypoints.forEach((w, i) => L.marker([w.lat, w.lng], { icon: pointIcon(L, '#e9eef9', String(i + 1)) }).addTo(layer).bindTooltip(w.name));
    for (const s of a.stationsOnRoute) L.marker([s.lat, s.lng], { icon: stationIcon(L, { ...s, status: 'operational' }) }).addTo(layer).bindTooltip(`${s.name} · ${s.alongKm} км от старта`);
    m.fitBounds(line.getBounds(), { padding: [30, 30] });
    const unit = r.unit;
    $('#result').innerHTML = String(html`
      <div class="notice ${r.route.source === 'osrm' ? '' : 'warn'}">${icon(r.route.source === 'osrm' ? 'info' : 'warn')}<p>${r.disclaimer}</p></div>
      <div class="grid g4" style="margin-top:14px">
        <div class="kpi accent"><div class="v">${fmt(r.route.distanceKm)} км</div><div class="l">Расстояние${r.route.durationMin ? ` · ~${fmt(r.route.durationMin / 60, 1)} ч` : ''}</div><div class="s">${r.route.source === 'osrm' ? 'по дорогам' : 'оценка'}</div></div>
        <div class="kpi"><div class="v">${fmt(r.gasNeeded)} ${unit}</div><div class="l">Расчётный расход газа</div><div class="s">${fmt(r.consumption, 1)} ${unit}/100 км${r.vehicle ? ' · ' + r.vehicle : ''}</div></div>
        <div class="kpi"><div class="v">${fmt(r.fullRangeKm)} км</div><div class="l">Запас хода на полном баке</div><div class="s">с резервом: ${fmt(a.effectiveRangeKm)} км</div></div>
        <div class="kpi"><div class="v">${a.stationsOnRoute.length}</div><div class="l">Станций ${r.fuel === 'lng' ? 'СПГ' : 'КПГ'} по пути</div><div class="s">в пределах отклонения</div></div>
      </div>
      <div class="card pad" style="margin-top:16px">
        ${a.feasible ? html`<div class="notice ok">${icon('check')}<p>Маршрут проходим на газе при заданных параметрах. Рекомендуемые остановки для заправки указаны ниже.</p></div>`
          : html`<div class="notice danger">${icon('warn')}<p>На маршруте есть ${a.gaps.length} ${a.gaps.length === 1 ? 'участок' : 'участка(ов)'}, где запаса хода может не хватить. Вы можете предложить строительство станции — это поможет оператору увидеть спрос.</p></div>`}
        <h3 style="margin-top:18px">Станции по пути</h3>
        ${a.stationsOnRoute.length ? html`<div class="table-wrap"><table class="table"><thead><tr><th>Станция</th><th class="num">От старта</th><th class="num">Отклонение</th><th>Режим</th><th></th></tr></thead><tbody>
          ${a.stationsOnRoute.map((s) => html`<tr><td><b>${s.name}</b> ${s.isDemo ? html`<span class="badge demo">демо</span>` : ''}<div class="tiny muted">${LABELS.kind[s.kind]} · ${s.region}</div></td><td class="num">${fmt(s.alongKm)} км</td><td class="num">${fmt(s.deviationKm, 1)} км</td><td>${s.hours || 'не указан'}</td><td>${a.refuelStops.some((x) => x.id === s.id && !x.unreachable) ? html`<span class="badge ok plain">Рекомендуемая остановка</span>` : ''}</td></tr>`)}
        </tbody></table></div>` : html`<p class="muted">Подходящих действующих станций вдоль маршрута не найдено.</p>`}
        ${a.gaps.length ? html`<h3 style="margin-top:20px">Участки возможного дефицита заправок</h3>
          <div class="grid" style="gap:10px">${a.gaps.map((g) => html`<div class="msg" style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><div><b>${fmt(g.fromKm)}–${fmt(g.toKm)} км от старта</b><div class="small muted">Протяжённость ≈ ${fmt(g.lengthKm)} км без доступной заправки в пределах запаса хода</div></div>
            <a class="btn sm primary" href="/vote/new${qs({ lat: g.mid[0].toFixed(4), lng: g.mid[1].toFixed(4), gapKm: g.lengthKm, kind: r.fuel === 'lng' ? 'cryo' : 'agnks' })}">${icon('plus', 14)} Предложить станцию здесь</a></div>`)}</div>` : ''}
        ${r.alternatives.length ? html`<h3 style="margin-top:20px">Альтернативные варианты</h3><div class="grid g2">${r.alternatives.map((alt, i) => html`<div class="kpi"><div class="v">${fmt(alt.distanceKm)} км</div><div class="l">Вариант ${i + 2}: станций по пути — ${alt.stations}, участков дефицита — ${alt.gaps}</div><div class="s">${alt.feasible ? 'проходим на газе' : 'есть участки дефицита'}</div></div>`)}</div>`
          : html`<p class="tiny muted" style="margin-top:16px">Альтернативные варианты показываются, когда маршрутизатор их предлагает (для маршрутов без промежуточных точек).</p>`}
        ${!state.user ? html`<p class="small muted" style="margin-top:16px"><a href="/register">Зарегистрируйтесь</a>, чтобы сохранять регулярные маршруты и получать уведомления о новых станциях на них.</p>` : ''}
      </div>`);
  }
  if (q.toName) $('#pf').requestSubmit();
}

export async function savings(ctx) {
  setTitle('Калькулятор экономии');
  ctx.app.innerHTML = String(html`
  <section class="page-hero photo" style="${raw(photoBg('cng-dispenser', 1800))}"><div class="wrap">
    <span class="eyebrow">Калькулятор</span><h1>Калькулятор экономии на газомоторном топливе</h1>
    <p class="lead">Сравните ориентировочные затраты на КПГ или СПГ с бензином или дизелем. Цены вводите сами — платформа не подставляет непроверенные рыночные данные.</p>
  </div></section>
  <section class="section tight"><div class="wrap">
    <div class="grid g2">
      <form class="card pad form" id="sf">
        <div class="form-grid">
          ${field('vehicles', 'Количество автомобилей', { type: 'number', min: 1, value: 1 })}
          ${field('monthlyKm', 'Пробег одного автомобиля, км/мес.', { type: 'number', min: 0, value: 3000 })}
          ${field('liquidConsumption', 'Расход бензина/дизеля, л/100 км', { type: 'number', min: 0, step: 'any', value: 10 })}
          ${field('liquidPrice', 'Цена бензина/дизеля, ₽/л', { type: 'number', min: 0, step: 'any', value: '', placeholder: 'введите цену' })}
          ${field('gasConsumption', 'Расход газа, м³ (КПГ) или кг (СПГ) на 100 км', { type: 'number', min: 0, step: 'any', value: 10 })}
          ${field('gasPrice', 'Цена газа, ₽/м³ или ₽/кг', { type: 'number', min: 0, step: 'any', value: '', placeholder: 'введите цену' })}
          ${field('gasShare', 'Доля пробега на газе, %', { type: 'number', min: 0, max: 100, value: 100, hint: 'для битопливных и газодизельных автомобилей — меньше 100 %' })}
          ${field('conversionCost', 'Стоимость переоборудования одного ТС, ₽', { type: 'number', min: 0, value: '', hint: 'необязательно — для расчёта окупаемости' })}
        </div>
        <p class="tiny muted" style="margin:0">Цены укажите по данным вашей АЗС/АГНКС или договора. Расчёт ориентировочный: не учитывает стоимость обслуживания ГБО, изменения цен и налоговые эффекты.</p>
      </form>
      <div class="card pad" id="sres"></div>
    </div>
  </div></section>`);
  const form = $('#sf');
  const recalc = () => {
    const v = formValues(form);
    const r = calcSavings(v);
    if (!v.liquidPrice || !v.gasPrice) { $('#sres').innerHTML = String(html`<div class="empty"><h3>Введите цены топлива</h3><p>Укажите цену бензина/дизеля и газа, чтобы увидеть сравнение.</p></div>`); return; }
    $('#sres').innerHTML = String(html`
      <h3>Результат</h3>
      <div class="grid g2"><div class="kpi"><div class="v">${money(r.monthlyLiquid)}</div><div class="l">в месяц на бензине/дизеле</div></div><div class="kpi"><div class="v">${money(r.monthlyGas)}</div><div class="l">в месяц с газом</div></div></div>
      <div class="kpi accent" style="margin-top:12px"><div class="v">${money(r.monthlySaving)} / мес.</div><div class="l">ориентировочная экономия · ${money(r.annualSaving)} в год${r.savingPct !== null ? ` · ${fmt(r.savingPct, 1)} %` : ''}</div></div>
      <div class="dl" style="margin-top:12px"><div>Потребление газа</div><div>${fmt(r.monthlyGasVolume)} м³ (кг) в месяц</div><div>Окупаемость переоборудования</div><div>${r.paybackMonths ? `${fmt(r.paybackMonths, 1)} мес.` : 'укажите стоимость переоборудования'}</div></div>
      <div class="form-actions" style="margin-top:16px"><a class="btn sm" href="/learn/conversion">Как перейти на метан</a><a class="btn sm" href="/routes">Проверить маршрут</a></div>`);
  };
  form.addEventListener('input', recalc);
  recalc();
}
