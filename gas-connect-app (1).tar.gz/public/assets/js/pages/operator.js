// Кабинет оператора платформы: аналитика, заявки, модерация, станции, инвестиционный калькулятор, отчёты.
import { html, raw, api, $, $$, fmt, mln, money, icon, statusBadge, demoBadge, setTitle, state, LABELS, date, dateTime, toast, showError, go, field, checkbox, bindForm, modal, confirmDialog, formValues, setFormValues, regionDatalist, isStaff, plural } from '../core.js';
import { bars, donut, columns, lines } from '../components/charts.js';
import { createMap, pickerMap, leaflet } from '../components/map.js';
import { investmentModel, SCENARIO_DEFAULTS, INVESTMENT_DEFAULTS, MODEL_LIMITATIONS } from '../shared/calc.js';

const TABS = [
  ['', 'Сводка и аналитика', 'chart'], ['segments', 'Перспективные участки', 'pin'], ['offers', 'Коммерческие предложения', 'doc'], ['contracts', 'Договорённости', 'check'],
  ['orgs', 'Проверка организаций', 'building'], ['proposals', 'Модерация инициатив', 'vote'], ['comments', 'Модерация комментариев', 'mail'], ['stations', 'Станции и план', 'fuel'],
  ['invest', 'Оценка строительства АГНКС', 'calc'], ['news', 'Новости', 'news'], ['feedback', 'Обратная связь', 'info'], ['audit', 'Журнал действий', 'shield'],
];
const ADMIN_TABS = [['users', 'Пользователи и роли', 'people'], ['outbox', 'Журнал писем', 'mail']];
let META = null;

export async function page(ctx) {
  if (!state.user) { go(`/login?next=${encodeURIComponent(location.pathname)}`, { replace: true }); return; }
  if (!isStaff()) {
    ctx.app.innerHTML = String(html`<section class="section"><div class="wrap"><div class="empty"><h3>Доступ ограничен</h3><p>Панель оператора доступна только авторизованным сотрудникам с соответствующими правами. Проверка выполняется на сервере.</p><a class="btn" href="/account">В личный кабинет</a></div></div></section>`);
    return;
  }
  setTitle('Панель оператора');
  META ||= await api.get('/api/op/meta');
  const tab = ctx.params.tab || '';
  const all = [...TABS, ...(state.user.role === 'admin' ? ADMIN_TABS : [])];
  const dash = await api.get('/api/op/dashboard').catch(() => null);
  const q = dash?.queue || {};
  const badge = { offers: q.offersNew, orgs: q.orgsPending, proposals: q.proposalsPending, comments: q.commentsPending, feedback: q.feedbackNew };
  ctx.app.innerHTML = String(html`<div class="wrap layout">
    <aside class="side"><div class="who"><span class="eyebrow" style="font-size:10px">Оператор платформы</span><strong style="margin-top:8px">${state.user.name}</strong><span class="tiny muted">${LABELS.role[state.user.role]}</span></div>
      ${all.map(([k, l, ic], i) => html`${i === TABS.length ? html`<div class="group">Администрирование</div>` : ''}<a href="/operator${k ? '/' + k : ''}" class="${tab === k ? 'active' : ''}">${icon(ic, 17)} ${l}${badge[k] ? html`<span class="n">${badge[k]}</span>` : ''}</a>`)}
    </aside><div id="pane" style="min-width:0"><div class="skeleton" style="min-height:300px"></div></div></div>`);
  const pane = $('#pane');
  const fns = { '': () => dashboard(pane, dash), segments, offers: () => (ctx.params.id ? offerDetail(pane, ctx.params.id) : offers(pane, ctx)), contracts, orgs, proposals, comments, stations, invest, news, feedback, audit, users, outbox };
  const fn = fns[tab];
  if (!fn) { pane.innerHTML = '<div class="empty">Раздел не найден</div>'; return; }
  try { await fn(pane, ctx); } catch (e) { pane.innerHTML = String(html`<div class="empty"><h3>Ошибка загрузки</h3><p>${e.message}</p></div>`); }
}
const head = (t, s, a = '') => html`<div class="content-head"><div><h1>${t}</h1>${s ? html`<p>${s}</p>` : ''}</div><div class="form-actions">${a}</div></div>`;
const exportBtn = (kind, label) => html`<a class="btn sm" href="/api/op/export/${kind}" download>${icon('download', 14)} ${label}</a>`;

// ---------- Сводка ----------
function dashboard(pane, d) {
  const t = d.demand.totals;
  const regions = d.demand.regions.slice(0, 10);
  pane.innerHTML = String(html`${head('Сводка и аналитика', 'Показатели рассчитываются по данным платформы в реальном времени.', html`${exportBtn('demand', 'Спрос по регионам')}${exportBtn('offers', 'Предложения')}${exportBtn('proposals', 'Инициативы')}${exportBtn('stations', 'Станции')}${exportBtn('organizations', 'Организации')}`)}
    <div class="grid g4">
      ${[['Пользователей всего', d.users.total, `подтвердили e-mail: ${fmt(d.users.verifiedEmail)}`], ['Физических лиц', d.users.person], ['Индивидуальных предпринимателей', d.users.ip], ['Юридических лиц (пользователей)', d.users.company, `организаций: ${fmt(d.organizations.total)}`],
        ['Зарегистрированных ТС', d.vehicles.total, `прочие (кандидаты на перевод): ${fmt(d.vehicles.other)}`], ['ТС на КПГ', d.vehicles.cng], ['ТС на СПГ', d.vehicles.lng], ['Заявленных маршрутов', d.routes],
        ['Голосов', d.votes], ['Инициатив', Object.values(d.proposals).reduce((a, b) => a + b, 0), `на модерации: ${fmt(d.proposals.pending || 0)}`], ['Коммерческих предложений', Object.entries(d.offers).filter(([k]) => k !== 'draft').reduce((a, [, b]) => a + b, 0), `новых: ${fmt(d.offers.submitted || 0)}`], ['Станций в базе', Object.values(d.stations).reduce((a, b) => a + b, 0), `действующих: ${fmt(d.stations.operational || 0)}`]]
        .map(([l, v, s], i) => html`<div class="kpi ${i === 0 ? 'accent' : ''}"><div class="v">${fmt(v)}</div><div class="l">${l}</div>${s ? html`<div class="s">${s}</div>` : ''}</div>`)}
    </div>
    <h2 style="margin:34px 0 6px">Три уровня спроса</h2><p class="muted small">Показатели не смешиваются в одно число: интерес, расчётный и договорной спрос имеют разную природу и достоверность.</p>
    <div class="grid g3" style="margin-top:14px">
      <div class="tier t1"><div class="lvl">Уровень 1</div><h3>Интерес</h3><div class="big">${fmt(t.interest.votes)} голосов</div><div class="small muted" style="margin-top:6px">${fmt(t.interest.proposals)} опубликованных инициатив · заявлено ${fmt(t.interest.declaredVehicles)} ТС</div></div>
      <div class="tier t2"><div class="lvl">Уровень 2</div><h3>Расчётный спрос</h3><div class="big">${fmt(t.estimated.m3)} м³ КПГ</div><div class="big" style="font-size:22px">${fmt(t.estimated.kg)} кг СПГ <span class="small muted">в месяц</span></div><div class="small muted" style="margin-top:6px">по ${fmt(t.estimated.vehicles)} ТС · отдельно заявлено в предложениях: ${fmt(t.estimated.offersM3)} м³ и ${fmt(t.estimated.offersKg)} кг</div></div>
      <div class="tier t3"><div class="lvl">Уровень 3</div><h3>Договорной спрос</h3><div class="big">${fmt(t.contracted.m3)} м³ КПГ</div><div class="big" style="font-size:22px">${fmt(t.contracted.kg)} кг СПГ <span class="small muted">в месяц</span></div><div class="small muted" style="margin-top:6px">договорённости, подтверждённые оператором</div></div>
    </div>
    <details class="card pad" style="margin-top:14px"><summary style="cursor:pointer;font-weight:600">Методика расчёта</summary><ul class="small muted" style="margin:12px 0 0">${d.demand.methodology.map((m) => html`<li>${m}</li>`)}</ul></details>
    <div class="grid g2" style="margin-top:22px">
      <div class="card pad"><h3>Регистрации за 12 месяцев</h3>${columns(d.registrations.map((m) => m.month.slice(5) + '.' + m.month.slice(2, 4)), [{ name: 'Физлица', values: d.registrations.map((m) => m.person) }, { name: 'ИП', values: d.registrations.map((m) => m.ip) }, { name: 'Юрлица', values: d.registrations.map((m) => m.company) }])}</div>
      <div class="card pad"><h3>Структура участников</h3>${donut([{ label: 'Физические лица', value: d.users.person }, { label: 'ИП', value: d.users.ip }, { label: 'Юридические лица', value: d.users.company }], { title: 'пользователей' })}
        <h3 style="margin-top:22px">Транспорт по топливу</h3>${donut([{ label: 'КПГ', value: d.vehicles.cng }, { label: 'СПГ', value: d.vehicles.lng }, { label: 'Прочие', value: d.vehicles.other }], { title: 'ТС', size: 170 })}</div>
    </div>
    <div class="card pad" style="margin-top:22px"><h3>Региональный рейтинг спроса</h3>
      <div class="table-wrap"><table class="table"><thead><tr><th>Регион</th><th class="num">Голоса (ур. 1)</th><th class="num">ТС</th><th class="num">Расчёт КПГ, м³/мес. (ур. 2)</th><th class="num">Расчёт СПГ, кг/мес. (ур. 2)</th><th class="num">Заявлено в предложениях</th><th class="num">Договорной (ур. 3)</th></tr></thead><tbody>
      ${regions.map((r) => html`<tr><td>${r.region}</td><td class="num">${fmt(r.votes)}</td><td class="num">${fmt(r.vehicles)}</td><td class="num">${fmt(r.estimatedM3)}</td><td class="num">${fmt(r.estimatedKg)}</td><td class="num">${r.offersM3 ? fmt(r.offersM3) + ' м³' : ''} ${r.offersKg ? fmt(r.offersKg) + ' кг' : ''}</td><td class="num">${r.contractM3 ? fmt(r.contractM3) + ' м³' : ''} ${r.contractKg ? fmt(r.contractKg) + ' кг' : ''}</td></tr>`)}
      </tbody></table></div>
      <div class="grid g2" style="margin-top:18px"><div><h4 class="small muted">Расчётный спрос КПГ по регионам, м³/мес.</h4>${bars(regions.filter((r) => r.estimatedM3).map((r) => ({ label: r.region, value: r.estimatedM3 })))}</div><div><h4 class="small muted">Голоса по регионам</h4>${bars(regions.filter((r) => r.votes).map((r) => ({ label: r.region, value: r.votes })), { colors: ['#9b7bff'] })}</div></div>
    </div>`);
}

// ---------- Перспективные участки ----------
async function segments(pane) {
  const data = await api.get('/api/op/segments');
  pane.innerHTML = String(html`${head('Перспективные участки строительства', 'Инициативы пользователей и проектируемые объекты с объединённым спросом участников, чьи маршруты проходят рядом.', exportBtn('proposals', 'Выгрузить CSV'))}
    <div class="notice" style="margin-bottom:16px">${icon('info')}<p>${data.formula}</p></div>
    <div class="card" style="overflow:hidden;margin-bottom:18px"><div id="smap" class="leaflet-host" style="height:380px"></div></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Участок</th><th>Статус</th><th class="num">Приоритет</th><th class="num">Голоса</th><th class="num">ТС без двойного учёта</th><th class="num">Организаций</th><th class="num">КПГ, м³/мес.</th><th class="num">СПГ, кг/мес.</th><th class="num">До действующей</th></tr></thead><tbody>
    ${data.items.map((s, i) => html`<tr><td>${i + 1}</td><td><a href="${s.type === 'proposal' ? '/vote/' + s.id : '/map?station=' + s.id}"><b>${s.title}</b></a> ${demoBadge(s.isDemo)}<div class="tiny muted">${s.region}${s.type === 'station' ? ' · проект оператора' + (s.plannedYear ? ', ' + s.plannedYear : '') : ' · инициатива'}</div>${s.demand.multiCompany ? html`<span class="badge info plain" style="margin-top:4px">объединённый спрос ${s.demand.organizations} компаний</span>` : ''}</td>
      <td>${statusBadge(s.status, s.statusLabel)}</td><td class="num"><b style="font-size:16px">${s.score}</b></td><td class="num">${fmt(s.votes)}</td><td class="num">${fmt(s.demand.vehiclesTotal)}</td><td class="num">${fmt(s.demand.organizations)}</td><td class="num">${fmt(s.demand.demandM3)}</td><td class="num">${fmt(s.demand.demandKg)}</td><td class="num">${s.nearestKm !== null ? fmt(s.nearestKm) + ' км' : '—'}</td></tr>`)}
    </tbody></table></div>`);
  const L = await leaflet();
  const m = await createMap($('#smap'), { zoom: 3, scrollWheelZoom: false });
  const max = Math.max(1, ...data.items.map((x) => x.score));
  data.items.forEach((s) => L.circleMarker([s.lat, s.lng], { radius: 6 + (s.score / max) * 18, color: s.type === 'proposal' ? '#e9eef9' : '#9b7bff', fillColor: s.type === 'proposal' ? '#47c8f5' : '#9b7bff', fillOpacity: .45, weight: 2 }).bindTooltip(`${s.title}: приоритет ${s.score}`).addTo(m));
}

// ---------- Коммерческие предложения ----------
async function offers(pane, ctx) {
  const st = ctx.query.status || '';
  const data = await api.get(`/api/op/offers${st ? '?status=' + st : ''}`);
  pane.innerHTML = String(html`${head('Коммерческие предложения', 'Заявки ИП и юридических лиц о сотрудничестве по поставке газомоторного топлива.', exportBtn('offers', 'Выгрузить CSV'))}
    <div class="chips" style="margin-bottom:16px"><a class="chip ${!st ? 'active' : ''}" href="/operator/offers">Все</a>${Object.entries(data.statuses).filter(([k]) => k !== 'draft').map(([k, l]) => html`<a class="chip ${st === k ? 'active' : ''}" href="/operator/offers?status=${k}">${l}</a>`)}</div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Организация / предложение</th><th>Статус</th><th class="num">Объём в месяц</th><th class="num">Мин. гарантия</th><th class="num">Срок</th><th class="num">ТС</th><th>Отправлено</th></tr></thead><tbody>
    ${data.items.map((o) => html`<tr><td><a href="/operator/offers/${o.id}"><b>${o.organizationName}</b></a> ${demoBadge(o.isDemo)}<div class="tiny muted">${o.title} · ${statusBadge(o.organizationVerification, LABELS.verification[o.organizationVerification])}</div></td><td>${statusBadge(o.status, o.statusLabel)}</td><td class="num">${fmt(o.monthlyVolume)} ${o.volumeUnit}</td><td class="num">${o.minGuaranteedVolume ? fmt(o.minGuaranteedVolume) + ' ' + o.volumeUnit : '—'}</td><td class="num">${o.termMonths ? o.termMonths + ' мес.' : '—'}</td><td class="num">${fmt(o.vehiclesTotal)}</td><td>${dateTime(o.submittedAt)}</td></tr>`)}
    </tbody></table></div>${!data.items.length ? html`<div class="empty" style="margin-top:12px">Нет предложений в этом статусе</div>` : ''}`);
}

async function offerDetail(pane, id) {
  const { item: o, fleet, contracts: cs, transitions } = await api.get(`/api/op/offers/${id}`);
  const d = (l, v) => html`<div>${l}</div><div style="white-space:pre-wrap">${v === null || v === undefined || v === '' ? '—' : v}</div>`;
  pane.innerHTML = String(html`${head(o.organization.name, o.title, html`${statusBadge(o.status, o.statusLabel)}${demoBadge(o.isDemo)}<a class="btn sm ghost" href="/operator/offers">← Все предложения</a>`)}
    <div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:22px" id="og">
      <div class="grid" style="gap:18px">
        <div class="card pad"><h3>Потребность</h3><div class="grid g3" style="gap:10px;margin-bottom:12px"><div class="kpi accent"><div class="v">${fmt(o.monthlyVolume)} ${o.volumeUnit}</div><div class="l">в месяц · ${o.fuelType === 'lng' ? 'СПГ' : 'КПГ'}</div></div><div class="kpi"><div class="v">${fmt(o.annualVolume)} ${o.volumeUnit}</div><div class="l">в год</div></div><div class="kpi"><div class="v">${o.minGuaranteedVolume ? fmt(o.minGuaranteedVolume) : '—'}</div><div class="l">мин. гарантия, ${o.volumeUnit}/мес.</div></div></div>
          <div class="dl">${d('Срок сотрудничества', o.termMonths ? o.termMonths + ' мес.' : null)}${d('Условия поставки', o.deliveryTerms)}</div></div>
        <div class="card pad"><h3>Организация</h3><div class="dl">${d('Наименование', o.orgName)}${d('ИНН', o.organization.inn)}${d('Регион', o.orgRegion)}${d('Представитель', o.representative)}${d('Контакты', [o.contactEmail, o.contactPhone].filter(Boolean).join(', '))}${d('Деятельность', o.activity)}${d('Проверка', LABELS.verification[o.organization.verification])}</div>
          <a class="btn sm" href="/operator/orgs?open=${o.organization.id}" style="margin-top:12px">${icon('shield', 14)} Карточка и проверка организации</a></div>
        <div class="card pad"><h3>Транспортный парк</h3><div class="dl">${d('Заявлено ТС', fmt(o.vehiclesTotal))}${d('Можно перевести', fmt(o.vehiclesConvertible))}${d('Марки и модели', o.makesModels)}${d('Средний пробег', o.avgMileageKm ? fmt(o.avgMileageKm) + ' км/мес.' : null)}${d('Сроки перевода', o.conversionTimeline)}${d('Зарегистрировано на платформе', `${fmt(fleet.vehicles)} ТС · расчёт ${fmt(fleet.demandM3)} м³ + ${fmt(fleet.demandKg)} кг в месяц`)}</div></div>
        <div class="card pad"><h3>Маршруты и ограничения</h3><div class="dl">${d('Направления', o.mainDirections)}${d('Частота', o.tripFrequency)}${d('Среднее расстояние', o.avgDistanceKm ? fmt(o.avgDistanceKm) + ' км' : null)}${d('Альтернативные пути', o.alternativePaths)}${d('Сезонные ограничения', o.seasonalLimits)}${d('Масса и габариты', o.weightLimits)}${d('Недоступные участки', o.unavailableSections)}${d('Обязательные остановки', o.mandatoryStops)}${d('Территории без инфраструктуры', o.underservedAreas)}${d('Пожелания к расположению', o.locationWishes)}${d('Ограничения', o.restrictions)}${d('Особые требования', o.specialRequirements)}${d('Комментарии', o.comments)}</div></div>
      </div>
      <aside class="grid" style="gap:18px;align-content:start">
        <form class="card pad form" id="stf"><h3 style="margin:0">Решение по заявке</h3>
          ${transitions.length ? html`${field('status', 'Новый статус', { options: transitions.map((t) => [t.value, t.label]) })}${field('comment', 'Комментарий оператора (виден организации)', { type: 'textarea', hint: 'обязателен для «Требуется уточнение» и «Отклонено»' })}<button class="btn primary" type="submit">Изменить статус и уведомить</button>` : html`<p class="small muted">Изменение статуса недоступно (черновик).</p>`}</form>
        <div class="card pad"><h3>История статусов</h3><div class="timeline">${o.history.map((h) => html`<div class="tl"><div class="when">${dateTime(h.at)}</div><b>${h.toLabel}</b>${h.comment ? html`<div class="small muted">${h.comment}</div>` : ''}</div>`)}</div></div>
        <div class="card pad"><h3>Переписка</h3><div class="grid" style="gap:10px">${o.messages.map((m) => html`<div class="msg ${m.side === 'operator' ? 'op' : ''}"><div class="who">${m.author} · ${dateTime(m.at)}</div><div style="white-space:pre-wrap">${m.body}</div></div>`)}</div>
          <form id="omf" class="form" style="margin-top:12px">${field('body', 'Сообщение организации', { type: 'textarea', required: true })}<button class="btn sm" type="submit">Отправить</button></form></div>
        <div class="card pad"><h3>Документы</h3>${o.documents.map((x) => html`<div style="padding:6px 0"><a href="/api/documents/${x.id}" download>${icon('doc', 15)} ${x.name}</a> <span class="tiny muted">${fmt(x.size / 1024)} КБ</span></div>`)}${!o.documents.length ? html`<p class="small muted">Нет документов</p>` : ''}</div>
        <div class="card pad"><h3>Договорённость (уровень 3)</h3>${cs.map((c) => html`<div class="msg" style="margin-bottom:8px">${statusBadge(c.status, c.statusLabel)} <b>${fmt(c.contractedMonthlyVolume)} ${c.volumeUnit}/мес.</b><div class="tiny muted">${c.startDate || ''} ${c.termMonths ? '· ' + c.termMonths + ' мес.' : ''}</div></div>`)}
          <form id="cf" class="form"><div class="form-grid">${field('status', 'Статус', { options: META.contractStatuses })}${field('contractedMonthlyVolume', `Объём в месяц, ${o.volumeUnit}`, { type: 'number', min: 0, step: 'any', required: true, value: o.minGuaranteedVolume || o.monthlyVolume })}${field('startDate', 'Дата начала', { type: 'date' })}${field('termMonths', 'Срок, мес.', { type: 'number', min: 1, value: o.termMonths })}</div>${field('note', 'Примечание', {})}<button class="btn sm success" type="submit">${icon('check', 14)} Зафиксировать договорённость</button><p class="tiny muted" style="margin:0">Учитывается в договорном спросе. Не является подписанием договора на платформе.</p></form></div>
      </aside>
    </div>`);
  if (matchMedia('(max-width: 1100px)').matches) $('#og').style.gridTemplateColumns = '1fr';
  if (transitions.length) bindForm($('#stf'), async (v) => { const r = await api.post(`/api/op/offers/${id}/status`, v); toast(r.message, 'ok'); offerDetail(pane, id); });
  bindForm($('#omf'), async (v) => { await api.post(`/api/op/offers/${id}/messages`, v); toast('Сообщение отправлено', 'ok'); offerDetail(pane, id); });
  bindForm($('#cf'), async (v) => { await api.post('/api/op/contracts', { ...v, organizationId: o.organization.id, offerId: o.id, fuelType: o.fuelType, volumeUnit: o.volumeUnit, region: o.orgRegion }); toast('Договорённость зафиксирована', 'ok'); offerDetail(pane, id); });
}

async function contracts(pane) {
  const data = await api.get('/api/op/contracts');
  pane.innerHTML = String(html`${head('Договорённости', 'Подтверждённые оператором договорённости — основа уровня «договорной спрос».')}
    <div class="table-wrap"><table class="table"><thead><tr><th>Организация</th><th>Статус</th><th class="num">Объём в месяц</th><th>Регион</th><th>Начало</th><th class="num">Срок</th><th></th></tr></thead><tbody>
    ${data.items.map((c) => html`<tr><td><b>${c.organizationName}</b> ${demoBadge(c.isDemo)}${c.note ? html`<div class="tiny muted">${c.note}</div>` : ''}</td><td>${statusBadge(c.status, c.statusLabel)}</td><td class="num">${fmt(c.contractedMonthlyVolume)} ${c.volumeUnit} ${c.fuelType === 'lng' ? 'СПГ' : 'КПГ'}</td><td>${c.region || '—'}</td><td>${c.startDate || '—'}</td><td class="num">${c.termMonths || '—'}</td><td><button class="btn sm" data-edit="${c.id}">${icon('edit', 14)}</button></td></tr>`)}
    </tbody></table></div>${!data.items.length ? html`<div class="empty" style="margin-top:12px">Договорённостей пока нет — их фиксируют в карточке коммерческого предложения.</div>` : ''}`);
  $$('[data-edit]').forEach((b) => (b.onclick = () => {
    const c = data.items.find((x) => x.id === b.dataset.edit);
    const m = modal({ title: 'Договорённость', body: html`<form class="form" id="ef"><div class="form-grid">${field('status', 'Статус', { options: data.statuses, value: c.status })}${field('contractedMonthlyVolume', `Объём в месяц, ${c.volumeUnit}`, { type: 'number', step: 'any', value: c.contractedMonthlyVolume })}${field('startDate', 'Дата начала', { type: 'date', value: c.startDate })}${field('termMonths', 'Срок, мес.', { type: 'number', value: c.termMonths })}${field('region', 'Регион', { value: c.region })}${field('note', 'Примечание', { value: c.note })}</div><button class="btn primary" type="submit">Сохранить</button></form>` });
    bindForm($('#ef', m.root), async (v) => { await api.put(`/api/op/contracts/${c.id}`, { ...v, fuelType: c.fuelType, volumeUnit: c.volumeUnit }); m.close(); toast('Сохранено', 'ok'); contracts(pane); });
  }));
}

// ---------- Организации ----------
async function orgs(pane, ctx) {
  const st = ctx.query.status || '';
  const data = await api.get(`/api/op/organizations${st ? '?status=' + st : ''}`);
  pane.innerHTML = String(html`${head('Проверка организаций', 'ИНН проверяется по контрольной сумме при регистрации; сверку с ЕГРЮЛ/ЕГРИП оператор выполняет вручную.', exportBtn('organizations', 'Выгрузить CSV'))}
    <div class="chips" style="margin-bottom:16px"><a class="chip ${!st ? 'active' : ''}" href="/operator/orgs">Все</a>${Object.entries(LABELS.verification).map(([k, l]) => html`<a class="chip ${st === k ? 'active' : ''}" href="/operator/orgs?status=${k}">${l}</a>`)}</div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Организация</th><th>ИНН</th><th>Регион</th><th class="num">ТС (заявл./зарег.)</th><th>Проверка</th><th></th></tr></thead><tbody>
    ${data.items.map((o) => html`<tr><td><b>${o.shortName || o.fullName}</b> ${demoBadge(o.isDemo)}<div class="tiny muted">${o.type === 'ip' ? 'ИП' : o.legalForm || 'Юрлицо'} · ${o.activity || ''}</div></td><td>${o.inn}</td><td>${o.region || '—'}</td><td class="num">${fmt(o.fleetSize)} / ${fmt(o.registeredVehicles)}</td><td>${statusBadge(o.verificationStatus, LABELS.verification[o.verificationStatus])}</td><td><button class="btn sm" data-open="${o.id}">Открыть</button></td></tr>`)}
    </tbody></table></div>`);
  const open = async (id) => {
    const r = await api.get(`/api/op/organizations/${id}`);
    const o = r.item;
    const m = modal({ title: o.shortName || o.fullName, wide: true, body: html`<div class="grid g2"><div class="dl">
      <div>Полное наименование</div><div>${o.fullName}</div><div>ИНН</div><div>${o.inn} <a href="${r.checkUrl}" target="_blank" rel="noopener" class="tiny">проверить в ЕГРЮЛ ↗</a></div><div>Форма</div><div>${o.legalForm || '—'}</div><div>Регион</div><div>${o.region || '—'}</div><div>Адрес</div><div>${o.legalAddress || '—'}</div><div>Деятельность</div><div>${o.activity || '—'}</div><div>Сотрудников</div><div>${fmt(o.employees)}</div><div>Контакт</div><div>${o.contactPerson || '—'}, ${o.contactPosition || ''} ${o.contactEmail || ''} ${o.contactPhone || ''}</div>
      </div><div><h4>Сотрудники на платформе</h4>${r.members.map((x) => html`<div class="small">${x.name} (${x.email}) — ${LABELS.member[x.role]}</div>`)}
      <h4 style="margin-top:16px">Автопарк</h4><div class="small">${fmt(r.fleet.vehicles)} ТС, расчёт ${fmt(r.fleet.demandM3)} м³ + ${fmt(r.fleet.demandKg)} кг в месяц, маршрутов: ${r.routes}</div>
      <h4 style="margin-top:16px">Предложения</h4>${r.offers.map((x) => html`<div class="small"><a href="/operator/offers/${x.id}">${x.title}</a> — ${x.statusLabel}</div>`)}${!r.offers.length ? html`<div class="small muted">нет</div>` : ''}</div></div>
      <form class="form" id="vf" style="margin-top:18px"><div class="form-grid">${field('status', 'Результат проверки', { options: { verified: 'Подтвердить', rejected: 'Отказать', pending: 'Вернуть на проверку' }, value: o.verificationStatus === 'verified' ? 'verified' : 'verified' })}${field('note', 'Комментарий', { value: o.verificationNote })}</div><button class="btn primary" type="submit">Сохранить решение</button></form>` });
    bindForm($('#vf', m.root), async (v) => { await api.post(`/api/op/organizations/${id}/verify`, v); m.close(); toast('Решение сохранено, организация уведомлена', 'ok'); orgs(pane, ctx); });
  };
  $$('[data-open]').forEach((b) => (b.onclick = () => open(b.dataset.open).catch(showError)));
  if (ctx.query.open) open(ctx.query.open).catch(showError);
}

// ---------- Модерация инициатив ----------
async function proposals(pane, ctx) {
  const st = ctx.query.status || 'pending';
  const data = await api.get(`/api/op/proposals?status=${st}`);
  pane.innerHTML = String(html`${head('Модерация инициатив', 'Публикация, отклонение, передача на рассмотрение и включение инициатив в план развития.')}
    <div class="chips" style="margin-bottom:16px">${Object.entries(data.statuses).map(([k, l]) => html`<a class="chip ${st === k ? 'active' : ''}" href="/operator/proposals?status=${k}">${l}</a>`)}</div>
    <div class="grid" style="gap:14px">${data.items.map((p) => html`<div class="card pad"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><a href="/vote/${p.id}"><h3 style="margin:0">${p.title}</h3></a><div class="small muted">${p.region} · ${p.highway || 'трасса не указана'} · ${p.lat.toFixed(3)}, ${p.lng.toFixed(3)} · голосов: ${p.votes}</div></div><div class="chips">${statusBadge(p.status, p.statusLabel)}${demoBadge(p.isDemo)}</div></div>
      <p class="small" style="margin:10px 0">${p.justification}</p>
      <div class="tiny muted">Автор: ${p.author ? `${p.author.name || ''} (${p.author.email}), на платформе с ${date(p.author.since)}` : '—'} · создана ${dateTime(p.createdAt)}</div>
      <div class="form-actions" style="margin-top:12px">${p.transitions.map((t) => html`<button class="btn sm ${t.value === 'published' ? 'primary' : t.value === 'rejected' || t.value === 'hidden' ? 'danger' : ''}" data-act="${p.id}" data-to="${t.value}">${t.label}</button>`)}${!p.linkedStationId && ['published', 'under_review'].includes(p.status) ? html`<button class="btn sm success" data-promote="${p.id}">${icon('check', 14)} Включить в план развития</button>` : ''}</div></div>`)}
    ${!data.items.length ? html`<div class="empty">Нет инициатив в этом статусе</div>` : ''}</div>`);
  $$('[data-act]').forEach((b) => (b.onclick = () => {
    const to = b.dataset.to;
    const m = modal({ title: `Статус: ${data.statuses[to]}`, body: html`<form class="form" id="mf">${field('note', 'Комментарий для автора', { type: 'textarea', required: ['rejected', 'hidden'].includes(to), hint: ['rejected', 'hidden'].includes(to) ? 'обязательно — причина решения' : 'необязательно' })}<button class="btn primary" type="submit">Применить</button></form>` });
    bindForm($('#mf', m.root), async (v) => { const r = await api.post(`/api/op/proposals/${b.dataset.act}/status`, { status: to, note: v.note }); m.close(); toast(r.message, 'ok'); proposals(pane, ctx); });
  }));
  $$('[data-promote]').forEach((b) => (b.onclick = () => {
    const p = data.items.find((x) => x.id === b.dataset.promote);
    const m = modal({ title: 'Включение в план развития', body: html`<form class="form" id="pf"><div class="form-grid">
      ${field('name', 'Название объекта', { required: true, value: `Проект: ${p.title.replace(/ \(демо\)$/, '')}`, full: true })}
      ${field('kind', 'Тип станции', { options: META.kinds, value: ['agnks', 'cryo', 'modular', 'pagz', 'multi'].includes(p.preferredKind) ? p.preferredKind : 'agnks' })}
      ${field('plannedYear', 'Планируемый год ввода', { type: 'number', min: new Date().getFullYear(), value: new Date().getFullYear() + 2, required: true })}
      ${field('category', 'Категория плана', { options: { under_review: 'Рассматривается оператором', announced: 'Официально объявленный проект', confirmed: 'Подтверждённый объект' } })}
      ${field('capacityValue', 'Проектная мощность', { type: 'number', min: 0 })}${field('capacityUnit', 'Единица', { options: ['м³/ч', 'м³/сут', 'т/сут', 'тыс. м³/год'] })}
      ${field('basis', 'Основание включения в план', { type: 'textarea', required: true, full: true, value: `Инициатива пользователей: ${p.votes} голосов.` })}
    </div><p class="tiny muted">Автор, проголосовавшие и пользователи с маршрутами рядом получат уведомление.</p><button class="btn success" type="submit">Включить в план</button></form>` });
    bindForm($('#pf', m.root), async (v) => { await api.post(`/api/op/proposals/${p.id}/promote`, v); m.close(); toast('Инициатива включена в план развития', 'ok'); proposals(pane, ctx); });
  }));
}

async function comments(pane, ctx) {
  const st = ctx.query.status || 'pending';
  const data = await api.get(`/api/op/comments?status=${st}`);
  pane.innerHTML = String(html`${head('Модерация комментариев', 'Комментарии со ссылками и от новых аккаунтов попадают на предварительную модерацию.')}
    <div class="chips" style="margin-bottom:16px">${[['pending', 'На модерации'], ['visible', 'Опубликованные'], ['hidden', 'Скрытые']].map(([k, l]) => html`<a class="chip ${st === k ? 'active' : ''}" href="/operator/comments?status=${k}">${l}</a>`)}</div>
    <div class="grid" style="gap:10px">${data.items.map((c) => html`<div class="msg"><div class="who">${c.authorEmail || 'удалённый пользователь'} · ${dateTime(c.createdAt)} · к инициативе <a href="/vote/${c.proposalId}">${c.proposalTitle}</a></div><div style="white-space:pre-wrap">${c.body}</div>
      <div class="form-actions" style="margin-top:8px">${c.status !== 'visible' ? html`<button class="btn sm primary" data-c="${c.id}" data-s="visible">Опубликовать</button>` : ''}${c.status !== 'hidden' ? html`<button class="btn sm danger" data-c="${c.id}" data-s="hidden">Скрыть</button>` : ''}</div></div>`)}
    ${!data.items.length ? html`<div class="empty">Нет комментариев</div>` : ''}</div>`);
  $$('[data-c]').forEach((b) => (b.onclick = async () => { await api.post(`/api/op/comments/${b.dataset.c}/status`, { status: b.dataset.s }).catch(showError); comments(pane, ctx); }));
}

// ---------- Станции ----------
async function stations(pane) {
  const data = await api.get('/api/op/stations');
  pane.innerHTML = String(html`${head('Станции и план развития', 'Добавление и редактирование объектов. Подписчики и пользователи с маршрутами рядом получают уведомления.', html`<button class="btn primary" id="add">${icon('plus')} Добавить станцию</button>${exportBtn('stations', 'CSV')}`)}
    <div class="table-wrap"><table class="table"><thead><tr><th>Объект</th><th>Тип</th><th>Статус</th><th>Год</th><th>Категория плана</th><th>Обновлено</th><th></th></tr></thead><tbody>
    ${data.items.map((s) => html`<tr><td><b>${s.name}</b> ${demoBadge(s.isDemo)}<div class="tiny muted">${s.region} · ${s.fuels.map((f) => LABELS.fuel[f]).join(', ')}</div></td><td>${s.kindLabel}</td><td>${statusBadge(s.status, s.statusLabel)}</td><td>${s.plannedYear || '—'}</td><td class="small">${LABELS.planCategory[s.planCategory] || '—'}${s.planPublished === false ? ' (не опубликован)' : ''}</td><td class="small">${date(s.dataUpdatedAt)}</td><td class="nowrap"><button class="btn sm" data-edit="${s.id}">${icon('edit', 14)}</button> <button class="btn sm danger" data-del="${s.id}">${icon('trash', 14)}</button></td></tr>`)}
    </tbody></table></div>${regionDatalist()}`);
  const open = async (s) => {
    const m = modal({ title: s ? 'Редактирование станции' : 'Новая станция', wide: true, body: html`<form class="form" id="sf"><div class="grid g2" style="gap:18px"><div class="form-grid">
      ${field('name', 'Название', { required: true, full: true, value: s?.name })}
      ${field('kind', 'Тип станции', { options: META.kinds, value: s?.kind || 'agnks' })}${field('status', 'Статус', { options: META.statuses, value: s?.status || 'planned' })}
      <div class="field full"><span class="label">Виды топлива</span><div class="chips"><label class="check"><input type="checkbox" name="fuels" value="cng" data-group="1" ${!s || s.fuels.includes('cng') ? 'checked' : ''}> КПГ</label><label class="check"><input type="checkbox" name="fuels" value="lng" data-group="1" ${s?.fuels.includes('lng') ? 'checked' : ''}> СПГ</label></div></div>
      ${field('region', 'Регион', { required: true, list: 'regions', value: s?.region })}${field('operatorName', 'Оператор', { value: s?.operator })}
      ${field('address', 'Адрес', { full: true, value: s?.address })}
      ${field('lat', 'Широта', { type: 'number', step: 'any', required: true, value: s?.lat })}${field('lng', 'Долгота', { type: 'number', step: 'any', required: true, value: s?.lng })}
      ${field('dispensers', 'Заправочных постов', { type: 'number', min: 0, value: s?.dispensers })}${field('serviceRadiusKm', 'Радиус работы ПАГЗ, км', { type: 'number', min: 0, value: s?.serviceRadiusKm })}
      ${field('capacityValue', 'Проектная производительность', { type: 'number', min: 0, step: 'any', value: s?.capacityValue })}${field('capacityUnit', 'Единица', { options: ['м³/ч', 'м³/сут', 'т/сут', 'тыс. м³/год'], value: s?.capacityUnit || 'м³/ч' })}
      ${field('hours', 'Часы работы', { value: s?.hours })}<div class="field">${checkbox('hoursConfirmed', 'Часы работы подтверждены', s?.hoursConfirmed)}</div>
      ${field('photoKey', 'Фотография', { options: ['cng-station', 'cng-station-2', 'cng-dispenser', 'lng-station', 'compressor', 'compressor-2', 'highway', 'trucks-road', 'bus'], value: s?.photoKey || 'cng-station' })}
      ${field('description', 'Описание', { type: 'textarea', full: true, value: s?.description })}
      ${field('sourceName', 'Источник данных', { value: s?.sourceName })}${field('sourceUrl', 'Ссылка на источник', { type: 'url', value: s?.sourceUrl })}
      <fieldset class="full"><legend>План развития</legend><div class="form-grid">
        ${field('plannedYear', 'Планируемый год ввода', { type: 'number', min: 2000, max: 2060, value: s?.plannedYear })}${field('planCategory', 'Категория', { options: [['', '—'], ...Object.entries(META.planCategories)], value: s?.planCategory || '' })}
        ${field('planBasis', 'Основание включения в план', { full: true, value: s?.planBasis })}${field('planSourceName', 'Источник плана', { value: s?.planSourceName })}${field('planSourceUrl', 'Ссылка', { type: 'url', value: s?.planSourceUrl })}
        <div class="field full">${checkbox('planPublished', 'Опубликовать в плане развития', s ? s.planPublished !== false : true)}</div></div></fieldset>
      <div class="field full">${checkbox('isDemo', 'Демонстрационная (тестовая) запись', s ? s.isDemo : true)}</div>
    </div><div><div id="spick" class="leaflet-host" style="height:520px;border-radius:12px;overflow:hidden"></div><p class="tiny muted">Кликните по карте, чтобы задать координаты.</p></div></div>
    <div class="form-actions"><button class="btn primary" type="submit">Сохранить</button></div></form>` });
    const form = $('#sf', m.root);
    const pm = await pickerMap($('#spick', m.root), { lat: s?.lat, lng: s?.lng, onPick: (a, b) => { form.lat.value = a; form.lng.value = b; } });
    bindForm(form, async (v) => {
      const r = s ? await api.put(`/api/op/stations/${s.id}`, v) : await api.post('/api/op/stations', v);
      m.close(); pm.map.remove();
      toast(s ? 'Станция обновлена' : `Станция добавлена${r.notified ? `, уведомлено пользователей: ${r.notified}` : ''}`, 'ok');
      stations(pane);
    });
  };
  $('#add').onclick = () => open(null).catch(showError);
  $$('[data-edit]').forEach((b) => (b.onclick = () => open(data.items.find((x) => x.id === b.dataset.edit)).catch(showError)));
  $$('[data-del]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Удалить станцию из базы? Действие будет записано в журнал.', { danger: true, ok: 'Удалить' })) { await api.del(`/api/op/stations/${b.dataset.del}`).catch(showError); stations(pane); } }));
}

// ---------- Инвестиционный калькулятор ----------
async function invest(pane) {
  const saved = await api.get('/api/op/scenarios').catch(() => ({ items: [] }));
  const D = INVESTMENT_DEFAULTS;
  pane.innerHTML = String(html`${head('Оценка строительства новой АГНКС', 'Упрощённая модель: выручка, валовая маржа, операционный денежный поток, срок окупаемости, NPV и IRR по трём сценариям.')}
    <div class="notice warn" style="margin-bottom:18px">${icon('warn')}<p>Значения по умолчанию — условный пример для демонстрации, а не рыночные данные. Введите параметры конкретного проекта.</p></div>
    <form class="card pad form" id="inv">
      <fieldset><legend>Объект</legend><div class="form-grid g3">
        ${field('region', 'Регион', { list: 'regions', value: 'Хабаровский край' })}${field('location', 'Предлагаемое местоположение', { value: 'Трасса А-376, район Комсомольска-на-Амуре' })}${field('stationType', 'Тип станции', { options: META.kinds, value: 'agnks' })}
        ${field('capacityM3h', 'Производительность, м³/ч', { type: 'number', min: 0, value: D.capacityM3h })}${field('maxUtilization', 'Предельная загрузка, % от 24×365', { type: 'number', min: 1, max: 100, value: D.maxUtilization })}${field('horizonYears', 'Горизонт проекта, лет', { type: 'number', min: 1, max: 40, value: D.horizonYears })}
      </div></fieldset>
      <fieldset><legend>Экономика</legend><div class="form-grid g3">
        ${field('capex', 'CAPEX, ₽', { type: 'number', min: 0, value: D.capex })}${field('opexAnnual', 'Годовые постоянные OPEX, ₽', { type: 'number', min: 0, value: D.opexAnnual })}${field('variableCost', 'Переменные затраты, ₽/м³', { type: 'number', min: 0, step: 'any', value: D.variableCost, hint: 'электроэнергия компрессоров и т. п.' })}
        ${field('annualVolume', 'Прогноз отпуска при полной загрузке, м³/год', { type: 'number', min: 0, value: D.annualVolume })}${field('purchasePrice', 'Закупочная цена газа, ₽/м³', { type: 'number', min: 0, step: 'any', value: D.purchasePrice })}${field('salePrice', 'Цена реализации, ₽/м³', { type: 'number', min: 0, step: 'any', value: D.salePrice })}
        ${field('discountRate', 'Ставка дисконтирования, %', { type: 'number', min: 0, max: 100, step: 'any', value: D.discountRate })}${field('taxRate', 'Налог на прибыль, %', { type: 'number', min: 0, max: 50, value: D.taxRate })}${field('usefulLifeYears', 'Срок амортизации, лет', { type: 'number', min: 1, max: 50, value: D.usefulLifeYears })}
        ${field('ramp', 'Этапы роста загрузки по годам, %', { value: D.ramp.join(', '), full: true, hint: 'через запятую; после последнего значения загрузка сохраняется' })}
      </div></fieldset>
      <fieldset><legend>Сценарии (коэффициенты к базовым значениям)</legend><div class="table-wrap"><table class="table" style="min-width:560px"><thead><tr><th>Сценарий</th><th>Объём ×</th><th>Цена реализации ×</th><th>CAPEX ×</th><th>OPEX ×</th><th>Задержка выхода, лет</th></tr></thead><tbody>
        ${Object.entries(SCENARIO_DEFAULTS).map(([k, s]) => html`<tr><td><b>${s.label}</b></td>${['volume', 'price', 'capex', 'opex', 'rampShift'].map((p) => html`<td><input class="input" type="number" step="0.01" name="${k}_${p}" value="${s[p]}" style="width:90px"></td>`)}</tr>`)}
      </tbody></table></div></fieldset>
      <div class="form-actions"><button class="btn primary" type="submit">${icon('calc')} Рассчитать</button>
        ${field('title', '', { placeholder: 'Название расчёта для сохранения', attrs: 'style="min-width:260px"' })}<button class="btn" type="button" id="saveSc">Сохранить расчёт</button>
        ${saved.items.length ? html`<select class="select" id="loadSc" style="width:auto"><option value="">Загрузить сохранённый…</option>${saved.items.map((s) => html`<option value="${s.id}">${s.title} (${date(s.createdAt)})</option>`)}</select>` : ''}</div>
    </form>
    <div id="invRes" style="margin-top:22px"></div>
    <div class="card pad" style="margin-top:22px"><h3>Ограничения расчётной модели</h3><ul class="small muted">${MODEL_LIMITATIONS.map((x) => html`<li>${x}</li>`)}</ul></div>
    ${regionDatalist()}`);
  const form = $('#inv');
  const read = () => {
    const v = formValues(form);
    const inputs = { ...v, ramp: String(v.ramp || '100').split(/[,;\s]+/).map(Number).filter((x) => Number.isFinite(x)) };
    const scen = Object.fromEntries(Object.entries(SCENARIO_DEFAULTS).map(([k, s]) => [k, { label: s.label, volume: v[`${k}_volume`] ?? s.volume, price: v[`${k}_price`] ?? s.price, capex: v[`${k}_capex`] ?? s.capex, opex: v[`${k}_opex`] ?? s.opex, rampShift: v[`${k}_rampShift`] ?? s.rampShift }]));
    return { inputs, scen, raw: v };
  };
  const calc = () => {
    const { inputs, scen } = read();
    const res = Object.fromEntries(Object.entries(scen).map(([k, s]) => [k, investmentModel(inputs, s)]));
    const b = res.base;
    const colors = { conservative: '#f08a3c', base: '#47c8f5', optimistic: '#22a779' };
    const cum = (r) => { let a = 0; return r.flows.map((x) => (a += x)); };
    $('#invRes').innerHTML = String(html`
      <div class="grid g3">${Object.entries(res).map(([k, r]) => html`<div class="card pad" style="border-top:3px solid ${colors[k]}"><div class="lvl tiny muted" style="text-transform:uppercase;letter-spacing:.12em">${r.scenario}</div>
        <div class="dl" style="margin-top:8px"><div>NPV</div><div><b style="color:${r.npv >= 0 ? '#5fe0b0' : '#ff9aa6'}">${mln(r.npv)}</b></div><div>IRR</div><div><b>${r.irr !== null ? fmt(r.irr, 1) + ' %' : '—'}</b>${r.irrNote ? html`<div class="tiny muted">${r.irrNote}</div>` : ''}</div>
        <div>Простой срок окупаемости</div><div>${r.simplePayback !== null ? fmt(r.simplePayback, 1) + ' лет' : 'не окупается в горизонте'}</div><div>Дисконтированный срок</div><div>${r.discountedPayback !== null ? fmt(r.discountedPayback, 1) + ' лет' : 'не окупается в горизонте'}</div>
        <div>CAPEX</div><div>${mln(r.capex)}</div><div>Выручка за горизонт</div><div>${mln(r.totalRevenue)}</div><div>Валовая маржа за горизонт</div><div>${mln(r.totalGrossMargin)}</div><div>Средний OCF в год</div><div>${mln(r.avgAnnualCashFlow)}</div></div>
        ${r.capacityCapped ? html`<div class="notice warn" style="margin-top:10px;padding:8px 10px">${icon('warn', 16)}<p class="tiny">Объём ограничен производительностью: ${fmt(r.capacityLimit)} м³/год.</p></div>` : ''}</div>`)}</div>
      <div class="card pad" style="margin-top:18px"><h3>Накопленный денежный поток</h3>${lines(['0', ...b.years.map((y) => String(y.year))], Object.entries(res).map(([k, r]) => ({ name: r.scenario, values: cum(r), color: colors[k] })), { money: true })}</div>
      <div class="card pad" style="margin-top:18px"><h3>Базовый сценарий по годам</h3><div class="table-wrap"><table class="table"><thead><tr><th>Год</th><th class="num">Загрузка</th><th class="num">Отпуск, м³</th><th class="num">Выручка</th><th class="num">Валовая маржа</th><th class="num">OPEX</th><th class="num">EBITDA</th><th class="num">Налог</th><th class="num">Опер. денежный поток</th></tr></thead><tbody>
        <tr><td>0</td><td colspan="7" class="muted">Инвестиции (CAPEX)</td><td class="num">${money(-b.capex)}</td></tr>
        ${b.years.map((y) => html`<tr><td>${y.year}</td><td class="num">${y.load} %</td><td class="num">${fmt(y.volume)}</td><td class="num">${money(y.revenue)}</td><td class="num">${money(y.grossMargin)}</td><td class="num">${money(y.opex)}</td><td class="num">${money(y.ebitda)}</td><td class="num">${money(y.tax)}</td><td class="num"><b>${money(y.cashFlow)}</b></td></tr>`)}
      </tbody></table></div></div>`);
  };
  bindForm(form, async () => calc());
  calc();
  $('#saveSc').onclick = async () => {
    const { raw: v } = read();
    try { await api.post('/api/op/scenarios', { title: v.title || `Расчёт ${v.location || ''}`.trim(), inputs: v }); toast('Расчёт сохранён', 'ok'); invest(pane); } catch (e) { showError(e); }
  };
  $('#loadSc')?.addEventListener('change', (e) => {
    const s = saved.items.find((x) => x.id === e.target.value);
    if (s) { setFormValues(form, s.inputs); calc(); toast('Параметры загружены'); }
  });
}

// ---------- Новости ----------
async function news(pane) {
  const data = await api.get('/api/op/news');
  pane.innerHTML = String(html`${head('Новости', 'Публикации о газомоторной инфраструктуре для раздела «Новости».', html`<button class="btn primary" id="add">${icon('plus')} Новая публикация</button>`)}
    <div class="table-wrap"><table class="table"><thead><tr><th>Заголовок</th><th>Статус</th><th>Опубликовано</th><th></th></tr></thead><tbody>${data.items.map((n) => html`<tr><td><b>${n.title}</b> ${demoBadge(n.isDemo)}<div class="tiny muted">${n.summary || ''}</div></td><td>${statusBadge(n.status === 'published' ? 'published' : 'draft', n.status === 'published' ? 'Опубликовано' : 'Черновик')}</td><td>${date(n.publishedAt)}</td><td class="nowrap"><button class="btn sm" data-edit="${n.id}">${icon('edit', 14)}</button> <button class="btn sm danger" data-del="${n.id}">${icon('trash', 14)}</button></td></tr>`)}</tbody></table></div>`);
  const open = (n) => {
    const m = modal({ title: n ? 'Редактирование публикации' : 'Новая публикация', wide: true, body: html`<form class="form" id="nf">${field('title', 'Заголовок', { required: true, value: n?.title })}${field('summary', 'Анонс', { value: n?.summary })}${field('body', 'Текст (абзацы разделяйте пустой строкой)', { type: 'textarea', required: true, value: n?.body, rows: 12 })}<div class="form-grid">${field('photoKey', 'Изображение', { options: ['cng-station', 'cng-station-2', 'cng-dispenser', 'lng-station', 'lng-truck', 'trucks-road', 'bus', 'compressor', 'highway'], value: n?.photoKey || 'cng-station' })}${field('status', 'Статус', { options: { draft: 'Черновик', published: 'Опубликовать' }, value: n?.status || 'draft' })}</div><button class="btn primary" type="submit">Сохранить</button></form>` });
    bindForm($('#nf', m.root), async (v) => { if (n) await api.put(`/api/op/news/${n.id}`, v); else await api.post('/api/op/news', v); m.close(); toast('Сохранено', 'ok'); news(pane); });
  };
  $('#add').onclick = () => open(null);
  $$('[data-edit]').forEach((b) => (b.onclick = () => open(data.items.find((x) => x.id === b.dataset.edit))));
  $$('[data-del]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Удалить публикацию?', { danger: true, ok: 'Удалить' })) { await api.del(`/api/op/news/${b.dataset.del}`); news(pane); } }));
}

async function feedback(pane) {
  const data = await api.get('/api/op/feedback');
  pane.innerHTML = String(html`${head('Обратная связь', 'Вопросы, предложения и сообщения об ошибках в данных.')}
    <div class="grid" style="gap:10px">${data.items.map((f) => html`<div class="msg"><div class="who">${LABELS.feedbackTopic[f.topic]} · ${f.name || ''} ${f.email ? `<${f.email}>` : ''} · ${dateTime(f.createdAt)} ${f.related ? '· ' + f.related : ''}</div><div style="white-space:pre-wrap">${f.message}</div>
      <div class="form-actions" style="margin-top:8px"><select class="select" data-fb="${f.id}" style="width:auto">${[['new', 'Новое'], ['in_progress', 'В работе'], ['closed', 'Закрыто']].map(([k, l]) => html`<option value="${k}" ${f.status === k ? 'selected' : ''}>${l}</option>`)}</select>${f.email ? html`<a class="btn sm" href="mailto:${f.email}">${icon('mail', 14)} Ответить</a>` : ''}</div></div>`)}
    ${!data.items.length ? html`<div class="empty">Обращений нет</div>` : ''}</div>`);
  $$('[data-fb]').forEach((s) => (s.onchange = async () => { await api.post(`/api/op/feedback/${s.dataset.fb}/status`, { status: s.value }).catch(showError); toast('Статус обновлён', 'ok'); }));
}

async function audit(pane) {
  const data = await api.get('/api/op/audit?limit=300');
  pane.innerHTML = String(html`${head('Журнал административных действий', 'Действия сотрудников и события безопасности. Записи нельзя изменить через интерфейс.')}
    <div class="table-wrap"><table class="table"><thead><tr><th>Время</th><th>Сотрудник / пользователь</th><th>Действие</th><th>Объект</th><th>Детали</th><th>IP</th></tr></thead><tbody>
    ${data.items.map((a) => html`<tr><td class="nowrap small">${dateTime(a.createdAt)}</td><td class="small">${a.actor || '—'}</td><td><code class="small">${a.action}</code></td><td class="small">${a.entityType || ''} ${a.entityId ? a.entityId.slice(0, 8) : ''}</td><td class="tiny muted" style="max-width:280px;overflow-wrap:anywhere">${a.details ? JSON.stringify(a.details) : ''}</td><td class="tiny">${a.ip || ''}</td></tr>`)}
    </tbody></table></div>`);
}

async function users(pane, ctx) {
  const q = ctx.query.q || '';
  const data = await api.get(`/api/admin/users${q ? '?q=' + encodeURIComponent(q) : ''}`);
  pane.innerHTML = String(html`${head('Пользователи и роли', `Всего: ${fmt(data.total)}. Назначение ролей оператора и администратора, блокировка аккаунтов.`)}
    <form class="toolbar" id="uf" style="margin-bottom:14px"><input class="input" name="q" value="${q}" placeholder="Поиск по e-mail или имени"><button class="btn" type="submit">Найти</button></form>
    <div class="table-wrap"><table class="table"><thead><tr><th>Пользователь</th><th>Тип</th><th>Роль</th><th>Статус</th><th>Зарегистрирован</th><th>Вход</th></tr></thead><tbody>
    ${data.items.map((u) => html`<tr><td><b>${u.name || '—'}</b> ${demoBadge(u.isDemo)}<div class="tiny muted">${u.email}${u.verified ? '' : ' · e-mail не подтверждён'}</div></td><td class="small">${LABELS.account[u.accountType]}</td>
      <td>${u.id === state.user.id ? LABELS.role[u.role] : html`<select class="select" data-role="${u.id}" style="width:auto">${Object.entries(LABELS.role).map(([k, l]) => html`<option value="${k}" ${u.role === k ? 'selected' : ''}>${l}</option>`)}</select>`}</td>
      <td>${u.id === state.user.id ? 'активен' : html`<select class="select" data-status="${u.id}" style="width:auto"><option value="active" ${u.status === 'active' ? 'selected' : ''}>Активен</option><option value="blocked" ${u.status === 'blocked' ? 'selected' : ''}>Заблокирован</option></select>`}</td>
      <td class="small">${date(u.createdAt)}</td><td class="small">${dateTime(u.lastLoginAt)}</td></tr>`)}
    </tbody></table></div>`);
  $('#uf').onsubmit = (e) => { e.preventDefault(); go(`/operator/users?q=${encodeURIComponent(e.target.q.value)}`); };
  $$('[data-role]').forEach((s) => (s.onchange = async () => { try { await api.post(`/api/admin/users/${s.dataset.role}`, { role: s.value }); toast('Роль изменена', 'ok'); } catch (e) { showError(e); } }));
  $$('[data-status]').forEach((s) => (s.onchange = async () => { try { await api.post(`/api/admin/users/${s.dataset.status}`, { status: s.value }); toast('Статус изменён', 'ok'); } catch (e) { showError(e); } }));
}

async function outbox(pane) {
  const data = await api.get('/api/admin/outbox');
  pane.innerHTML = String(html`${head('Журнал исходящих писем', 'В режиме разработки (MAIL_DRIVER=console) письма не отправляются, а сохраняются здесь. При SMTP содержимое писем не хранится.')}
    <div class="grid" style="gap:10px">${data.items.map((m) => html`<details class="msg"><summary style="cursor:pointer"><b>${m.subject}</b> · ${m.to} · ${dateTime(m.createdAt)} · ${m.status}</summary><pre style="white-space:pre-wrap;font-size:12.5px;margin:10px 0 0">${m.body}</pre></details>`)}</div>`);
}
