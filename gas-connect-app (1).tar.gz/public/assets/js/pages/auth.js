// Вход, регистрация, восстановление доступа, подтверждение e-mail.
import { html, raw, api, $, $$, icon, setTitle, state, toast, field, checkbox, bindForm, go, setUser, refreshSession, regionDatalist, photoBg } from '../core.js';

function shell(title, sub, body, side = 'cng-station') {
  return html`<section class="section" style="padding-top:40px"><div class="wrap"><div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,.9fr);gap:0;border:1px solid var(--line);border-radius:18px;overflow:hidden;background:var(--card-2)" id="authGrid">
    <div class="pad" style="padding:clamp(22px,4vw,48px)"><h1 style="font-size:clamp(28px,3vw,38px)">${title}</h1><p class="muted">${sub}</p>${body}</div>
    <div class="auth-side" style="${raw(photoBg(side, 1200, 'linear-gradient(180deg,rgba(11,18,48,.35),rgba(11,18,48,.92))'))};background-size:cover;background-position:center;min-height:420px;display:flex;flex-direction:column;justify-content:flex-end;padding:36px">
      <span class="eyebrow">GAS CONNECT</span><h2 style="margin:12px 0 8px">Строим газомоторную инфраструктуру вместе</h2>
      <p class="muted" style="margin:0">Ваши маршруты и голоса помогают оператору понять, где нужны новые станции.</p></div>
  </div></div></section>`;
}
function responsive() { if (matchMedia('(max-width: 860px)').matches) { const g = $('#authGrid'); if (g) g.style.gridTemplateColumns = '1fr'; $$('.auth-side').forEach((x) => (x.style.minHeight = '220px')); } }
const safeNext = (n) => (n && n.startsWith('/') && !n.startsWith('//') ? n : null);

export async function login(ctx) {
  setTitle('Вход');
  if (state.user) { go(safeNext(ctx.query.next) || '/account', { replace: true }); return; }
  ctx.app.innerHTML = String(shell('Вход в личный кабинет', 'Используйте e-mail и пароль, указанные при регистрации.', html`
    <form id="lf" class="form" style="margin-top:18px">
      ${field('email', 'E-mail', { type: 'email', required: true, attrs: 'autocomplete="username"' })}
      ${field('password', 'Пароль', { type: 'password', required: true, attrs: 'autocomplete="current-password"' })}
      <div class="form-actions"><button class="btn primary lg" type="submit">Войти</button><a href="/forgot">Забыли пароль?</a></div>
      <p class="small muted">Нет аккаунта? <a href="/register">Зарегистрируйтесь</a></p>
      ${state.meta && !state.meta.production ? html`<details class="small" style="margin-top:6px"><summary class="muted" style="cursor:pointer">Тестовые аккаунты для демонстрации</summary>
        <p class="tiny muted" style="margin:10px 0">Пароль для всех: <code>GasDemo2026!</code> (если не задан SEED_PASSWORD). В опубликованной версии вход демо-аккаунтов отключён.</p>
        <div class="chips">${[['driver@demo.gas-connect.ru', 'Физлицо'], ['ip@demo.gas-connect.ru', 'ИП'], ['company@demo.gas-connect.ru', 'Юрлицо'], ['operator@demo.gas-connect.ru', 'Оператор'], ['admin@demo.gas-connect.ru', 'Админ']].map(([e, l]) => html`<button type="button" class="chip" data-demo="${e}">${l}</button>`)}</div></details>` : ''}
    </form>`));
  responsive();
  $$('[data-demo]').forEach((b) => (b.onclick = () => { $('#lf [name=email]').value = b.dataset.demo; $('#lf [name=password]').value = 'GasDemo2026!'; $('#lf').requestSubmit(); }));
  bindForm($('#lf'), async (v) => {
    const r = await api.post('/api/auth/login', v);
    state.csrf = r.csrf;
    setUser(r.user);
    toast(`Добро пожаловать, ${r.user.name}!`, 'ok');
    go(safeNext(ctx.query.next) || (['operator', 'admin'].includes(r.user.role) ? '/operator' : '/account'));
  });
}

export async function register(ctx) {
  setTitle('Регистрация');
  if (state.user) { go('/account', { replace: true }); return; }
  const invite = ctx.query.invite === '1';
  ctx.app.innerHTML = String(html`
  <section class="page-hero"><div class="wrap"><span class="eyebrow">Регистрация</span><h1>Присоединиться к GAS CONNECT</h1><p class="lead">Выберите тип участника — форма подстроится под ваши данные. Для ИП и организаций доступны автопарк и коммерческие предложения.</p></div></section>
  <section class="section tight"><div class="wrap" style="max-width:980px">
    <form id="rf" class="card pad form" novalidate>
      <div class="role-pick" role="radiogroup" aria-label="Тип участника">
        ${[['person', 'user', 'Физическое лицо', 'Частный владелец автомобиля на газе'], ['ip', 'car', 'Индивидуальный предприниматель', 'ИП, использующий транспорт в работе'], ['company', 'building', 'Юридическое лицо', 'Транспортная, логистическая или иная организация']].map(([v, ic, t, d], i) => html`<label><input type="radio" name="accountType" value="${v}" ${i === 0 && !invite ? raw('checked') : v === 'company' && invite ? raw('checked') : ''}><span class="rp"><span class="ic">${icon(ic, 22)}</span><strong>${t}</strong><small>${d}</small></span></label>`)}
      </div>
      <div id="inviteBox" class="hidden">${checkbox('joinByInvite', 'Я сотрудник организации и получил(а) приглашение на этот e-mail', invite)}</div>
      <fieldset><legend>Учётная запись</legend><div class="form-grid">
        ${field('email', 'Электронная почта', { type: 'email', required: true, attrs: 'autocomplete="email"' })}
        ${field('password', 'Пароль', { type: 'password', required: true, hint: 'Не менее 10 символов, буквы и цифры', attrs: 'autocomplete="new-password" minlength="10"' })}
      </div></fieldset>
      <fieldset><legend id="personLegend">О вас</legend><div class="form-grid">
        ${field('fullName', 'Имя', { required: true, attrs: 'autocomplete="name"' })}
        ${field('phone', 'Контактный телефон', { type: 'tel', hint: 'необязательно', attrs: 'autocomplete="tel"' })}
        ${field('region', 'Регион', { required: true, list: 'regions' })}
        ${field('city', 'Город', {})}
        ${field('preferredFuel', 'Предпочитаемое топливо', { options: { undecided: 'Пока не выбрано', cng: 'КПГ', lng: 'СПГ', both: 'КПГ и СПГ' } })}
        <div class="biz-only">${field('contactPosition', 'Должность представителя', {})}</div>
      </div></fieldset>
      <fieldset class="biz-only org-fields"><legend id="orgLegend">Организация</legend><div class="form-grid">
        <div class="company-only full">${field('orgFullName', 'Полное наименование организации', { placeholder: 'Общество с ограниченной ответственностью «…»' })}</div>
        <div class="company-only">${field('legalForm', 'Организационно-правовая форма', { options: ['ООО', 'АО', 'ПАО', 'НАО', 'МУП', 'ГУП', 'ФГУП', 'ГБУ', 'МБУ', 'Кооператив', 'Другое'] })}</div>
        ${field('inn', 'ИНН', { required: true, hint: 'ИП — 12 цифр, юрлицо — 10 цифр; проверяется контрольная сумма', attrs: 'inputmode="numeric" maxlength="12"' })}
        <div class="company-only full">${field('legalAddress', 'Юридический адрес', { hint: 'при необходимости' })}</div>
        ${field('activity', 'Вид / сфера деятельности', { required: true, placeholder: 'Грузоперевозки, такси, доставка…' })}
        ${field('employees', 'Количество сотрудников', { type: 'number', min: 0 })}
        ${field('fleetSize', 'Размер автопарка (ТС)', { type: 'number', min: 0 })}
      </div></fieldset>
      <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      ${checkbox('consent', raw('Я даю согласие на обработку персональных данных в соответствии с <a href="/privacy" target="_blank">Политикой конфиденциальности</a>'), false, 'required')}
      <div class="notice warn">${icon('info')}<p>Демонстрационная версия: не указывайте реальные персональные данные, ИНН и сведения, составляющие коммерческую тайну.</p></div>
      <div class="form-actions"><button class="btn primary lg" type="submit">Зарегистрироваться</button><span class="small muted">Уже есть аккаунт? <a href="/login">Войти</a></span></div>
    </form>${regionDatalist()}
  </div></section>`);
  const form = $('#rf');
  const started = Date.now();
  const sync = () => {
    const t = form.querySelector('[name=accountType]:checked').value;
    const invited = t === 'company' && form.joinByInvite.checked;
    $('#inviteBox').classList.toggle('hidden', t !== 'company');
    $$('.biz-only', form).forEach((el) => el.classList.toggle('hidden', t === 'person'));
    $$('.company-only', form).forEach((el) => el.classList.toggle('hidden', t !== 'company'));
    $('.org-fields', form).classList.toggle('hidden', t === 'person' || invited);
    $$('.org-fields input, .org-fields select', form).forEach((el) => (el.disabled = t === 'person' || invited || (t === 'ip' && el.closest('.company-only'))));
    form.querySelector('label[for^="f-fullName"]').innerHTML = t === 'person' ? 'Имя <span class="req">*</span>' : t === 'ip' ? 'ФИО предпринимателя <span class="req">*</span>' : 'Контактное лицо (ФИО) <span class="req">*</span>';
    $('#personLegend').textContent = t === 'person' ? 'О вас' : 'Представитель';
    $('#orgLegend').textContent = t === 'ip' ? 'Индивидуальный предприниматель' : 'Организация';
  };
  $$('[name=accountType], [name=joinByInvite]', form).forEach((el) => el.addEventListener('change', sync));
  sync();
  bindForm(form, async (v) => {
    const r = await api.post('/api/auth/register', { ...v, formStartedAt: started });
    ctx.app.innerHTML = String(html`<section class="section"><div class="wrap" style="max-width:720px"><div class="card pad" style="text-align:center;padding:48px">
      <div style="width:64px;height:64px;border-radius:50%;background:rgba(34,167,121,.2);display:grid;place-items:center;margin:0 auto 18px;color:#5fe0b0">${icon('mail', 30)}</div>
      <h2>Почти готово!</h2><p class="muted">${r.message}</p>
      ${r.devVerifyLink ? html`<div class="notice" style="text-align:left;margin:20px 0">${icon('info')}<p>Режим разработки: письма не отправляются, а сохраняются в журнале. Ссылка подтверждения: <a href="${r.devVerifyLink.replace(location.origin, '')}">подтвердить e-mail</a></p></div>` : ''}
      <a class="btn primary" href="/login">Перейти ко входу</a></div></div></section>`);
  });
}

export async function forgot(ctx) {
  setTitle('Восстановление доступа');
  ctx.app.innerHTML = String(shell('Восстановление доступа', 'Укажите e-mail — мы отправим ссылку для установки нового пароля.', html`
    <form id="ff" class="form" style="margin-top:18px">${field('email', 'E-mail', { type: 'email', required: true })}<button class="btn primary" type="submit">Отправить ссылку</button><a href="/login" class="small">← Вернуться ко входу</a></form><div id="fres"></div>`, 'cng-dispenser'));
  responsive();
  bindForm($('#ff'), async (v) => {
    const r = await api.post('/api/auth/forgot', v);
    $('#fres').innerHTML = String(html`<div class="notice ok" style="margin-top:16px">${icon('check')}<p>${r.message}${r.devResetLink ? html` Режим разработки: <a href="${r.devResetLink.replace(location.origin, '')}">открыть ссылку восстановления</a>.` : ''}</p></div>`);
  });
}

export async function reset(ctx) {
  setTitle('Новый пароль');
  ctx.app.innerHTML = String(shell('Новый пароль', 'Придумайте новый пароль: не менее 10 символов, буквы и цифры.', html`
    <form id="nf" class="form" style="margin-top:18px">${field('password', 'Новый пароль', { type: 'password', required: true, attrs: 'autocomplete="new-password"' })}<button class="btn primary" type="submit">Сохранить пароль</button></form>`, 'cng-dispenser'));
  responsive();
  bindForm($('#nf'), async (v) => {
    const r = await api.post('/api/auth/reset', { token: ctx.query.token, password: v.password });
    toast(r.message, 'ok', 6000);
    await refreshSession();
    go('/login');
  });
}

export async function verify(ctx) {
  setTitle('Подтверждение e-mail');
  ctx.app.innerHTML = '<section class="section"><div class="wrap" style="max-width:640px"><div class="card pad" id="vres" style="text-align:center;padding:48px">Проверяем ссылку…</div></div></section>';
  try {
    const r = await api.post('/api/auth/verify', { token: ctx.query.token });
    await refreshSession();
    $('#vres').innerHTML = String(html`<div style="color:#5fe0b0">${icon('check', 40)}</div><h2>Адрес подтверждён</h2><p class="muted">${r.message}</p><a class="btn primary" href="${state.user ? '/account' : '/login'}">${state.user ? 'В личный кабинет' : 'Войти'}</a>`);
  } catch (e) {
    $('#vres').innerHTML = String(html`<div style="color:#ff9aa6">${icon('warn', 40)}</div><h2>Не удалось подтвердить</h2><p class="muted">${e.message}</p><a class="btn" href="/account">Запросить новое письмо в кабинете</a>`);
  }
}
