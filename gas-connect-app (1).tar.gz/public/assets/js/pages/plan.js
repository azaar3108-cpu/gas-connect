// «План развития газозаправочной сети» — календарь объектов по годам.
import { html, raw, api, $, $$, fmt, photoBg, icon, statusBadge, demoBadge, setTitle, LABELS } from '../core.js';

const BUCKETS = [
  ['2026', 'Действующая инфраструктура и проекты в работе', (s) => s.status === 'operational' || (s.plannedYear || 0) <= 2026],
  ['2027', 'Планируемые объекты', (s) => s.status !== 'operational' && s.plannedYear === 2027],
  ['2028', 'Перспективные проекты', (s) => s.status !== 'operational' && s.plannedYear === 2028],
  ['2029+', 'Долгосрочные инициативы', (s) => s.status !== 'operational' && (s.plannedYear || 0) >= 2029],
];
const CAT_ORDER = ['confirmed', 'announced', 'under_review', 'user_initiative'];
const CAT_COLORS = { confirmed: '#22a779', announced: '#f08a3c', under_review: '#9b7bff', user_initiative: '#c7d1e8' };

export async function plan(ctx) {
  setTitle('План развития газозаправочной сети');
  ctx.app.innerHTML = String(html`
  <section class="page-hero photo" style="${raw(photoBg('compressor', 1800))}"><div class="wrap">
    <span class="eyebrow">Развитие инфраструктуры</span><h1>План развития газозаправочной сети</h1>
    <p class="lead">Объекты по годам с указанием типа, мощности, статуса, основания включения в план и источника данных. Подтверждённые объекты, объявленные проекты, проекты на рассмотрении и инициативы пользователей показаны раздельно.</p>
  </div></section>
  <section class="section tight"><div class="wrap">
    <div class="toolbar" style="margin-bottom:18px"><span class="small muted">Категории:</span><div class="chips" id="cats">
      ${CAT_ORDER.map((c) => html`<button class="chip active" data-cat="${c}"><i class="dot" style="background:${CAT_COLORS[c]};box-shadow:none"></i>${LABELS.planCategory[c]}</button>`)}</div></div>
    <div class="years" id="years">${raw('<div class="skeleton" style="min-height:400px"></div>'.repeat(4))}</div>
    <div id="inits" style="margin-top:26px"></div>
    <div class="notice warn" style="margin-top:20px">${icon('warn')}<p>Пользовательские инициативы не являются официальными планами компании. В демонстрационной версии все объекты и даты условные; категория «Официально объявленный проект» в демо-данных также является примером оформления, а не реальным объявлением.</p></div>
  </div></section>`);
  const data = await api.get('/api/plans');
  const active = new Set(CAT_ORDER);
  function item(s) {
    return html`<a class="plan-item" href="/map?station=${s.id}" style="display:block;color:#fff">
      <div class="chips" style="gap:6px">${statusBadge(s.status, s.statusLabel)}${demoBadge(s.isDemo)}</div>
      <h4>${s.name}</h4>
      <div class="meta">
        <span>${s.region} · ${LABELS.kind[s.kind]}</span>
        <span>Год ввода: ${s.status === 'operational' ? 'действует' : s.plannedYear || 'не определён'} · мощность: ${s.capacityValue ? `${fmt(s.capacityValue)} ${s.capacityUnit}` : '—'}</span>
        <span>${statusBadge(s.planCategory || 'confirmed', LABELS.planCategory[s.planCategory] || 'Подтверждённый объект')}</span>
        <span>Заинтересованы: ${fmt(s.interested)} · Основание: ${s.planBasis || '—'}</span>
        <span>Источник: ${s.planSourceName || s.sourceName || '—'}</span>
      </div></a>`;
  }
  function render() {
    $('#years').innerHTML = String(html`${BUCKETS.map(([label, sub, pred]) => {
      const stations = data.stations.filter((s) => pred(s) && active.has(s.planCategory || 'confirmed'));
      const inits = [];
      return html`<div class="year-col reveal revealed"><h2>${label}</h2><div class="sub">${sub}</div>
        ${stations.map(item)}
        ${inits.length ? html`<div class="eyebrow" style="margin:18px 0 10px;font-size:11px">Инициативы пользователей</div>${inits.map((p) => html`<a class="plan-item" href="/vote/${p.id}" style="display:block;color:#fff;border-style:dashed"><div class="chips" style="gap:6px">${statusBadge('user_initiative', 'Инициатива пользователей')}${demoBadge(p.isDemo)}</div><h4>${p.title}</h4><div class="meta"><span>${p.region}${p.highway ? ' · ' + p.highway : ''}</span><span>Голосов: ${fmt(p.votes)} · статус: ${p.status === 'under_review' ? 'рассматривается' : 'сбор голосов'}</span><span>Основание: голоса и заявки пользователей платформы</span></div></a>`)}` : ''}
        ${!stations.length && !inits.length ? html`<p class="muted small">Нет объектов в выбранных категориях.</p>` : ''}
      </div>`;
    })}`);
    const inits = active.has('user_initiative') ? data.initiatives : [];
    $('#inits').innerHTML = inits.length ? String(html`<div class="section-head"><div><span class="eyebrow">Отдельно от плана</span><h2 style="margin-top:10px">Инициативы пользователей</h2></div><p>Предложения участников платформы. Сроки не определены, решение о включении в план принимает оператор.</p></div>
      <div class="grid g4">${inits.map((p) => html`<a class="plan-item" href="/vote/${p.id}" style="display:block;color:#fff;border-style:dashed"><div class="chips" style="gap:6px">${statusBadge('user_initiative', 'Инициатива пользователей')}${demoBadge(p.isDemo)}</div><h4>${p.title}</h4><div class="meta"><span>${p.region}${p.highway ? ' · ' + p.highway : ''}</span><span>Голосов: ${fmt(p.votes)} · ${p.status === 'under_review' ? 'рассматривается оператором' : 'сбор голосов'}</span><span>Основание: голоса и заявки пользователей</span><span>Источник: GAS CONNECT</span></div></a>`)}</div>`) : '';
  }
  $$('#cats [data-cat]').forEach((b) => (b.onclick = () => { const c = b.dataset.cat; if (active.has(c)) active.delete(c); else active.add(c); b.classList.toggle('active'); render(); }));
  render();
}
