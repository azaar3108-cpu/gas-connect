// Информационные страницы: для бизнеса, аналитика, о проекте, авторство фото, политика, обратная связь, новости.
import { html, raw, api, $, $$, fmt, photo, photoBg, icon, setTitle, state, LABELS, date, toast, field, checkbox, bindForm, MEDIA, isBusiness, demoBadge } from '../core.js';
import { bars, donut } from '../components/charts.js';

const hero = (eyebrow, title, lead, ph, actions = '') => html`<section class="page-hero photo" style="${raw(photoBg(ph, 1800))}"><div class="wrap"><span class="eyebrow">${eyebrow}</span><h1>${title}</h1><p class="lead">${lead}</p>${actions ? html`<div class="actions">${actions}</div>` : ''}</div></section>`;

export async function business(ctx) {
  setTitle('Для бизнеса');
  const cta = state.user ? (isBusiness() ? '/account/offers/new' : '/account') : '/register';
  ctx.app.innerHTML = String(html`
  ${hero('Для бизнеса', 'Долгосрочное сотрудничество по поставке газомоторного топлива', 'ИП и юридические лица могут зарегистрировать автопарк, указать маршруты и направить оператору коммерческое предложение о закупке КПГ или СПГ.', 'lng-truck', html`<a class="btn primary lg" href="${cta}">${icon('doc')} Предложить договор сотрудничества</a><a class="btn lg" href="/savings">${icon('calc')} Калькулятор экономии</a>`)}
  <section class="section"><div class="wrap">
    <div class="section-head reveal"><div><span class="eyebrow">Как это работает</span><h2 style="margin-top:12px">От автопарка до договорённости</h2></div></div>
    <div class="steps reveal">${[
      ['building', 'Зарегистрируйте компанию', 'Тип «ИП» или «Юридическое лицо», ИНН с проверкой контрольной суммы. Оператор подтверждает организацию.'],
      ['car', 'Опишите автопарк и маршруты', 'Карточки ТС с расходом и пробегом, регулярные направления, ограничения и проблемные участки.'],
      ['doc', 'Направьте предложение', 'Объёмы КПГ/СПГ, срок, минимальный гарантируемый объём, условия поставки и документы.'],
      ['check', 'Получите решение', 'Статусы: отправлено → на рассмотрении → требуется уточнение → предварительно согласовано.'],
    ].map(([ic, t, d]) => html`<div class="step"><div class="icon">${icon(ic, 28)}</div><h3>${t}</h3><p>${d}</p><span class="bar"></span></div>`)}</div>
  </div></section>
  <section class="section" style="padding-top:0"><div class="wrap"><div class="grid g3 reveal">
    <div class="card pad"><h3>${icon('people')} Объединение спроса</h3><p class="muted small">Если маршруты нескольких компаний проходят через одну точку, платформа суммирует автомобили и расчётную потребность без двойного учёта — это усиливает обоснование строительства станции.</p></div>
    <div class="card pad"><h3>${icon('fuel')} Расчёт потребности</h3><p class="muted small">Потребность в газе рассчитывается по пробегу и расходу каждого ТС: КПГ в м³, СПГ в кг. Пробег по маршрутам не дублирует пробег автомобилей.</p></div>
    <div class="card pad"><h3>${icon('shield')} Конфиденциальность</h3><p class="muted small">Коммерческие предложения видят только сотрудники вашей организации и уполномоченные сотрудники оператора. Доступ проверяется на сервере, действия оператора журналируются.</p></div>
  </div>
  <div class="notice warn" style="margin-top:22px">${icon('info')}<p>Коммерческое предложение на платформе — это заявка, а не юридически обязывающий договор. Юридически значимое подписание требует отдельной согласованной процедуры. GAS CONNECT — демонстрационная концепция и не принимает обязательств от имени ПАО «Газпром» или иных компаний.</p></div>
  </div></section>`);
}

export async function analytics(ctx) {
  setTitle('Аналитика');
  ctx.app.innerHTML = String(html`${hero('Аналитика', 'Открытая аналитика платформы', 'Обезличенные сводные показатели: станции, транспорт, инициативы по регионам и уровни спроса. Подробная аналитика доступна сотрудникам оператора.', 'compressor-2')}
  <section class="section tight"><div class="wrap" id="an"><div class="skeleton" style="min-height:400px"></div></div></section>`);
  const a = await api.get('/api/analytics/public');
  const byKind = {};
  a.stationsByKindStatus.forEach((x) => { byKind[x.kind] = (byKind[x.kind] || 0) + x.n; });
  const byStatus = {};
  a.stationsByKindStatus.forEach((x) => { byStatus[x.status] = (byStatus[x.status] || 0) + x.n; });
  const t = a.demand.totals;
  $('#an').innerHTML = String(html`
    ${state.meta?.demoData ? html`<div class="notice warn" style="margin-bottom:18px">${icon('warn')}<p>Показатели рассчитаны по демонстрационным данным и не отражают реальную ситуацию.</p></div>` : ''}
    <div class="grid g3">
      <div class="tier t1"><div class="lvl">Уровень 1 · интерес</div><div class="big">${fmt(t.interest.votes)}</div><div class="small muted">голосов за ${fmt(t.interest.proposals)} инициатив</div></div>
      <div class="tier t2"><div class="lvl">Уровень 2 · расчётный спрос</div><div class="big">${fmt(t.estimated.m3 / 1000, 1)} тыс. м³</div><div class="small muted">КПГ в месяц · СПГ: ${fmt(t.estimated.kg / 1000, 1)} т в месяц</div></div>
      <div class="tier t3"><div class="lvl">Уровень 3 · договорной спрос</div><div class="big">${fmt(t.contracted.m3 / 1000, 1)} тыс. м³</div><div class="small muted">КПГ в месяц · СПГ: ${fmt(t.contracted.kg / 1000, 1)} т в месяц</div></div>
    </div>
    <div class="grid g2" style="margin-top:22px">
      <div class="card pad"><h3>Станции по типам</h3>${donut(Object.entries(byKind).map(([k, n]) => ({ label: LABELS.kind[k], value: n })), { title: 'объектов' })}</div>
      <div class="card pad"><h3>Станции по статусу</h3>${bars(Object.entries(byStatus).map(([k, n]) => ({ label: LABELS.stationStatus[k], value: n })), { colors: ['#22a779', '#f08a3c', '#9b7bff', '#6b7799'] })}
        <h3 style="margin-top:22px">Зарегистрированный транспорт</h3>${bars(a.vehiclesByFuel.sort((x, y) => y.n - x.n).map((v) => ({ label: v.label, value: v.n })), { unit: 'ТС' })}</div>
      <div class="card pad"><h3>Инициативы по регионам (голоса)</h3>${bars(a.proposalsByRegion.map((r) => ({ label: r.region, value: r.votes })), { colors: ['#9b7bff'] })}</div>
      <div class="card pad"><h3>Расчётный спрос КПГ по регионам, м³/мес.</h3>${bars(a.demand.topRegions.filter((r) => r.estimatedM3).map((r) => ({ label: r.region, value: r.estimatedM3 })))}</div>
    </div>
    <details class="card pad" style="margin-top:22px"><summary style="cursor:pointer;font-weight:600">Методика расчёта уровней спроса</summary><ul class="small muted">${a.demand.methodology.map((m) => html`<li>${m}</li>`)}</ul></details>`);
}

export async function about(ctx) {
  setTitle('О проекте');
  ctx.app.innerHTML = String(html`${hero('О проекте', 'GAS CONNECT — единая цифровая платформа газомоторной инфраструктуры', 'Демонстрационная концепция экосистемы, объединяющей владельцев газомоторного транспорта, предпринимателей, транспортные компании и операторов инфраструктуры.', 'bus')}
  <section class="section"><div class="wrap"><div class="grid g2" style="gap:40px;align-items:start">
    <div class="article">
      <h2 style="margin-top:0">Идея</h2>
      <p>Развитие сети газозаправочных станций сдерживается неопределённостью спроса: оператору сложно оценить, сколько автомобилей будет заправляться на новой станции, а перевозчикам — переводить парк на метан без уверенности в инфраструктуре. GAS CONNECT собирает данные о реальных потребностях: какие автомобили, по каким маршрутам и как часто ездят, где не хватает заправок.</p>
      <h2>Для кого</h2>
      <ul><li><b>Частные владельцы</b> — карта станций, планировщик маршрута, голосование за новые точки.</li><li><b>ИП и компании</b> — автопарк, маршруты, коммерческие предложения о долгосрочной закупке топлива.</li><li><b>Оператор инфраструктуры</b> — аналитика спроса трёх уровней, перспективные участки, модерация, инвестиционная оценка.</li></ul>
      <h2>Принципы</h2>
      <ul><li>Голоса — сигнал интереса, а не гарантированный спрос.</li><li>Интерес, расчётный и договорной спрос показываются раздельно.</li><li>Пользовательские инициативы не выдаются за официальные планы.</li><li>Все демонстрационные данные помечены как тестовые.</li></ul>
    </div>
    <div class="grid" style="gap:18px">
      <div class="notice warn">${icon('warn')}<p>Проект разработан как демонстрационная концепция для возможного использования операторами газомоторной инфраструктуры (в т. ч. ПАО «Газпром»). Сайт не является официальным ресурсом ПАО «Газпром», не использует его логотип и не содержит обязательств компании.</p></div>
      <div class="card pad"><h3>Технологии</h3><div class="dl"><div>Сервер</div><div>Node.js 22, серверный API, проверка прав на сервере</div><div>База данных</div><div>PostgreSQL 16 или SQLite (для локальной демонстрации)</div><div>Безопасность</div><div>scrypt-хеши паролей, HttpOnly-сессии, CSRF-токены, CSP, ограничение частоты запросов, журнал действий</div><div>Карта</div><div>Leaflet + OpenStreetMap</div><div>Маршрутизация</div><div>OSRM (дорожный граф OpenStreetMap)</div></div></div>
      <div class="card pad"><h3>Полезные ссылки</h3><div class="grid" style="gap:8px"><a href="/learn">Обучающий раздел</a><a href="/privacy">Политика конфиденциальности</a><a href="/credits">Авторство фотографий</a><a href="/feedback">Обратная связь</a></div></div>
    </div>
  </div></div></section>`);
}

export async function credits(ctx) {
  setTitle('Авторство фотографий');
  const seen = new Set();
  const list = Object.entries(MEDIA).filter(([, m]) => (seen.has(m.file) ? false : seen.add(m.file)));
  ctx.app.innerHTML = String(html`<section class="page-hero"><div class="wrap"><span class="eyebrow">Источники</span><h1>Авторство фотографий</h1><p class="lead">Фотографии загружаются из Wikimedia Commons — хранилища свободно лицензируемых медиафайлов. Автор и лицензия каждого файла указаны на его странице в Commons; при публикации сайта сведения об авторстве нужно перенести в подписи согласно условиям лицензии.</p></div></section>
  <section class="section tight"><div class="wrap"><div class="grid g3">${list.map(([k, m]) => { const p = photo(k, 600); return html`<a class="card hover photo-card" href="${p.page}" target="_blank" rel="noopener"><div class="ph" style="${raw(photoBg(k, 600))}"></div><div class="body"><h3 style="font-size:16px">${m.title}</h3><p class="tiny muted" style="margin:0;overflow-wrap:anywhere">Файл: ${m.file}</p><span class="small">Автор и лицензия — на странице файла ↗</span></div></a>`; })}</div>
  <div class="notice" style="margin-top:20px">${icon('info')}<p>Если фотография недоступна (нет интернета или файл удалён), вместо неё показывается встроенная иллюстрация в стиле сайта. Карта: © участники OpenStreetMap (ODbL).</p></div></div></section>`);
}

export async function privacy(ctx) {
  setTitle('Политика конфиденциальности');
  ctx.app.innerHTML = String(html`<section class="page-hero"><div class="wrap"><span class="eyebrow">Документы</span><h1>Политика обработки персональных данных</h1><p class="lead">Редакция 2026-10 (шаблон для демонстрационной версии).</p></div></section>
  <section class="section tight"><div class="wrap article">
    <div class="notice warn">${icon('warn')}<p>Это шаблон политики для учебно-демонстрационной версии платформы. Перед запуском реального сервиса в России текст и процессы обработки данных должны пройти юридическую проверку на соответствие Федеральному закону № 152-ФЗ «О персональных данных» (включая уведомление Роскомнадзора, локализацию баз данных с персональными данными граждан РФ на территории РФ, назначение ответственного за обработку и т. д.).</p></div>
    <h2>1. Оператор и цели обработки</h2><p>Оператор персональных данных указывается при запуске сервиса. Данные обрабатываются для регистрации и авторизации пользователей, ведения личного кабинета, учёта транспортных средств и маршрутов, проведения голосований за развитие инфраструктуры, рассмотрения коммерческих предложений, направления уведомлений и формирования обезличенной аналитики спроса.</p>
    <h2>2. Состав данных</h2><ul><li>Учётные данные: адрес электронной почты, хеш пароля (сам пароль не хранится).</li><li>Профиль: имя, регион, город, телефон (по желанию), предпочитаемое топливо, должность.</li><li>Данные организаций: наименование, ИНН, регион, контакты представителя.</li><li>Сведения о транспорте, маршрутах, голосах, инициативах, комментариях и коммерческих предложениях.</li><li>Технические данные: IP-адрес, сведения о браузере, время действий (для безопасности и журнала).</li></ul>
    <h2>3. Правовое основание</h2><p>Согласие субъекта персональных данных, которое даётся при регистрации и фиксируется с указанием версии документа и времени; для организаций — также заключение и исполнение договорённостей.</p>
    <h2>4. Хранение и защита</h2><p>Пароли хранятся в виде криптографического хеша (scrypt). Сессии защищены cookie с флагами HttpOnly и SameSite, изменения данных — CSRF-токенами. Доступ к коммерческим данным имеют только сотрудники организации и уполномоченные сотрудники оператора; их действия записываются в журнал. Обезличенная аналитика не позволяет идентифицировать пользователя: популярные маршруты показываются, только если их указали не менее двух участников.</p>
    <h2>5. Передача третьим лицам</h2><p>Данные не передаются третьим лицам, кроме случаев, предусмотренных законом. Для построения маршрутов на сервер маршрутизации передаются только координаты точек маршрута, без персональных данных.</p>
    <h2>6. Права пользователя</h2><p>Пользователь может просматривать и изменять свои данные, выгрузить их в личном кабинете («Профиль и безопасность» → «Выгрузить мои данные»), а также удалить аккаунт, отозвав согласие на обработку. Удаление аккаунта удаляет профиль, транспорт, маршруты, голоса и уведомления.</p>
    <h2>7. Cookie</h2><p>Используются только необходимые cookie: идентификатор сессии (gc_session) и защитный токен (gc_csrf). Сторонние счётчики и рекламные cookie не применяются.</p>
    <h2>8. Контакты</h2><p>Вопросы об обработке данных направляйте через <a href="/feedback">форму обратной связи</a>.</p>
  </div></section>`);
}

export async function feedback(ctx) {
  setTitle('Обратная связь');
  ctx.app.innerHTML = String(html`<section class="page-hero"><div class="wrap"><span class="eyebrow">Связь с оператором</span><h1>Обратная связь</h1><p class="lead">Задайте вопрос, предложите улучшение или сообщите об ошибке в данных — например, о неверных часах работы станции.</p></div></section>
  <section class="section tight"><div class="wrap" style="max-width:820px"><form class="card pad form" id="ff">
    <div class="form-grid">${!state.user ? html`${field('name', 'Ваше имя', { required: true })}${field('email', 'E-mail для ответа', { type: 'email', required: true })}` : ''}
    ${field('topic', 'Тема', { options: LABELS.feedbackTopic, value: ctx.query.topic || 'question' })}${field('related', 'Связанный объект', { value: ctx.query.related || '', placeholder: 'например, название станции' })}
    ${field('message', 'Сообщение', { type: 'textarea', required: true, full: true })}</div>
    <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
    ${!state.user ? checkbox('consent', raw('Согласен(на) на обработку персональных данных согласно <a href="/privacy" target="_blank">Политике</a>')) : ''}
    <button class="btn primary" type="submit">Отправить</button>
  </form></div></section>`);
  bindForm($('#ff'), async (v, f) => { const r = await api.post('/api/feedback', v); toast(r.message, 'ok', 6000); f.reset(); });
}

export async function newsList(ctx) {
  setTitle('Новости');
  const data = await api.get('/api/news');
  ctx.app.innerHTML = String(html`${hero('Новости', 'Новости газомоторной инфраструктуры', 'Публикации о развитии сети, работе платформы и газомоторном транспорте.', 'cng-station-2')}
  <section class="section tight"><div class="wrap"><div class="grid g3">${data.items.map((n) => html`<a class="card hover photo-card" href="/news/${n.slug}"><div class="ph" style="${raw(photoBg(n.photoKey || 'cng-station', 900))}"><div class="badges">${demoBadge(n.isDemo)}</div></div><div class="body"><span class="tiny muted">${date(n.publishedAt)}</span><h3>${n.title}</h3><p class="small muted" style="margin:0">${n.summary || ''}</p></div></a>`)}</div>
  ${!data.items.length ? html`<div class="empty">Публикаций пока нет</div>` : ''}</div></section>`);
}

export async function newsItem(ctx) {
  let n;
  try { n = (await api.get(`/api/news/${encodeURIComponent(ctx.params.slug)}`)).item; } catch { ctx.app.innerHTML = '<section class="section"><div class="wrap"><div class="empty"><h3>Публикация не найдена</h3><a class="btn" href="/news">Все новости</a></div></div></section>'; return; }
  setTitle(n.title);
  const p = photo(n.photoKey || 'cng-station');
  ctx.app.innerHTML = String(html`<section class="section"><div class="wrap article">
    <div class="breadcrumbs"><a href="/news">Новости</a> / ${date(n.publishedAt)}</div>
    <h1 style="font-size:clamp(28px,3.4vw,44px);margin:14px 0 20px">${n.title} ${demoBadge(n.isDemo)}</h1>
    <div class="cover" style="${raw(photoBg(n.photoKey || 'cng-station', 1600))}"><a class="img-credit" href="${p.page}" target="_blank" rel="noopener">Фото: Wikimedia Commons</a></div>
    ${n.summary ? html`<p style="font-size:19px;color:#fff">${n.summary}</p>` : ''}
    ${n.body.split(/\n\s*\n/).map((para) => html`<p>${para}</p>`)}
    <a class="btn" href="/news" style="margin-top:20px">← Все новости</a>
  </div></section>`);
}
