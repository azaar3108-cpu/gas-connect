// «Где нужна новая АГНКС?» — инициативы, голосование, создание предложения, обсуждение.
import { html, raw, api, $, $$, fmt, photo, photoBg, icon, statusBadge, demoBadge, setTitle, state, LABELS, date, dateTime, toast, showError, go, field, checkbox, bindForm, modal, regionDatalist, isBusiness, plural, ApiError, confirmDialog } from '../core.js';
import { createMap, pickerMap, proposalIcon, stationIcon, leaflet } from '../components/map.js';

const KIND = { agnks: 'АГНКС', modular: 'Модульная АГНКС', cryo: 'КриоАЗС (СПГ)', pagz: 'ПАГЗ', multi: 'АЗС с метаном', any: 'Не важно' };

async function doVote(p, after) {
  if (!state.user) { toast('Войдите или зарегистрируйтесь, чтобы голосовать'); go(`/login?next=${encodeURIComponent('/vote/' + p.id)}`); return; }
  if (!state.user.emailVerified) { toast('Подтвердите e-mail, чтобы голосовать — ссылка в письме или в личном кабинете', 'error', 6000); return; }
  const send = async (body) => { const r = await api.post(`/api/proposals/${p.id}/vote`, body); toast(r.message, 'ok'); after?.(r); };
  if (p.myVote) {
    const r = await api.del(`/api/proposals/${p.id}/vote`);
    toast(r.message);
    after?.(r);
    return;
  }
  if (isBusiness()) {
    const m = modal({ title: 'Поддержать строительство', body: html`<form class="form" id="vf">
      <p class="muted small" style="margin:0">Укажите, сколько автомобилей вашей организации заправлялись бы на этой станции. Число не может превышать размер автопарка; оно учитывается как интерес, а не как обязательство.</p>
      <div class="form-grid">${field('vehiclesCount', 'Количество автомобилей', { type: 'number', min: 1, value: 1, required: true })}${field('tripsPerMonth', 'Проездов участка в месяц', { type: 'number', min: 0, value: 10 })}
      ${field('fuelType', 'Топливо', { options: { cng: 'КПГ', lng: 'СПГ', both: 'КПГ и СПГ' } })}</div>
      <div class="form-actions"><button class="btn primary" type="submit">${icon('vote')} Поддержать</button></div></form>` });
    bindForm($('#vf', m.root), async (v) => { await send(v); m.close(); });
    return;
  }
  await send({ vehiclesCount: 1 });
}

function card(p) {
  return html`<article class="card hover photo-card">
    <a class="ph" href="/vote/${p.id}" style="${raw(photoBg(p.photoKey || 'highway', 900))}" aria-label="${p.title}"><div class="badges">${statusBadge(p.status, p.statusLabel)}${demoBadge(p.isDemo)}</div></a>
    <div class="body">
      <div class="meta"><span>${icon('pin', 14)} ${p.region}</span>${p.highway ? html`<span>${icon('route', 14)} ${p.highway}</span>` : ''}<span>${KIND[p.preferredKind] || '—'}</span></div>
      <h3><a href="/vote/${p.id}" style="color:#fff">${p.title}</a></h3>
      <p class="small muted" style="margin:0">${p.justification.length > 170 ? p.justification.slice(0, 170) + '…' : p.justification}</p>
      <div class="grid g3" style="gap:8px;margin-top:4px">
        <div class="spec"><b>${fmt(p.votes)}</b><span>${plural(p.votes, 'голос', 'голоса', 'голосов')}</span></div>
        <div class="spec"><b>${fmt(p.demand.vehiclesTotal)}</b><span>автомобилей</span></div>
        <div class="spec"><b>${p.demandEquivM3 ? fmt(p.demandEquivM3 / 1000, 1) : '—'}</b><span>тыс. м³/мес.*</span></div>
      </div>
      <div class="foot">
        ${p.demand.multiCompany ? html`<span class="badge info plain">${icon('people', 12)} ${p.demand.organizations} компаний на участке</span>` : html`<span class="tiny muted">${p.comments} ${plural(p.comments, 'комментарий', 'комментария', 'комментариев')}</span>`}
        ${['published', 'under_review'].includes(p.status) ? html`<button class="btn sm ${p.myVote ? 'voted' : 'primary'}" data-vote="${p.id}">${p.myVote ? raw(`${icon('check')} Вы поддержали`) : 'Поддержать строительство'}</button>` : ''}
      </div>
    </div></article>`;
}

export async function list(ctx) {
  setTitle('Где нужна новая АГНКС?');
  ctx.app.innerHTML = String(html`
  <section class="page-hero photo" style="${raw(photoBg('highway', 1800))}"><div class="wrap">
    <span class="eyebrow">Голосование</span>
    <h1>Где нужна новая АГНКС?</h1>
    <p class="lead">Поддерживайте строительство станций на участках дорог, где не хватает заправок метаном, или предложите свою точку. Голос — сигнал интереса для оператора, а не гарантия строительства.</p>
    <div class="actions"><a class="btn primary lg" href="/vote/new">${icon('plus')} Предложить новую станцию</a><a class="btn lg" href="/map">${icon('map')} Посмотреть на карте</a></div>
  </div></section>
  <section class="section tight"><div class="wrap">
    <div class="toolbar" style="margin-bottom:20px">
      <select class="select" id="sort" aria-label="Сортировка"><option value="votes">По количеству голосов</option><option value="vehicles">По числу заинтересованных автомобилей</option><option value="volume">По оценочному объёму потребления</option><option value="new">Сначала новые</option><option value="region">По региону (А–Я)</option></select>
      <select class="select" id="region" aria-label="Регион"><option value="">Все регионы</option></select>
      <select class="select" id="status" aria-label="Статус"><option value="">Активные</option><option value="published">Сбор голосов</option><option value="under_review">Рассматривается оператором</option><option value="included">Включены в план</option><option value="rejected">Отклонённые</option></select>
      <span class="muted small" id="total" style="margin-left:auto"></span>
    </div>
    <div class="grid g3" id="cards">${raw('<div class="skeleton" style="min-height:420px"></div>'.repeat(3))}</div>
    <p class="tiny muted" style="margin-top:16px">* Оценочный объём — расчётная потребность автомобилей участников, чьи маршруты проходят в радиусе 25 км, и проголосовавших (СПГ пересчитан в м³ по 1 кг ≈ 1,39 м³). Автомобиль учитывается один раз. Это не прогноз продаж станции.</p>
    <div class="notice" style="margin-top:12px">${icon('shield')}<p>Голосовать могут только зарегистрированные пользователи с подтверждённым e-mail. Один пользователь — один голос на инициативу (проверяется сервером), голос можно отозвать. Оператор модерирует инициативы и комментарии.</p></div>
  </div></section>`);
  let regionsFilled = false;
  async function load() {
    const q = new URLSearchParams({ sort: $('#sort').value });
    if ($('#region').value) q.set('region', $('#region').value);
    if ($('#status').value) q.set('status', $('#status').value);
    const data = await api.get('/api/proposals?' + q);
    if (!regionsFilled) { $('#region').insertAdjacentHTML('beforeend', String(html`${data.regions.map((r) => html`<option>${r}</option>`)}`)); regionsFilled = true; }
    $('#total').textContent = `Инициатив: ${data.items.length}`;
    $('#cards').innerHTML = data.items.length ? String(html`${data.items.map(card)}`) : String(html`<div class="empty" style="grid-column:1/-1"><h3>Инициатив пока нет</h3><p>Станьте первым — предложите точку для новой станции.</p><a class="btn primary" href="/vote/new">Предложить станцию</a></div>`);
    $$('[data-vote]').forEach((b) => (b.onclick = async () => {
      const p = data.items.find((x) => x.id === b.dataset.vote);
      try { await doVote(p, load); } catch (e) { showError(e); }
    }));
  }
  ['sort', 'region', 'status'].forEach((id) => $('#' + id).addEventListener('change', () => load().catch(showError)));
  await load();
}

export async function detail(ctx) {
  let p;
  try { p = (await api.get(`/api/proposals/${ctx.params.id}`)).item; } catch (e) {
    ctx.app.innerHTML = String(html`<section class="section"><div class="wrap"><div class="empty"><h3>Инициатива не найдена</h3><a class="btn" href="/vote">К списку инициатив</a></div></div></section>`);
    return;
  }
  setTitle(p.title);
  const ph = photo(p.photoKey || 'highway');
  const votable = ['published', 'under_review'].includes(p.status);
  ctx.app.innerHTML = String(html`
  <section class="page-hero photo" style="${raw(photoBg(p.photoKey || 'highway', 1800))}"><div class="wrap">
    <div class="breadcrumbs"><a href="/vote">Голосование</a> / ${p.region}</div>
    <div class="chips" style="margin-top:14px">${statusBadge(p.status, p.statusLabel)}<span class="badge info plain">${p.preferredKindLabel}</span>${demoBadge(p.isDemo)}</div>
    <h1>${p.title}</h1>
    <p class="lead">${p.settlement}${p.highway ? ' · трасса ' + p.highway : ''} · предложил(а): ${p.authorName} · ${date(p.createdAt)}</p>
  </div><a class="hero-credit" href="${ph.page}" target="_blank" rel="noopener">Фото: Wikimedia Commons</a></section>
  <section class="section tight"><div class="wrap">
    <div class="grid" style="grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:22px" id="dgrid">
      <div class="grid" style="gap:22px">
        ${p.status === 'pending' ? html`<div class="notice warn">${icon('clock')}<p>Инициатива ожидает модерации и пока видна только вам и оператору.</p></div>` : ''}
        ${p.moderationNote && ['rejected', 'hidden'].includes(p.status) ? html`<div class="notice danger">${icon('warn')}<p>Комментарий модератора: ${p.moderationNote}</p></div>` : ''}
        <div class="card pad"><h3>Почему здесь нужна станция</h3><p>${p.justification}</p>
          <div class="dl">
            <div>Как часто проезжают участок</div><div>${p.travelFrequency || '—'}</div>
            <div>Транспорт</div><div>${p.transportType || '—'}</div>
            <div>Альтернативные заправки</div><div>${p.hasAlternatives ? 'есть' + (p.alternativesNote ? ': ' + p.alternativesNote : '') : 'нет'}</div>
            <div>До ближайшей доступной станции (по словам автора)</div><div>${p.distanceToNearestKm !== null ? fmt(p.distanceToNearestKm) + ' км' : '—'}</div>
            <div>До ближайшей действующей станции на карте (по прямой)</div><div>${p.nearestOperationalKm !== null ? fmt(p.nearestOperationalKm) + ' км' : '—'}</div>
            <div>Координаты</div><div>${p.lat.toFixed(4)}, ${p.lng.toFixed(4)}</div>
            ${p.comment ? html`<div>Комментарий</div><div>${p.comment}</div>` : ''}
          </div></div>
        <div class="card" style="overflow:hidden"><div id="pmap" class="leaflet-host" style="height:340px"></div></div>
        <div class="card pad"><h3>Обсуждение</h3><div id="comments" class="grid" style="gap:12px"></div>
          ${state.user ? html`<form id="cform" class="form" style="margin-top:16px">${field('body', 'Ваш комментарий', { type: 'textarea', required: true, placeholder: 'Аргументы, подробности о поездках, пожелания к станции…' })}<div class="form-actions"><button class="btn primary" type="submit">Отправить</button><span class="tiny muted">Комментарии со ссылками проходят модерацию. Не чаще одного сообщения в 20 секунд.</span></div></form>` : html`<p class="muted small" style="margin-top:14px"><a href="/login?next=${encodeURIComponent('/vote/' + p.id)}">Войдите</a>, чтобы участвовать в обсуждении.</p>`}
        </div>
      </div>
      <aside class="grid" style="gap:22px;align-content:start">
        <div class="card pad">
          <div class="vote-box"><div class="vote-count" id="vc">${fmt(p.votes)}<small>${plural(p.votes, 'человек поддержал', 'человека поддержали', 'человек поддержали')}</small></div></div>
          ${votable ? html`<button class="btn lg ${p.myVote ? 'voted' : 'primary'}" id="voteBtn" style="width:100%;margin-top:16px">${p.myVote ? raw(`${icon('check')} Вы поддержали · отозвать голос`) : raw(`${icon('vote')} Поддержать строительство`)}</button>` : html`<div class="notice" style="margin-top:14px">${icon('info')}<p>Голосование закрыто: ${p.statusLabel.toLowerCase()}.</p></div>`}
          <button class="btn sm ghost" id="favBtn" style="width:100%;margin-top:10px">${icon('star')} ${p.favorite ? 'Вы следите за инициативой' : 'Следить за изменениями статуса'}</button>
        </div>
        <div class="card pad"><h3>Объединённый спрос</h3>
          <p class="tiny muted">Маршруты участников в радиусе ${p.demand.radiusKm} км и проголосовавшие. Автомобиль учитывается один раз.</p>
          <div class="grid g2" style="gap:10px">
            <div class="kpi"><div class="v">${fmt(p.demand.vehiclesTotal)}</div><div class="l">автомобилей</div></div>
            <div class="kpi"><div class="v">${fmt(p.demand.parties)}</div><div class="l">участников</div></div>
            <div class="kpi"><div class="v">${fmt(p.demand.organizations)}</div><div class="l">организаций</div></div>
            <div class="kpi"><div class="v">${fmt(p.demand.routesNear)}</div><div class="l">маршрутов рядом</div></div>
          </div>
          <div class="dl" style="margin-top:10px"><div>Расчётная потребность КПГ</div><div>${fmt(p.demand.demandM3)} м³/мес.</div><div>Расчётная потребность СПГ</div><div>${fmt(p.demand.demandKg)} кг/мес.</div><div>Заявлено ТС при голосовании</div><div>${fmt(p.declaredVehicles)}</div></div>
          <p class="tiny muted" style="margin:10px 0 0">Голоса и расчётная потребность — сигнал интереса, а не гарантированный спрос.</p>
        </div>
        <div class="card pad"><h3>Статус рассмотрения</h3><div class="timeline">${p.history.map((h) => html`<div class="tl"><div class="when">${dateTime(h.created_at)}</div><b>${h.toLabel}</b>${h.comment ? html`<div class="small muted">${h.comment}</div>` : ''}</div>`)}</div>
          ${p.linkedStationId ? html`<a class="btn sm" href="/map?station=${p.linkedStationId}" style="margin-top:12px">Объект в плане развития →</a>` : ''}</div>
      </aside>
    </div>
  </div></section>`);
  if (matchMedia('(max-width: 900px)').matches) $('#dgrid').style.gridTemplateColumns = '1fr';

  $('#voteBtn') && ($('#voteBtn').onclick = async () => { try { await doVote(p, () => detail(ctx)); } catch (e) { showError(e); } });
  $('#favBtn').onclick = async () => {
    if (!state.user) { go(`/login?next=${encodeURIComponent('/vote/' + p.id)}`); return; }
    try { if (p.favorite) await api.del(`/api/favorites/proposal/${p.id}`); else await api.post('/api/favorites', { type: 'proposal', id: p.id }); detail(ctx); } catch (e) { showError(e); }
  };

  async function loadComments() {
    const c = await api.get(`/api/proposals/${p.id}/comments`);
    $('#comments').innerHTML = c.items.length ? String(html`${c.items.map((x) => html`<div class="msg ${x.staff ? 'op' : ''}"><div class="who">${x.author} · ${dateTime(x.createdAt)} ${x.status !== 'visible' ? html`<span class="badge plan plain">на модерации</span>` : ''} ${x.isDemo ? html`<span class="badge demo">демо</span>` : ''}</div><div style="white-space:pre-wrap">${x.body}</div>${x.mine ? html`<button class="linkbtn tiny" data-del="${x.id}">Удалить</button>` : ''}</div>`)}`) : '<p class="muted small">Комментариев пока нет.</p>';
    $$('[data-del]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Удалить комментарий?', { danger: true, ok: 'Удалить' })) { await api.del(`/api/comments/${b.dataset.del}`); loadComments(); } }));
  }
  loadComments().catch(showError);
  if ($('#cform')) bindForm($('#cform'), async (v, form) => { const r = await api.post(`/api/proposals/${p.id}/comments`, v); toast(r.message, 'ok'); form.reset(); loadComments(); });

  const L = await leaflet();
  const m = await createMap($('#pmap'), { center: [p.lat, p.lng], zoom: 5, scrollWheelZoom: false });
  L.marker([p.lat, p.lng], { icon: proposalIcon(L) }).addTo(m).bindTooltip('Предлагаемая точка', { permanent: false });
  L.circle([p.lat, p.lng], { radius: p.demand.radiusKm * 1000, color: '#47c8f5', weight: 1, dashArray: '4 6', fillOpacity: .04 }).addTo(m);
  api.get('/api/stations?status=operational').then((st) => st.items.forEach((s) => L.marker([s.lat, s.lng], { icon: stationIcon(L, s) }).bindTooltip(s.name).addTo(m))).catch(() => {});
  ctx.cleanup = () => m.remove();
}

export async function create(ctx) {
  setTitle('Предложить новую станцию');
  if (!state.user) {
    ctx.app.innerHTML = String(html`<section class="section"><div class="wrap" style="max-width:720px"><div class="empty"><h3>Предложить новую станцию</h3><p>Чтобы предложить точку для строительства, войдите или зарегистрируйтесь. Это защищает голосование от накруток.</p><div class="form-actions" style="justify-content:center"><a class="btn primary" href="/login?next=${encodeURIComponent('/vote/new' + location.search)}">Войти</a><a class="btn" href="/register">Зарегистрироваться</a></div></div></div></section>`);
    return;
  }
  const q = ctx.query;
  ctx.app.innerHTML = String(html`
  <section class="page-hero"><div class="wrap"><div class="breadcrumbs"><a href="/vote">Голосование</a> / Новая инициатива</div><h1>Предложить новую станцию</h1><p class="lead">Отметьте точку на карте и расскажите, почему здесь нужна заправка. После модерации инициатива станет доступна для голосования.</p></div></section>
  <section class="section tight"><div class="wrap">
    ${!state.user.emailVerified ? html`<div class="notice warn" style="margin-bottom:18px">${icon('warn')}<p>Чтобы отправить инициативу, подтвердите e-mail. <a href="/account">Отправить письмо повторно</a></p></div>` : ''}
    <form id="pf" class="grid" style="grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:22px" novalidate>
      <div class="card pad form">
        <fieldset><legend>Где</legend><div class="form-grid">
          ${field('region', 'Регион', { required: true, list: 'regions', value: q.region || state.user.region || '' })}
          ${field('settlement', 'Город или ближайший населённый пункт', { required: true, value: q.settlement || '' })}
          ${field('highway', 'Автомобильная трасса', { placeholder: 'например, М-11 «Нева», 320 км', value: q.highway || '' })}
          ${field('preferredKind', 'Предпочтительный тип станции', { options: KIND, value: q.kind || 'any' })}
          ${field('lat', 'Широта', { type: 'number', step: 'any', required: true, value: q.lat || '', hint: 'Кликните по карте, чтобы указать точку' })}
          ${field('lng', 'Долгота', { type: 'number', step: 'any', required: true, value: q.lng || '' })}
        </div></fieldset>
        <fieldset><legend>Почему здесь</legend><div class="form-grid">
          ${field('justification', 'Почему здесь необходима заправка', { type: 'textarea', required: true, full: true, placeholder: 'Например: на участке 300 км нет заправки КПГ, регулярно езжу по работе…' })}
          ${field('travelFrequency', 'Как часто вы проезжаете этот участок', { required: true, options: ['Ежедневно', 'Несколько раз в неделю', 'Еженедельно', 'Несколько раз в месяц', 'Реже раза в месяц'], value: 'Несколько раз в месяц' })}
          ${field('transportType', 'Каким транспортом пользуетесь', { required: true, value: isBusiness() ? 'Грузовые автомобили на КПГ' : 'Легковой автомобиль на КПГ' })}
          ${field('distanceToNearestKm', 'Расстояние до ближайшей доступной станции, км', { type: 'number', min: 0, value: q.gapKm || '' })}
          ${field('authorFuel', 'Нужное топливо', { options: { cng: 'КПГ', lng: 'СПГ', both: 'КПГ и СПГ' } })}
          ${field('authorVehicles', isBusiness() ? 'Сколько автомобилей вашей организации заправлялись бы здесь' : 'Количество ваших автомобилей', { type: 'number', min: 1, value: 1 })}
          <div class="field full">${checkbox('hasAlternatives', 'Есть альтернативные заправки поблизости')}</div>
          ${field('alternativesNote', 'Какие альтернативы и чем они не подходят', { full: true })}
          ${field('comment', 'Комментарий', { type: 'textarea', full: true })}
        </div></fieldset>
        <div class="form-actions"><button class="btn primary lg" type="submit" ${state.user.emailVerified ? '' : 'disabled'}>Отправить инициативу</button><span class="tiny muted">Ваш голос будет засчитан автоматически.</span></div>
      </div>
      <div><div class="card" style="overflow:hidden;position:sticky;top:96px"><div id="pick" class="leaflet-host" style="height:560px"></div><div class="pad small muted">Кликните по карте, чтобы отметить место. Рядом показаны действующие станции.</div></div></div>
    </form>
    ${regionDatalist()}
  </div></section>`);
  if (matchMedia('(max-width: 900px)').matches) $('#pf').style.gridTemplateColumns = '1fr';
  const form = $('#pf');
  const lat = Number(q.lat), lng = Number(q.lng);
  const pm = await pickerMap($('#pick'), { lat, lng, onPick: (la, ln) => { form.lat.value = la; form.lng.value = ln; } });
  const L = await leaflet();
  api.get('/api/stations?status=operational').then((st) => st.items.forEach((s) => L.marker([s.lat, s.lng], { icon: stationIcon(L, s) }).bindTooltip(s.name).addTo(pm.map))).catch(() => {});
  ['lat', 'lng'].forEach((n) => form[n].addEventListener('change', () => { const a = Number(form.lat.value), b = Number(form.lng.value); if (a && b) pm.setPoint(a, b); }));
  const submit = async (v, force = false) => {
    try {
      const r = await api.post('/api/proposals', { ...v, force });
      toast(r.message, 'ok', 6000);
      go(`/vote/${r.id}`);
    } catch (e) {
      if (e instanceof ApiError && e.status === 409 && e.details?.duplicateOf) {
        const m = modal({ title: 'Рядом уже есть инициатива', body: html`<p>${e.message}</p><div class="form-actions"><a class="btn primary" href="/vote/${e.details.duplicateOf}">Открыть и поддержать</a><button class="btn" id="forceBtn">Всё равно создать новую</button></div>` });
        $('#forceBtn', m.root).onclick = async () => { m.close(); try { await submit(v, true); } catch (err) { showError(err); } };
        return;
      }
      throw e;
    }
  };
  bindForm(form, (v) => submit(v));
  ctx.cleanup = () => pm.map.remove();
}
