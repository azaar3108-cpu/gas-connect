// Личные кабинеты: физическое лицо, ИП, юридическое лицо.
import { html, raw, api, $, $$, fmt, icon, statusBadge, demoBadge, setTitle, state, LABELS, date, dateTime, toast, showError, go, field, checkbox, bindForm, modal, confirmDialog, formValues, setFormValues, regionDatalist, cityDatalist, loadCities, refreshSession, initials, isBusiness, plural } from '../core.js';
import { vehicleMetrics, FUELS, CONS_UNITS } from '../shared/calc.js';
import { createMap, leaflet } from '../components/map.js';
import { bars } from '../components/charts.js';

const VEHICLE_TYPES = ['Легковой', 'Лёгкий коммерческий', 'Грузовой (до 12 т)', 'Магистральный тягач', 'Автобус', 'Коммунальная / спецтехника', 'Другое'];
const EQUIPMENT = ['КПГ: баллоны тип 1 (сталь)', 'КПГ: баллоны тип 2 (металлокомпозит)', 'КПГ: баллоны тип 3', 'КПГ: баллоны тип 4 (композит)', 'СПГ: криогенный бак', 'Заводская газовая версия', 'Не установлено'];
const OFFER_STATUS = { draft: 'Черновик', submitted: 'Отправлено', in_review: 'На рассмотрении', needs_info: 'Требуется уточнение', preliminarily_approved: 'Предварительно согласовано', rejected: 'Отклонено' };

function tabs(u) {
  const biz = ['ip', 'company'].includes(u.accountType);
  const t = [['', 'Обзор', 'layers']];
  if (biz) t.push(['company', u.accountType === 'ip' ? 'Мой бизнес' : 'Моя компания', 'building'], ['fleet', 'Мой автопарк', 'car'], ['routes', 'Наши маршруты', 'route'], ['demand', 'Потребность в газе', 'fuel'], ['offers', 'Договоры и заявки', 'doc'], ['contracts', 'Договорённости', 'check']);
  else t.push(['vehicles', 'Мои автомобили', 'car'], ['routes', 'Мои маршруты', 'route']);
  t.push(['proposals', biz ? 'Предложения по станциям' : 'Мои инициативы', 'vote'], ['favorites', 'Избранное', 'star'], ['notifications', 'Уведомления', 'bell'], ['profile', 'Профиль и безопасность', 'user']);
  return t;
}

export async function page(ctx) {
  if (!state.user) { go(`/login?next=${encodeURIComponent(location.pathname)}`, { replace: true }); return; }
  const u = state.user;
  const tab = ctx.params.tab || '';
  const list = tabs(u);
  ctx.app.innerHTML = String(html`<div class="wrap layout">
    <aside class="side" aria-label="Разделы кабинета">
      <div class="who"><span class="avatar" style="width:44px;height:44px;font-size:16px;margin-bottom:10px">${initials(u.name)}</span><strong>${u.name}</strong><span class="tiny muted">${LABELS.account[u.accountType]}${u.organization ? html`<br>${u.organization.name}<br>Роль: ${LABELS.member[u.organization.role]}` : ''}</span></div>
      ${list.map(([k, l, ic]) => html`<a href="/account${k ? '/' + k : ''}" class="${tab === k ? 'active' : ''}">${icon(ic, 17)} ${l}${k === 'notifications' && u.unreadNotifications ? html`<span class="n">${u.unreadNotifications}</span>` : ''}</a>`)}
      ${['operator', 'admin'].includes(u.role) ? html`<div class="group">Сотрудник</div><a href="/operator">${icon('chart', 17)} Панель оператора</a>` : ''}
    </aside>
    <div id="pane" style="min-width:0"><div class="skeleton" style="min-height:300px"></div></div>
  </div>`);
  const pane = $('#pane');
  const map = { '': overview, company, fleet: (p) => vehiclesTab(p, 'fleet'), vehicles: (p) => vehiclesTab(p, 'personal'), routes: routesTab, demand, offers: offersTab, contracts, proposals, favorites, notifications, profile };
  const fn = map[tab];
  if (!fn) { pane.innerHTML = '<div class="empty">Раздел не найден</div>'; return; }
  setTitle('Личный кабинет');
  try { await fn(pane, ctx); } catch (e) { pane.innerHTML = String(html`<div class="empty"><h3>Не удалось загрузить раздел</h3><p>${e.message}</p></div>`); }
}

const head = (title, sub, actions = '') => html`<div class="content-head"><div><h1>${title}</h1>${sub ? html`<p>${sub}</p>` : ''}</div><div class="form-actions">${actions}</div></div>`;

function verifyBanner() {
  if (state.user.emailVerified) return '';
  return html`<div class="notice warn" style="margin-bottom:18px">${icon('mail')}<p>Подтвердите адрес электронной почты, чтобы голосовать, предлагать станции и отправлять заявки. <button class="linkbtn" id="resend">Отправить письмо ещё раз</button><span id="resendRes"></span></p></div>`;
}
function bindResend() {
  const b = $('#resend');
  if (!b) return;
  b.onclick = async () => { try { const r = await api.post('/api/auth/resend-verification'); toast(r.message, 'ok'); if (r.devVerifyLink) $('#resendRes').innerHTML = String(html` Режим разработки: <a href="${r.devVerifyLink.replace(location.origin, '')}">подтвердить</a>`); } catch (e) { showError(e); } };
}

// ---------- Обзор ----------
async function overview(pane) {
  const [me, notes] = await Promise.all([api.get('/api/me'), api.get('/api/notifications')]);
  const biz = isBusiness();
  const c = me.counts;
  pane.innerHTML = String(html`
    ${head(`Здравствуйте, ${(me.profile?.fullName || '').split(' ')[0] || 'участник'}!`, `${LABELS.account[me.user.accountType]}${me.organization ? ' · ' + (me.organization.shortName || me.organization.fullName) : ''} · на платформе с ${date(me.user.createdAt)}`)}
    ${verifyBanner()}
    ${me.organization ? html`<div class="notice ${me.organization.verificationStatus === 'verified' ? 'ok' : 'warn'}" style="margin-bottom:18px">${icon('shield')}<p>Статус проверки организации: <b>${LABELS.verification[me.organization.verificationStatus]}</b>. ${me.organization.verificationNote || ''}</p></div>` : ''}
    <div class="grid g4">
      ${biz ? html`<a class="kpi" href="/account/fleet" style="color:#fff"><div class="v">${fmt(c.fleet)}</div><div class="l">ТС в автопарке</div></a>` : html`<a class="kpi" href="/account/vehicles" style="color:#fff"><div class="v">${fmt(c.vehicles)}</div><div class="l">автомобилей</div></a>`}
      <a class="kpi" href="/account/routes" style="color:#fff"><div class="v">${fmt(c.routes)}</div><div class="l">регулярных маршрутов</div></a>
      <a class="kpi" href="/vote" style="color:#fff"><div class="v">${fmt(c.votes)}</div><div class="l">поддержанных инициатив</div></a>
      ${biz ? html`<a class="kpi" href="/account/offers" style="color:#fff"><div class="v">${fmt(c.offers)}</div><div class="l">коммерческих предложений</div></a>` : html`<a class="kpi" href="/account/proposals" style="color:#fff"><div class="v">${fmt(c.proposals)}</div><div class="l">моих инициатив</div></a>`}
    </div>
    <div class="grid g2" style="margin-top:22px">
      <div class="card pad"><h3>Быстрые действия</h3><div class="grid" style="gap:10px">
        <a class="btn" href="/account/${biz ? 'fleet' : 'vehicles'}">${icon('car')} ${biz ? 'Добавить автомобиль в автопарк' : 'Добавить автомобиль'}</a>
        <a class="btn" href="/account/routes">${icon('route')} Указать регулярный маршрут</a>
        <a class="btn" href="/vote">${icon('vote')} Проголосовать за новые станции</a>
        ${biz ? html`<a class="btn primary" href="/account/offers/new">${icon('doc')} Предложить договор сотрудничества</a>` : html`<a class="btn primary" href="/vote/new">${icon('plus')} Предложить новую станцию</a>`}
      </div></div>
      <div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">Последние уведомления</h3><a class="small" href="/account/notifications">Все</a></div>
        <div style="margin-top:10px">${notes.items.slice(0, 5).map((n) => html`<a href="${n.link || '/account/notifications'}" style="display:block;padding:10px 0;border-bottom:1px solid var(--line);color:#fff"><div class="tiny muted">${dateTime(n.createdAt)} ${n.read ? '' : html`<span class="badge info plain">новое</span>`}</div><div class="small" style="font-weight:600">${n.title}</div></a>`)}
        ${!notes.items.length ? html`<p class="muted small">Уведомлений пока нет. Добавьте маршруты и подпишитесь на объекты — мы сообщим о новых станциях.</p>` : ''}</div></div>
    </div>`);
  bindResend();
}

// ---------- Профиль ----------
async function profile(pane) {
  const me = await api.get('/api/me');
  const p = me.profile || {};
  pane.innerHTML = String(html`${head('Профиль и безопасность', 'Контактные данные, пароль и управление персональными данными.')}
    ${verifyBanner()}
    <div class="grid" style="gap:22px">
      <form class="card pad form" id="pf"><h3>Личные данные</h3><div class="form-grid">
        ${field('fullName', me.user.accountType === 'person' ? 'Имя' : 'ФИО', { required: true, value: p.fullName })}
        <div class="field"><label>Электронная почта</label><input value="${me.user.email}" disabled></div>
        ${field('region', 'Регион проживания / деятельности', { required: true, value: p.region, list: 'regions' })}
        ${field('city', 'Город', { value: p.city })}
        ${field('phone', 'Телефон', { type: 'tel', value: p.phone, hint: 'необязательно' })}
        ${field('contactNote', 'Другие контакты', { value: p.contactNote, hint: 'необязательно' })}
        ${field('preferredFuel', 'Предпочитаемый вид газомоторного топлива', { options: { undecided: 'Пока не выбрано', cng: 'КПГ', lng: 'СПГ', both: 'КПГ и СПГ' }, value: p.preferredFuel })}
        ${me.user.accountType !== 'person' ? field('position', 'Должность', { value: p.position }) : ''}
        <div class="field full">${checkbox('notifyEmail', 'Получать важные уведомления на e-mail', p.notifyEmail)}</div>
      </div><div class="form-actions"><button class="btn primary" type="submit">Сохранить</button></div></form>
      <form class="card pad form" id="cp"><h3>Смена пароля</h3><div class="form-grid">
        ${field('currentPassword', 'Текущий пароль', { type: 'password', required: true, attrs: 'autocomplete="current-password"' })}
        ${field('newPassword', 'Новый пароль', { type: 'password', required: true, hint: 'не менее 10 символов, буквы и цифры', attrs: 'autocomplete="new-password"' })}
      </div><div class="form-actions"><button class="btn" type="submit">Изменить пароль</button><span class="tiny muted">Остальные сеансы будут завершены.</span></div></form>
      <div class="card pad"><h3>Персональные данные</h3><p class="muted small">Вы можете выгрузить сведения, которые хранятся о вас на платформе, или удалить аккаунт (отзыв согласия на обработку персональных данных).</p>
        <div class="form-actions"><button class="btn" id="exp">${icon('download')} Выгрузить мои данные (JSON)</button><button class="btn danger" id="del">${icon('trash')} Удалить аккаунт</button></div></div>
    </div>${regionDatalist()}`);
  bindResend();
  bindForm($('#pf'), async (v) => { const r = await api.put('/api/me/profile', v); toast(r.message, 'ok'); await refreshSession(); });
  bindForm($('#cp'), async (v, f) => { const r = await api.post('/api/auth/change-password', v); toast(r.message, 'ok'); f.reset(); });
  $('#exp').onclick = async () => {
    try {
      const data = await api.get('/api/me/export');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      a.download = 'gas-connect-my-data.json';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch (e) { showError(e); }
  };
  $('#del').onclick = () => {
    const m = modal({ title: 'Удаление аккаунта', body: html`<form class="form" id="df"><p>Будут удалены профиль, автомобили, маршруты, голоса, избранное и уведомления. Действие необратимо.</p>${field('password', 'Подтвердите паролем', { type: 'password', required: true })}<div class="form-actions"><button class="btn danger" type="submit">Удалить навсегда</button></div></form>` });
    bindForm($('#df', m.root), async (v) => { const r = await api.post('/api/me/delete', v); m.close(); toast(r.message, 'ok', 6000); await refreshSession(); go('/'); });
  };
}

// ---------- Автомобили / автопарк ----------
function vehicleCard(v, canEdit) {
  const m = v.metrics;
  return html`<div class="card pad vehicle">
    <div class="top"><div><div class="tiny muted">${v.vehicleType}${v.year ? ' · ' + v.year : ''}</div><h3 style="margin:2px 0 0">${v.make} ${v.model}</h3></div>
      <div class="chips" style="gap:6px;justify-content:flex-end">${v.quantity > 1 ? html`<span class="badge info plain">× ${fmt(v.quantity)} ТС</span>` : ''}<span class="badge ${m.methane ? 'ok' : 'gray'} plain">${FUELS[v.fuelType]?.short || v.fuelType}</span>${demoBadge(v.isDemo)}</div></div>
    <div class="specs">
      ${m.methane === 'cng' ? html`<div class="spec"><b>${v.cylinderCount ?? '—'} × ${v.cylinderVolumeL ? fmt(v.cylinderVolumeL) + ' л' : '—'}</b><span>баллоны (геом. объём)</span></div><div class="spec"><b>${m.stockValue ? fmt(m.stockValue, 1) + ' м³' : '—'}</b><span>запас газа${v.stockIsManual ? '' : ' (расчёт)'}</span></div>` : ''}
      ${m.methane === 'lng' ? html`<div class="spec"><b>${v.lngTankL ? fmt(v.lngTankL) + ' л' : '—'}</b><span>объём криобака</span></div><div class="spec"><b>${m.stockValue ? fmt(m.stockValue) + ' кг' : '—'}</b><span>запас СПГ${v.stockIsManual ? '' : ' (расчёт)'}</span></div>` : ''}
      ${!m.methane ? html`<div class="spec"><b>${v.convertible ? 'Да' : 'Нет'}</b><span>можно перевести на метан</span></div><div class="spec"><b>${v.equipmentType || '—'}</b><span>ГБО</span></div>` : ''}
      <div class="spec"><b>${v.consumptionValue ? fmt(v.consumptionValue, 1) : '—'}</b><span>${CONS_UNITS[v.consumptionUnit] || 'расход'}</span></div>
      <div class="spec"><b>${m.rangeKm ? fmt(m.rangeKm) + ' км' : '—'}</b><span>запас хода</span></div>
      <div class="spec"><b>${v.monthlyMileageKm ? fmt(v.monthlyMileageKm) + ' км' : '—'}</b><span>пробег в месяц</span></div>
      <div class="spec"><b>${m.monthlyDemand ? fmt(m.monthlyDemand) + ' ' + m.demandUnit : '—'}</b><span>потребность/мес.${v.quantity > 1 ? ' (все ТС)' : ''}</span></div>
    </div>
    ${v.note ? html`<p class="small muted" style="margin:0">${v.note}</p>` : ''}
    ${canEdit ? html`<div class="form-actions"><button class="btn sm" data-edit="${v.id}">${icon('edit', 14)} Изменить</button><button class="btn sm danger" data-del="${v.id}">${icon('trash', 14)} Удалить</button></div>` : ''}
  </div>`;
}

function vehicleForm(v = {}, scope) {
  return html`<form class="form" id="vf">
    <div class="form-grid">
      ${field('make', 'Марка', { required: true, value: v.make, placeholder: 'КАМАЗ, ГАЗ, Lada…' })}
      ${field('model', 'Модель', { required: true, value: v.model })}
      ${field('year', 'Год выпуска', { type: 'number', min: 1960, max: new Date().getFullYear() + 1, value: v.year })}
      ${field('vehicleType', 'Тип транспортного средства', { options: VEHICLE_TYPES, value: v.vehicleType || 'Легковой' })}
      ${field('fuelType', 'Используемое топливо', { options: Object.fromEntries(Object.entries(FUELS).map(([k, f]) => [k, f.label])), value: v.fuelType || 'cng' })}
      ${field('equipmentType', 'Тип газобаллонного оборудования', { options: [['', '—'], ...EQUIPMENT.map((x) => [x, x])], value: v.equipmentType || '' })}
    </div>
    <fieldset class="f-cng"><legend>КПГ: баллоны</legend><div class="form-grid g3">
      ${field('cylinderCount', 'Количество баллонов', { type: 'number', min: 0, max: 40, value: v.cylinderCount })}
      ${field('cylinderVolumeL', 'Вместимость баллона, л', { type: 'number', min: 0, step: 'any', value: v.cylinderVolumeL, hint: 'геометрический (водяной) объём' })}
      ${field('workingPressureBar', 'Рабочее давление, бар', { type: 'number', min: 50, max: 350, value: v.workingPressureBar ?? 200 })}
    </div></fieldset>
    <fieldset class="f-lng"><legend>СПГ: криобак</legend><div class="form-grid">
      ${field('lngTankL', 'Объём криогенного бака, л', { type: 'number', min: 0, step: 'any', value: v.lngTankL, hint: 'запас будет пересчитан в кг' })}
    </div></fieldset>
    <fieldset class="f-gas"><legend>Запас газа</legend><div class="form-grid">
      <div class="field full">${checkbox('stockIsManual', 'Указать запас вручную вместо расчёта', v.stockIsManual)}</div>
      <div class="f-cng">${field('gasStockM3', 'Запас КПГ, м³', { type: 'number', min: 0, step: 'any', value: v.stockIsManual ? v.gasStockM3 : '' })}</div>
      <div class="f-lng">${field('gasStockKg', 'Запас СПГ, кг', { type: 'number', min: 0, step: 'any', value: v.stockIsManual ? v.gasStockKg : '' })}</div>
    </div></fieldset>
    <div class="form-grid">
      ${field('consumptionValue', 'Средний расход', { type: 'number', min: 0, step: 'any', value: v.consumptionValue, hint: 'м³/100 км для КПГ, кг/100 км для СПГ, л/100 км для остальных' })}
      ${field('monthlyMileageKm', 'Среднемесячный пробег, км', { type: 'number', min: 0, value: v.monthlyMileageKm })}
      ${field('payloadT', 'Грузоподъёмность, т', { type: 'number', min: 0, step: 'any', value: v.payloadT, hint: 'если применимо' })}
      ${scope === 'fleet' ? field('quantity', 'Количество одинаковых ТС', { type: 'number', min: 1, value: v.quantity || 1, hint: 'одна карточка может описывать группу одинаковых машин' }) : ''}
      <div class="field full">${checkbox('convertible', 'Можно перевести на метан (для бензиновых и дизельных ТС)', v.convertible)}</div>
      ${field('note', 'Примечание', { full: true, value: v.note })}
    </div>
    <div class="notice" id="calcPreview"></div>
    <div class="form-actions"><button class="btn primary" type="submit">Сохранить</button></div>
  </form>`;
}

function wireVehicleForm(form) {
  const sync = () => {
    const v = formValues(form);
    const methane = FUELS[v.fuelType]?.methane;
    $$('.f-cng', form).forEach((e) => e.classList.toggle('hidden', methane !== 'cng'));
    $$('.f-lng', form).forEach((e) => e.classList.toggle('hidden', methane !== 'lng'));
    $$('.f-gas', form).forEach((e) => e.classList.toggle('hidden', !methane));
    const m = vehicleMetrics({ fuel_type: v.fuelType, cylinder_count: v.cylinderCount, cylinder_volume_l: v.cylinderVolumeL, working_pressure_bar: v.workingPressureBar, lng_tank_l: v.lngTankL, stock_is_manual: v.stockIsManual, gas_stock_m3: v.gasStockM3, gas_stock_kg: v.gasStockKg, consumption_value: v.consumptionValue, monthly_mileage_km: v.monthlyMileageKm, quantity: v.quantity || 1 });
    $('#calcPreview', form).innerHTML = String(html`${icon('calc')}<p><b>Расчёт:</b> ${methane ? html`запас ${m.stockValue ? fmt(m.stockValue, 1) + ' ' + m.stockUnit : '—'}${methane === 'cng' && v.cylinderCount && v.cylinderVolumeL ? ` (геометрический объём ${fmt(v.cylinderCount * v.cylinderVolumeL)} л)` : ''}, запас хода ${m.rangeKm ? fmt(m.rangeKm) + ' км' : '—'}, потребность ${m.monthlyDemand ? fmt(m.monthlyDemand) + ' ' + m.demandUnit + ' в месяц' : '—'}.` : 'автомобиль не использует метан и учитывается как потенциал перевода.'}
      ${m.notes.length ? html`<br><span class="tiny">${m.notes.join(' ')}</span>` : ''}</p>`);
  };
  form.addEventListener('input', sync);
  sync();
}

async function vehiclesTab(pane, scope) {
  const data = await api.get(`/api/vehicles?scope=${scope}`);
  const canEdit = scope === 'personal' || ['owner', 'manager'].includes(state.user.organization?.role);
  const s = data.summary;
  pane.innerHTML = String(html`${head(scope === 'fleet' ? 'Мой автопарк' : 'Мои автомобили', scope === 'fleet' ? 'Карточки транспортных средств и сводные характеристики автопарка.' : 'Можно добавить несколько автомобилей. Запас газа считается в м³ (КПГ) или кг (СПГ), а не в литрах баллона.', canEdit ? html`<button class="btn primary" id="add">${icon('plus')} Добавить ${scope === 'fleet' ? 'ТС' : 'автомобиль'}</button>` : '')}
    ${scope === 'fleet' ? html`<div class="grid g4" style="margin-bottom:20px">
      <div class="kpi accent"><div class="v">${fmt(s.vehicles)}</div><div class="l">транспортных средств</div><div class="s">${s.cards} ${plural(s.cards, 'карточка', 'карточки', 'карточек')}</div></div>
      <div class="kpi"><div class="v">${fmt(s.demandM3)} м³</div><div class="l">потребность КПГ в месяц</div></div>
      <div class="kpi"><div class="v">${fmt(s.demandKg)} кг</div><div class="l">потребность СПГ в месяц</div></div>
      <div class="kpi"><div class="v">${fmt(s.convertible)}</div><div class="l">можно перевести на метан</div><div class="s">средний запас хода: ${s.avgRangeKm ? fmt(s.avgRangeKm) + ' км' : '—'}</div></div>
    </div>
    ${s.vehicles ? html`<div class="grid g2" style="margin-bottom:20px"><div class="card pad"><h3>По виду топлива</h3>${bars(Object.entries(s.byFuel).map(([k, n]) => ({ label: FUELS[k]?.short || k, value: n })), { unit: 'ТС' })}</div><div class="card pad"><h3>По типу ТС</h3>${bars(Object.entries(s.byType).map(([k, n]) => ({ label: k, value: n })), { unit: 'ТС' })}</div></div>` : ''}` : ''}
    <div class="grid g2" id="list">${data.items.map((v) => vehicleCard(v, canEdit))}</div>
    ${!data.items.length ? html`<div class="empty"><h3>Пока нет транспорта</h3><p>Добавьте автомобиль, чтобы платформа рассчитала потребность в газе и запас хода.</p></div>` : ''}`);
  const open = (v) => {
    const m = modal({ title: v ? 'Изменить автомобиль' : 'Новый автомобиль', body: vehicleForm(v || {}, scope), wide: true });
    const form = $('#vf', m.root);
    wireVehicleForm(form);
    bindForm(form, async (val) => {
      if (v) await api.put(`/api/vehicles/${v.id}`, val); else await api.post('/api/vehicles', { ...val, scope });
      m.close(); toast('Сохранено в базе данных', 'ok'); vehiclesTab(pane, scope);
    });
  };
  $('#add') && ($('#add').onclick = () => open(null));
  $$('[data-edit]').forEach((b) => (b.onclick = () => open(data.items.find((x) => x.id === b.dataset.edit))));
  $$('[data-del]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Удалить автомобиль? Связанные маршруты сохранятся без привязки.', { danger: true, ok: 'Удалить' })) { await api.del(`/api/vehicles/${b.dataset.del}`).catch(showError); vehiclesTab(pane, scope); } }));
}

// ---------- Маршруты ----------
async function routesTab(pane) {
  await loadCities().catch(() => {});
  const biz = isBusiness();
  const [routes, veh, fleet] = await Promise.all([api.get(`/api/my-routes${biz ? '?scope=org' : ''}`), api.get('/api/vehicles'), biz ? api.get('/api/vehicles?scope=fleet') : { items: [] }]);
  const vehicles = [...veh.items, ...fleet.items];
  const canEdit = !biz || ['owner', 'manager'].includes(state.user.organization?.role);
  pane.innerHTML = String(html`${head(biz ? 'Наши маршруты' : 'Мои маршруты', 'Регулярные поездки сохраняются в базе и используются для поиска участков, где нужны станции. Пример: «Хабаровск — Комсомольск-на-Амуре, 4 раза в месяц».', canEdit ? html`<button class="btn primary" id="add">${icon('plus')} Добавить маршрут</button>` : '')}
    <div class="card" style="overflow:hidden;margin-bottom:20px"><div id="rmap" class="leaflet-host" style="height:340px"></div></div>
    <div class="grid g2">${routes.items.map((r) => html`<div class="card pad">
      <div style="display:flex;justify-content:space-between;gap:10px"><h3 style="margin:0">${r.originName} → ${r.destName}</h3>${demoBadge(r.isDemo)}</div>
      ${r.waypoints.length ? html`<div class="small muted">через ${r.waypoints.map((w) => w.name).join(', ')}</div>` : ''}
      <div class="specs vehicle" style="margin-top:12px"><div class="specs">
        <div class="spec"><b>${fmt(r.distanceKm)} км</b><span>${r.distanceSource === 'osrm' ? 'по дорогам' : r.distanceSource === 'user' ? 'указано вручную' : 'оценка (демо)'}</span></div>
        <div class="spec"><b>${fmt(r.tripsPerMonth, 1)}</b><span>поездок в месяц</span></div>
        <div class="spec"><b>${fmt(r.monthlyKm)} км</b><span>в месяц</span></div></div></div>
      <div class="dl" style="margin-top:10px"><div>Причина поездок</div><div>${r.purpose || '—'}</div><div>Автомобиль</div><div>${r.vehicle || '—'}</div><div>Остановки</div><div>${r.preferredStops || '—'}</div><div>Альтернативы</div><div>${r.alternatives || '—'}</div><div>Проблемы с заправками</div><div>${r.stationIssues || '—'}</div></div>
      <div class="form-actions" style="margin-top:12px"><a class="btn sm" href="/routes?fromName=${encodeURIComponent(r.originName)}&toName=${encodeURIComponent(r.destName)}&toLat=${r.destLat}&toLng=${r.destLng}">${icon('route', 14)} Проверить заправки</a>${canEdit ? html`<button class="btn sm" data-edit="${r.id}">${icon('edit', 14)}</button><button class="btn sm danger" data-del="${r.id}">${icon('trash', 14)}</button>` : ''}</div>
    </div>`)}</div>
    ${!routes.items.length ? html`<div class="empty"><h3>Маршрутов пока нет</h3><p>Укажите регулярные поездки — мы сообщим, когда на них появятся новые станции.</p></div>` : ''}
    ${cityDatalist()}`);
  const L = await leaflet();
  const m = await createMap($('#rmap'), { zoom: 3, scrollWheelZoom: false });
  const group = L.featureGroup().addTo(m);
  routes.items.forEach((r) => r.geometry && L.polyline(r.geometry, { color: '#e7aa44', weight: 4 }).bindTooltip(`${r.originName} — ${r.destName}`).addTo(group));
  if (routes.items.length) m.fitBounds(group.getBounds(), { padding: [30, 30] });
  const open = (r) => {
    const md = modal({ title: r ? 'Изменить маршрут' : 'Новый регулярный маршрут', wide: true, body: html`<form class="form" id="rf"><div class="form-grid">
      ${field('originName', 'Город отправления', { required: true, list: 'cities', value: r?.originName })}
      ${field('destName', 'Город назначения', { required: true, list: 'cities', value: r?.destName })}
      ${field('waypointsText', 'Промежуточные пункты', { full: true, value: r?.waypoints.map((w) => w.name).join(', '), hint: 'через запятую, из списка городов' })}
      ${field('tripsPerMonth', 'Частота поездок в месяц', { type: 'number', min: 0.1, step: 'any', required: true, value: r?.tripsPerMonth ?? 4 })}
      ${field('distanceKm', 'Расстояние, км', { type: 'number', min: 1, value: r?.distanceSource === 'user' ? r.distanceKm : '', hint: 'оставьте пустым — рассчитаем автоматически' })}
      ${field('purpose', 'Причина поездок', { options: ['Работа / командировки', 'Личные поездки', 'Грузовые перевозки', 'Пассажирские перевозки', 'Доставка', 'Такси', 'Другое'], value: r?.purpose })}
      ${field('vehicleId', 'Используемый автомобиль', { options: [['', '— не указан —'], ...vehicles.map((v) => [v.id, `${v.make} ${v.model}${v.quantity > 1 ? ' ×' + v.quantity : ''}`])], value: r?.vehicleId || '' })}
      ${field('preferredStops', 'Предпочтительные места остановок', { full: true, value: r?.preferredStops })}
      ${field('alternatives', 'Альтернативные маршруты', { full: true, value: r?.alternatives })}
      ${field('stationIssues', 'Проблемы с существующими заправками', { type: 'textarea', full: true, value: r?.stationIssues })}
    </div><div class="form-actions"><button class="btn primary" type="submit">Сохранить маршрут</button></div></form>${cityDatalist()}` });
    bindForm($('#rf', md.root), async (v) => {
      const body = { ...v, waypoints: (v.waypointsText || '').split(',').map((x) => x.trim()).filter(Boolean).map((name) => ({ name })), scope: biz ? 'org' : 'personal' };
      delete body.waypointsText;
      if (r) await api.put(`/api/my-routes/${r.id}`, body); else await api.post('/api/my-routes', body);
      md.close(); toast('Маршрут сохранён', 'ok'); routesTab(pane);
    });
  };
  $('#add') && ($('#add').onclick = () => open(null));
  $$('[data-edit]').forEach((b) => (b.onclick = () => open(routes.items.find((x) => x.id === b.dataset.edit))));
  $$('[data-del]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Удалить маршрут?', { danger: true, ok: 'Удалить' })) { await api.del(`/api/my-routes/${b.dataset.del}`).catch(showError); routesTab(pane); } }));
}

// ---------- Компания ----------
async function company(pane) {
  const [me, mem] = await Promise.all([api.get('/api/me'), api.get('/api/me/organization/members')]);
  const o = me.organization;
  const canEdit = ['owner', 'manager'].includes(me.memberRole);
  const ip = o.type === 'ip';
  pane.innerHTML = String(html`${head(ip ? 'Мой бизнес' : 'Моя компания', `${o.fullName} · ИНН ${o.inn}`, html`${statusBadge(o.verificationStatus, LABELS.verification[o.verificationStatus])}${demoBadge(o.isDemo)}`)}
    <form class="card pad form" id="of"><h3>Реквизиты и деятельность</h3><div class="form-grid">
      ${field('fullName', ip ? 'ФИО предпринимателя / наименование' : 'Полное наименование', { required: true, value: o.fullName, full: true })}
      ${field('shortName', 'Краткое наименование', { value: o.shortName })}
      ${!ip ? field('legalForm', 'Организационно-правовая форма', { value: o.legalForm }) : ''}
      <div class="field"><label>ИНН</label><input value="${o.inn}" disabled><div class="hint">ИНН меняется только через поддержку оператора</div></div>
      ${field('region', 'Регион ведения деятельности', { value: o.region, list: 'regions' })}
      ${!ip ? field('legalAddress', 'Юридический адрес', { value: o.legalAddress, full: true }) : ''}
      ${field('activity', 'Вид деятельности', { value: o.activity })}
      ${field('employees', 'Количество сотрудников', { type: 'number', min: 0, value: o.employees })}
      ${field('fleetSize', 'Размер автопарка (ТС)', { type: 'number', min: 0, value: o.fleetSize })}
      ${field('vehicleTypes', 'Типы автомобилей', { value: o.vehicleTypes })}
      ${field('tripFrequency', 'Частота коммерческих поездок', { value: o.tripFrequency })}
      ${field('transportDirections', 'Основные направления перевозок', { type: 'textarea', full: true, value: o.transportDirections })}
      ${field('estMonthlyGas', 'Предполагаемый объём потребления газа в месяц', { type: 'number', min: 0, value: o.estMonthlyGas })}
      ${field('estMonthlyGasUnit', 'Единица', { options: { 'м³': 'м³ (КПГ)', 'кг': 'кг (СПГ)' }, value: o.estMonthlyGasUnit || 'м³' })}
      ${field('contactPerson', 'Контактное лицо', { value: o.contactPerson })}
      ${field('contactPosition', 'Должность представителя', { value: o.contactPosition })}
      ${field('contactEmail', 'E-mail организации', { type: 'email', value: o.contactEmail })}
      ${field('contactPhone', 'Телефон организации', { type: 'tel', value: o.contactPhone })}
    </div>${canEdit ? html`<div class="form-actions"><button class="btn primary" type="submit">Сохранить</button><span class="tiny muted">Изменение наименования отправит организацию на повторную проверку.</span></div>` : html`<p class="tiny muted">У вас права только на просмотр.</p>`}</form>
    <div class="card pad" style="margin-top:22px"><h3>Уполномоченные сотрудники</h3><p class="small muted">Владелец управляет доступом: «Менеджер» может редактировать автопарк, маршруты и заявки, «Наблюдатель» — только просматривать.</p>
      <div class="table-wrap"><table class="table"><thead><tr><th>Сотрудник</th><th>E-mail</th><th>Права</th><th>С</th><th></th></tr></thead><tbody>
      ${mem.members.map((x) => html`<tr><td>${x.name || '—'}${x.me ? ' (вы)' : ''}<div class="tiny muted">${x.position || ''}</div></td><td>${x.email}</td><td>${mem.myRole === 'owner' && x.role !== 'owner' ? html`<select class="select" data-role="${x.userId}" style="width:auto"><option value="manager" ${x.role === 'manager' ? 'selected' : ''}>Менеджер</option><option value="viewer" ${x.role === 'viewer' ? 'selected' : ''}>Наблюдатель</option></select>` : LABELS.member[x.role]}</td><td>${date(x.since)}</td><td>${mem.myRole === 'owner' && x.role !== 'owner' ? html`<button class="btn sm danger" data-rm="${x.userId}">Исключить</button>` : ''}</td></tr>`)}
      ${mem.invites.map((x) => html`<tr><td class="muted">Приглашение отправлено</td><td>${x.email}</td><td>${LABELS.member[x.member_role]}</td><td>до ${date(x.expires_at)}</td><td><button class="btn sm" data-inv="${x.id}">Отозвать</button></td></tr>`)}
      </tbody></table></div>
      ${mem.myRole === 'owner' ? html`<form class="form-grid" id="inv" style="margin-top:16px;align-items:end">${field('email', 'E-mail сотрудника', { type: 'email', required: true })}${field('role', 'Права', { options: { manager: 'Менеджер (редактирование)', viewer: 'Наблюдатель (просмотр)' } })}<div class="form-actions full"><button class="btn primary" type="submit">${icon('people')} Пригласить сотрудника</button></div></form>` : ''}
    </div>${regionDatalist()}`);
  if (canEdit) bindForm($('#of'), async (v) => { const r = await api.put('/api/me/organization', v); toast(r.message, 'ok'); company(pane); });
  else $$('#of input, #of select, #of textarea').forEach((e) => (e.disabled = true));
  if ($('#inv')) bindForm($('#inv'), async (v) => { const r = await api.post('/api/me/organization/members', v); toast(r.message, 'ok', 6000); company(pane); });
  $$('[data-role]').forEach((s) => (s.onchange = async () => { try { await api.put(`/api/me/organization/members/${s.dataset.role}`, { role: s.value }); toast('Права обновлены', 'ok'); } catch (e) { showError(e); } }));
  $$('[data-rm]').forEach((b) => (b.onclick = async () => { if (await confirmDialog('Исключить сотрудника из организации? Его сеансы будут завершены.', { danger: true, ok: 'Исключить' })) { await api.del(`/api/me/organization/members/${b.dataset.rm}`).catch(showError); company(pane); } }));
  $$('[data-inv]').forEach((b) => (b.onclick = async () => { await api.del(`/api/me/organization/invites/${b.dataset.inv}`).catch(showError); company(pane); }));
}

// ---------- Потребность в газе ----------
async function demand(pane) {
  const [fleet, routes, me] = await Promise.all([api.get('/api/vehicles?scope=fleet'), api.get('/api/my-routes?scope=org'), api.get('/api/me')]);
  const s = fleet.summary;
  const o = me.organization;
  const routeKm = routes.items.reduce((a, r) => a + (r.monthlyKm || 0), 0);
  pane.innerHTML = String(html`${head('Потребность в газе', 'Расчёт по зарегистрированному автопарку: пробег × расход × количество ТС. Каждый автомобиль учитывается один раз.')}
    <div class="grid g3">
      <div class="tier t2"><div class="lvl">Расчётный спрос · КПГ</div><div class="big">${fmt(s.demandM3)} м³/мес.</div><div class="small muted">≈ ${fmt(s.demandM3 * 12)} м³ в год</div></div>
      <div class="tier t2"><div class="lvl">Расчётный спрос · СПГ</div><div class="big">${fmt(s.demandKg)} кг/мес.</div><div class="small muted">≈ ${fmt((s.demandKg * 12) / 1000, 1)} т в год</div></div>
      <div class="tier t1"><div class="lvl">Заявлено организацией</div><div class="big">${o.estMonthlyGas ? fmt(o.estMonthlyGas) + ' ' + (o.estMonthlyGasUnit || 'м³') : '—'}</div><div class="small muted">из раздела «Моя компания»</div></div>
    </div>
    <div class="grid g2" style="margin-top:20px">
      <div class="card pad"><h3>Исходные данные</h3><div class="dl">
        <div>Транспортных средств</div><div>${fmt(s.vehicles)}</div><div>Суммарный пробег в месяц</div><div>${fmt(s.monthlyKm)} км</div>
        <div>Пробег по заявленным маршрутам</div><div>${fmt(routeKm)} км/мес. (${routes.items.length} ${plural(routes.items.length, 'маршрут', 'маршрута', 'маршрутов')})</div>
        <div>ТС, которые можно перевести на метан</div><div>${fmt(s.convertible)}</div><div>Средний запас хода</div><div>${s.avgRangeKm ? fmt(s.avgRangeKm) + ' км' : '—'}</div></div>
        <p class="tiny muted" style="margin-top:10px">Пробег по маршрутам не суммируется с пробегом автомобилей, чтобы не учитывать одни и те же километры дважды.</p></div>
      <div class="card pad"><h3>Что дальше</h3><p class="small muted">Расчётный спрос помогает оператору оценить перспективные участки. Чтобы спрос стал договорным, направьте коммерческое предложение — оператор рассмотрит его и зафиксирует договорённость.</p>
        <div class="form-actions"><a class="btn primary" href="/account/offers/new">${icon('doc')} Предложить договор сотрудничества</a><a class="btn" href="/savings">Калькулятор экономии</a></div></div>
    </div>`);
}

// ---------- Коммерческие предложения ----------
async function offersTab(pane, ctx) {
  const id = ctx.params.id;
  if (id === 'new') return offerForm(pane, null);
  if (id) return offerDetail(pane, id);
  const data = await api.get('/api/offers');
  const canEdit = ['owner', 'manager'].includes(state.user.organization?.role);
  pane.innerHTML = String(html`${head('Договоры и заявки', 'Коммерческие предложения о сотрудничестве по поставке газомоторного топлива и история их рассмотрения.', canEdit ? html`<a class="btn primary" href="/account/offers/new">${icon('plus')} Предложить договор сотрудничества</a>` : '')}
    <div class="notice warn" style="margin-bottom:18px">${icon('info')}<p>Предложение — это заявка, а не юридически обязывающий договор. Подписание договора проходит отдельно после проверки контрагента и согласования условий.</p></div>
    ${data.items.length ? html`<div class="table-wrap"><table class="table"><thead><tr><th>Предложение</th><th>Статус</th><th class="num">Объём</th><th class="num">Срок</th><th>Обновлено</th></tr></thead><tbody>
      ${data.items.map((o) => html`<tr style="cursor:pointer" data-open="${o.id}"><td><a href="/account/offers/${o.id}"><b>${o.title}</b></a> ${demoBadge(o.isDemo)}</td><td>${statusBadge(o.status, o.statusLabel)}</td><td class="num">${o.monthlyVolume ? fmt(o.monthlyVolume) + ' ' + o.volumeUnit + '/мес.' : '—'}</td><td class="num">${o.termMonths ? o.termMonths + ' мес.' : '—'}</td><td>${dateTime(o.updatedAt)}</td></tr>`)}
    </tbody></table></div>` : html`<div class="empty"><h3>Предложений пока нет</h3><p>Расскажите об автопарке, маршрутах и потребности в газе — оператор рассмотрит возможность долгосрочного сотрудничества.</p>${canEdit ? html`<a class="btn primary" href="/account/offers/new">Создать предложение</a>` : ''}</div>`}`);
}

function offerFormHtml(o = {}) {
  const f = (n, l, opt = {}) => field(n, l, { value: o[n], ...opt });
  return html`<form class="form" id="off" novalidate>
    <fieldset><legend>1. Информация об организации</legend><div class="form-grid">
      ${f('orgName', 'Наименование', { required: true })}${f('orgInn', 'ИНН', { attrs: 'readonly' })}${f('orgRegion', 'Регион', { list: 'regions' })}${f('representative', 'Представитель', { required: true })}
      ${f('contactEmail', 'E-mail', { type: 'email', required: true })}${f('contactPhone', 'Телефон', { type: 'tel' })}${f('activity', 'Вид деятельности', { full: true })}</div></fieldset>
    <fieldset><legend>2. Транспортный парк</legend><div class="form-grid">
      ${f('vehiclesTotal', 'Количество автомобилей', { type: 'number', min: 0, required: true })}${f('vehiclesConvertible', 'Можно перевести на метан', { type: 'number', min: 0 })}
      ${f('makesModels', 'Марки и модели', { type: 'textarea', full: true })}${f('fuelTypesNow', 'Используемые типы топлива')}${f('avgMileageKm', 'Средний пробег, км/мес.', { type: 'number', min: 0 })}
      ${f('conversionTimeline', 'Планируемые сроки перевода', { full: true })}</div></fieldset>
    <fieldset><legend>3. Маршруты перевозок</legend><div class="form-grid">
      ${f('mainDirections', 'Основные транспортные направления', { type: 'textarea', full: true, required: true })}${f('tripFrequency', 'Частота перевозок', { required: true })}${f('avgDistanceKm', 'Среднее расстояние, км', { type: 'number', min: 0 })}
      ${f('alternativePaths', 'Альтернативные пути', { type: 'textarea' })}${f('seasonalLimits', 'Сезонные ограничения', { type: 'textarea' })}
      ${f('weightLimits', 'Ограничения по массе и габаритам', { type: 'textarea' })}${f('unavailableSections', 'Недоступные участки дорог', { type: 'textarea' })}
      ${f('mandatoryStops', 'Места обязательных остановок', { type: 'textarea' })}${f('underservedAreas', 'Территории с недостаточной заправочной инфраструктурой', { type: 'textarea' })}</div></fieldset>
    <fieldset><legend>4. Потребность в газомоторном топливе</legend><div class="form-grid g3">
      ${field('fuelType', 'Вид топлива', { options: { cng: 'КПГ', lng: 'СПГ' }, value: o.fuelType || 'cng', required: true })}
      ${field('volumeUnit', 'Единица объёма', { options: { 'м³': 'м³ (КПГ)', 'кг': 'кг (СПГ)', 'т': 'т (СПГ)' }, value: o.volumeUnit || 'м³' })}
      ${f('monthlyVolume', 'Среднемесячный объём', { type: 'number', min: 0, step: 'any', required: true })}
      ${f('annualVolume', 'Предполагаемый годовой объём', { type: 'number', min: 0, step: 'any', hint: 'по умолчанию — месячный × 12' })}
      ${f('termMonths', 'Планируемый срок сотрудничества, мес.', { type: 'number', min: 1, max: 240, required: true })}
      ${f('minGuaranteedVolume', 'Минимальный гарантируемый объём в месяц', { type: 'number', min: 0, step: 'any', hint: 'если готовы принять обязательство' })}
      ${f('deliveryTerms', 'Предпочтительные условия поставки', { type: 'textarea', full: true })}</div></fieldset>
    <fieldset><legend>5. Дополнительные сведения</legend><div class="form-grid">
      ${f('restrictions', 'Возможные ограничения', { type: 'textarea' })}${f('locationWishes', 'Пожелания к расположению заправок', { type: 'textarea' })}
      ${f('specialRequirements', 'Особые требования', { type: 'textarea' })}${f('comments', 'Комментарии', { type: 'textarea' })}</div>
      <p class="tiny muted">Сопроводительные документы (PDF, DOCX, XLSX, JPG, PNG до ${state.meta?.maxUploadMb || 10} МБ) можно приложить после сохранения черновика.</p></fieldset>
    <div class="form-actions"><button class="btn" type="submit" name="act" value="save">Сохранить черновик</button><button class="btn primary" type="submit" name="act" value="submit">${icon('arrow')} Сохранить и отправить оператору</button></div>
  </form>`;
}

async function offerForm(pane, existing) {
  const pre = existing || (await api.get('/api/offers/prefill'));
  pane.innerHTML = String(html`${head(existing ? 'Редактирование предложения' : 'Предложить сотрудничество по поставке газомоторного топлива', 'Заполните разделы — обязательные поля отмечены звёздочкой. Данные сохраняются как черновик до отправки.', html`<a class="btn ghost" href="/account/offers">← К списку</a>`)}
    <div class="notice warn" style="margin-bottom:18px">${icon('info')}<p>Платформа не создаёт юридически обязывающий договор. Отправленное предложение рассматривает оператор; при необходимости он запросит уточнения.</p></div>
    <div class="card pad">${offerFormHtml(pre)}</div>${regionDatalist()}`);
  const form = $('#off');
  const syncUnit = () => { const u = form.volumeUnit; if (form.fuelType.value === 'cng') { u.value = 'м³'; u.disabled = true; } else { u.disabled = false; if (u.value === 'м³') u.value = 'кг'; } };
  form.fuelType.addEventListener('change', syncUnit);
  syncUnit();
  bindForm(form, async (v, _f, submitter) => {
    const act = submitter?.value || 'save';
    delete v.act;
    if (form.volumeUnit.disabled) v.volumeUnit = 'м³';
    let id = existing?.id;
    if (id) await api.put(`/api/offers/${id}`, v); else id = (await api.post('/api/offers', v)).id;
    if (act === 'submit') { const r = await api.post(`/api/offers/${id}/submit`); toast(r.message, 'ok', 6000); }
    else toast('Черновик сохранён', 'ok');
    go(`/account/offers/${id}`);
  });
}

async function offerDetail(pane, id) {
  const o = (await api.get(`/api/offers/${id}`)).item;
  const canEdit = ['owner', 'manager'].includes(state.user.organization?.role);
  if (o.editable && canEdit && new URLSearchParams(location.search).get('edit') === '1') return offerForm(pane, o);
  const d = (l, v) => html`<div>${l}</div><div style="white-space:pre-wrap">${v === null || v === undefined || v === '' ? '—' : v}</div>`;
  pane.innerHTML = String(html`${head(o.title, `Создано ${dateTime(o.createdAt)}${o.submittedAt ? ' · отправлено ' + dateTime(o.submittedAt) : ''}`, html`${statusBadge(o.status, o.statusLabel)}${demoBadge(o.isDemo)}`)}
    ${o.status === 'needs_info' ? html`<div class="notice warn" style="margin-bottom:18px">${icon('warn')}<p>Оператор запросил уточнения. Отредактируйте предложение и отправьте его повторно.</p></div>` : ''}
    ${o.status === 'preliminarily_approved' ? html`<div class="notice ok" style="margin-bottom:18px">${icon('check')}<p>Условия предварительно согласованы. Это не подписанный договор: дальнейшие шаги оператор согласует с вами отдельно.</p></div>` : ''}
    <div class="form-actions" style="margin-bottom:18px">${o.editable && canEdit ? html`<a class="btn" href="/account/offers/${o.id}?edit=1">${icon('edit')} Редактировать</a><button class="btn primary" id="sub">${icon('arrow')} Отправить оператору</button>` : ''}${o.status === 'draft' && canEdit ? html`<button class="btn danger" id="delOffer">${icon('trash')} Удалить черновик</button>` : ''}<a class="btn ghost" href="/account/offers">← К списку</a></div>
    <div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:22px" id="og">
      <div class="grid" style="gap:18px">
        <div class="card pad"><h3>Потребность в топливе</h3><div class="grid g3" style="gap:10px;margin-bottom:12px">
          <div class="kpi accent"><div class="v">${fmt(o.monthlyVolume)} ${o.volumeUnit}</div><div class="l">в месяц (${o.fuelType === 'lng' ? 'СПГ' : 'КПГ'})</div></div>
          <div class="kpi"><div class="v">${fmt(o.annualVolume)} ${o.volumeUnit}</div><div class="l">в год</div></div>
          <div class="kpi"><div class="v">${o.termMonths ? o.termMonths + ' мес.' : '—'}</div><div class="l">срок сотрудничества</div></div></div>
          <div class="dl">${d('Минимальный гарантируемый объём', o.minGuaranteedVolume ? `${fmt(o.minGuaranteedVolume)} ${o.volumeUnit}/мес.` : null)}${d('Условия поставки', o.deliveryTerms)}</div></div>
        <div class="card pad"><h3>Организация</h3><div class="dl">${d('Наименование', o.orgName)}${d('ИНН', o.orgInn)}${d('Регион', o.orgRegion)}${d('Представитель', o.representative)}${d('Контакты', [o.contactEmail, o.contactPhone].filter(Boolean).join(', '))}${d('Вид деятельности', o.activity)}</div></div>
        <div class="card pad"><h3>Транспортный парк</h3><div class="dl">${d('Количество автомобилей', fmt(o.vehiclesTotal))}${d('Можно перевести на метан', fmt(o.vehiclesConvertible))}${d('Марки и модели', o.makesModels)}${d('Типы топлива', o.fuelTypesNow)}${d('Средний пробег', o.avgMileageKm ? fmt(o.avgMileageKm) + ' км/мес.' : null)}${d('Сроки перевода', o.conversionTimeline)}</div></div>
        <div class="card pad"><h3>Маршруты перевозок</h3><div class="dl">${d('Направления', o.mainDirections)}${d('Частота', o.tripFrequency)}${d('Среднее расстояние', o.avgDistanceKm ? fmt(o.avgDistanceKm) + ' км' : null)}${d('Альтернативные пути', o.alternativePaths)}${d('Сезонные ограничения', o.seasonalLimits)}${d('Ограничения по массе и габаритам', o.weightLimits)}${d('Недоступные участки', o.unavailableSections)}${d('Обязательные остановки', o.mandatoryStops)}${d('Территории без инфраструктуры', o.underservedAreas)}</div></div>
        <div class="card pad"><h3>Дополнительно</h3><div class="dl">${d('Ограничения', o.restrictions)}${d('Пожелания к расположению заправок', o.locationWishes)}${d('Особые требования', o.specialRequirements)}${d('Комментарии', o.comments)}</div></div>
      </div>
      <aside class="grid" style="gap:18px;align-content:start">
        <div class="card pad"><h3>История статусов</h3><div class="timeline">${o.history.map((h) => html`<div class="tl"><div class="when">${dateTime(h.at)}</div><b>${h.toLabel}</b>${h.comment ? html`<div class="small muted">${h.comment}</div>` : ''}</div>`)}</div></div>
        <div class="card pad"><h3>Переписка с оператором</h3><div class="grid" style="gap:10px">${o.messages.map((m) => html`<div class="msg ${m.side === 'operator' ? 'op' : ''}"><div class="who">${m.author} · ${dateTime(m.at)}</div><div style="white-space:pre-wrap">${m.body}</div></div>`)}${!o.messages.length ? html`<p class="small muted">Сообщений нет.</p>` : ''}</div>
          ${canEdit ? html`<form id="mf" class="form" style="margin-top:12px">${field('body', 'Сообщение оператору', { type: 'textarea', required: true })}<button class="btn sm" type="submit">Отправить</button></form>` : ''}</div>
        <div class="card pad"><h3>Документы</h3>${o.documents.map((x) => html`<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)"><a href="/api/documents/${x.id}" download>${icon('doc', 15)} ${x.name}</a><span class="tiny muted nowrap">${fmt(x.size / 1024)} КБ ${o.editable && canEdit ? html`<button class="linkbtn" data-deldoc="${x.id}">удалить</button>` : ''}</span></div>`)}
          ${!o.documents.length ? html`<p class="small muted">Документы не приложены.</p>` : ''}
          ${canEdit && ['draft', 'needs_info', 'submitted', 'in_review'].includes(o.status) ? html`<label class="btn sm" style="margin-top:12px">${icon('plus', 14)} Приложить файл<input type="file" id="docInput" accept=".pdf,.docx,.xlsx,.png,.jpg,.jpeg" hidden></label>` : ''}</div>
      </aside>
    </div>`);
  if (matchMedia('(max-width: 1000px)').matches) $('#og').style.gridTemplateColumns = '1fr';
  $('#sub') && ($('#sub').onclick = async () => { try { const r = await api.post(`/api/offers/${o.id}/submit`); toast(r.message, 'ok', 6000); offerDetail(pane, id); } catch (e) { showError(e); } });
  $('#delOffer') && ($('#delOffer').onclick = async () => { if (await confirmDialog('Удалить черновик?', { danger: true, ok: 'Удалить' })) { await api.del(`/api/offers/${o.id}`); go('/account/offers'); } });
  if ($('#mf')) bindForm($('#mf'), async (v) => { await api.post(`/api/offers/${o.id}/messages`, v); toast('Сообщение отправлено', 'ok'); offerDetail(pane, id); });
  $$('[data-deldoc]').forEach((b) => (b.onclick = async () => { await api.del(`/api/documents/${b.dataset.deldoc}`).catch(showError); offerDetail(pane, id); }));
  $('#docInput')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const max = (state.meta?.maxUploadMb || 10) * 1024 * 1024;
    if (file.size > max) { toast('Файл слишком большой', 'error'); return; }
    const mime = file.type || ({ pdf: 'application/pdf', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg' })[file.name.split('.').pop().toLowerCase()];
    const buf = new Uint8Array(await file.arrayBuffer());
    let bin = '';
    for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    try { await api.post(`/api/offers/${o.id}/documents`, { name: file.name, mime, dataBase64: btoa(bin) }); toast('Документ загружен', 'ok'); offerDetail(pane, id); } catch (err) { showError(err); }
  });
}

async function contracts(pane) {
  const data = await api.get('/api/contracts');
  pane.innerHTML = String(html`${head('Договорённости', 'Договорённости, зафиксированные оператором по итогам рассмотрения предложений (уровень «договорной спрос»).')}
    ${data.items.length ? html`<div class="grid g2">${data.items.map((c) => html`<div class="card pad"><div style="display:flex;justify-content:space-between;gap:10px">${statusBadge(c.status, c.statusLabel)}${demoBadge(c.isDemo)}</div>
      <h3 style="margin:12px 0">${fmt(c.contractedMonthlyVolume)} ${c.volumeUnit}/мес. · ${c.fuelType === 'lng' ? 'СПГ' : 'КПГ'}</h3>
      <div class="dl"><div>Регион</div><div>${c.region || '—'}</div><div>Начало</div><div>${c.startDate ? date(c.startDate) : '—'}</div><div>Срок</div><div>${c.termMonths ? c.termMonths + ' мес.' : '—'}</div><div>Примечание</div><div>${c.note || '—'}</div></div>
      ${c.offerId ? html`<a class="btn sm" href="/account/offers/${c.offerId}" style="margin-top:12px">Связанное предложение →</a>` : ''}</div>`)}</div>`
      : html`<div class="empty"><h3>Договорённостей пока нет</h3><p>Они появятся после рассмотрения ваших предложений оператором.</p></div>`}
    <div class="notice" style="margin-top:18px">${icon('info')}<p>Юридически значимое подписание договора выполняется вне платформы по отдельной согласованной процедуре.</p></div>`);
}

async function proposals(pane) {
  const data = await api.get('/api/proposals?mine=1');
  pane.innerHTML = String(html`${head(isBusiness() ? 'Предложения по строительству станций' : 'Мои инициативы', 'Инициативы, которые вы предложили, и их статус рассмотрения.', html`<a class="btn primary" href="/vote/new">${icon('plus')} Предложить станцию</a>`)}
    ${data.items.length ? html`<div class="table-wrap"><table class="table"><thead><tr><th>Инициатива</th><th>Статус</th><th class="num">Голоса</th><th>Создана</th></tr></thead><tbody>${data.items.map((p) => html`<tr><td><a href="/vote/${p.id}"><b>${p.title}</b></a> ${demoBadge(p.isDemo)}${p.moderationNote ? html`<div class="tiny muted">Модератор: ${p.moderationNote}</div>` : ''}</td><td>${statusBadge(p.status, p.statusLabel)}</td><td class="num">${fmt(p.votes)}</td><td>${date(p.createdAt)}</td></tr>`)}</tbody></table></div>`
      : html`<div class="empty"><h3>Вы ещё не предлагали станций</h3><p>Отметьте на карте участок, где не хватает заправки.</p></div>`}`);
}

async function favorites(pane) {
  const f = await api.get('/api/favorites');
  const block = (title, items, render) => html`<div class="card pad"><h3>${title}</h3>${items.length ? items.map(render) : html`<p class="small muted">Пусто</p>`}</div>`;
  pane.innerHTML = String(html`${head('Избранное', 'Подписки на станции, инициативы и маршруты. Вы получаете уведомления об изменении их статуса и сроков.')}
    <div class="grid g3">
      ${block('Станции и проекты', f.stations, (s) => html`<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)"><a href="/map?station=${s.id}">${s.name}</a><button class="linkbtn tiny" data-unfav="station:${s.id}">убрать</button></div>`)}
      ${block('Инициативы', f.proposals, (p) => html`<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)"><a href="/vote/${p.id}">${p.title}</a><button class="linkbtn tiny" data-unfav="proposal:${p.id}">убрать</button></div>`)}
      ${block('Маршруты', f.routes, (r) => html`<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line)"><a href="/account/routes">${r.name}</a><button class="linkbtn tiny" data-unfav="route:${r.id}">убрать</button></div>`)}
    </div>`);
  $$('[data-unfav]').forEach((b) => (b.onclick = async () => { const [t, id] = b.dataset.unfav.split(':'); await api.del(`/api/favorites/${t}/${id}`).catch(showError); favorites(pane); }));
}

async function notifications(pane) {
  const data = await api.get('/api/notifications');
  pane.innerHTML = String(html`${head('Уведомления', 'Новые статусы предложений, объекты на ваших маршрутах, ответы оператора и изменения сроков строительства.', data.items.some((n) => !n.read) ? html`<button class="btn" id="readAll">${icon('check')} Отметить все прочитанными</button>` : '')}
    <div class="grid" style="gap:10px">${data.items.map((n) => html`<a class="card pad" href="${n.link || '#'}" data-n="${n.id}" style="display:block;color:#fff;padding:16px 20px;${n.read ? 'opacity:.72' : 'border-color:rgba(71,200,245,.45)'}">
      <div class="tiny muted">${dateTime(n.createdAt)} ${n.read ? '' : html`<span class="badge info plain">новое</span>`}</div><div style="font-weight:600;margin-top:4px">${n.title}</div>${n.body ? html`<div class="small muted" style="margin-top:4px">${n.body}</div>` : ''}</a>`)}
    ${!data.items.length ? html`<div class="empty"><h3>Уведомлений нет</h3><p>Добавьте маршруты и подпишитесь на объекты, чтобы узнавать о новых станциях.</p></div>` : ''}</div>`);
  $('#readAll') && ($('#readAll').onclick = async () => { await api.post('/api/notifications/read', { all: true }); await refreshSession(); notifications(pane); });
  $$('[data-n]').forEach((a) => a.addEventListener('click', () => { api.post('/api/notifications/read', { ids: [a.dataset.n] }).then(refreshSession).catch(() => {}); }));
}
