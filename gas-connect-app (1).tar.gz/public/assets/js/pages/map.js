// Интерактивная карта газозаправочной инфраструктуры.
import { html, raw, api, $, $$, fmt, photo, photoBg, icon, statusBadge, demoBadge, setTitle, state, LABELS, date, toast, showError, go, stationColor, STATION_COLORS, esc } from '../core.js';
import { createMap, stationIcon, proposalIcon, leaflet, legendHtml } from '../components/map.js';

export async function map(ctx) {
  setTitle('Карта заправок');
  ctx.app.innerHTML = String(html`
  <section class="page-hero" style="padding:44px 0 30px"><div class="wrap">
    <span class="eyebrow">Геоинформационный модуль</span>
    <h1>Карта газомоторной инфраструктуры</h1>
    <p class="lead">Действующие АГНКС, КриоАЗС, модульные станции и передвижные заправщики, строящиеся и проектируемые объекты, предложения пользователей и популярные маршруты.</p>
  </div></section>
  <section class="section tight"><div class="wrap">
    <div class="map-shell">
      <aside class="map-panel">
        <div class="filters">
          <div class="search field"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input id="q" type="search" placeholder="Город, трасса, название…" aria-label="Поиск"></div>
          <div class="form-grid" style="gap:8px">
            <select class="select" id="fKind" aria-label="Тип станции"><option value="">Все типы</option>${Object.entries(LABELS.kind).map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select>
            <select class="select" id="fStatus" aria-label="Статус"><option value="">Все статусы</option>${Object.entries(LABELS.stationStatus).filter(([k]) => k !== 'closed').map(([k, v]) => html`<option value="${k}">${v}</option>`)}</select>
            <select class="select" id="fFuel" aria-label="Топливо"><option value="">КПГ и СПГ</option><option value="cng">Только КПГ</option><option value="lng">Только СПГ</option></select>
            <select class="select" id="fYear" aria-label="Год ввода"><option value="">Любой год ввода</option>${[2026, 2027, 2028, 2029, 2030].map((y) => html`<option>${y}</option>`)}</select>
          </div>
          <div class="legend" style="flex-direction:column;gap:7px">
            <label><input type="checkbox" id="lStations" checked> Станции и проекты</label>
            <label><input type="checkbox" id="lProposals" checked> <i class="dot" style="background:${STATION_COLORS.proposal};border-radius:3px"></i> Предложения пользователей</label>
            <label><input type="checkbox" id="lRoutes" checked> <i style="width:18px;height:3px;background:#47c8f5;display:inline-block;border-radius:2px"></i> Популярные маршруты (≥ 2 участников)</label>
            ${state.user ? html`<label><input type="checkbox" id="lMine" checked> <i style="width:18px;height:3px;background:#e7aa44;display:inline-block;border-radius:2px"></i> Мои маршруты</label>` : ''}
          </div>
          <div class="tiny muted" id="count">Загрузка…</div>
        </div>
        <div class="map-list" id="list"></div>
      </aside>
      <div class="map-canvas"><div id="map"></div><div id="drawerHost"></div></div>
    </div>
    <div style="margin-top:14px;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;align-items:center">${raw(legendHtml())}<a class="btn sm primary" href="/vote/new">${icon('plus')} Предложить точку</a></div>
    ${state.meta?.demoData ? html`<div class="notice warn" style="margin-top:14px">${icon('warn')}<p>Станции на карте — демонстрационный тестовый набор: названия и координаты вымышленные (условно в районах городов и трасс). Для боевой версии необходимо загрузить официальный реестр объектов с источником и датой обновления.</p></div>` : ''}
  </div></section>`);

  const L = await leaflet();
  const m = await createMap($('#map'), { zoom: 4 });
  const layers = { stations: L.layerGroup().addTo(m), proposals: L.layerGroup().addTo(m), routes: L.layerGroup().addTo(m), mine: L.layerGroup().addTo(m), extra: L.layerGroup().addTo(m) };
  let stations = [], proposals = [], markers = new Map();

  const [st, pr, rt] = await Promise.all([api.get('/api/stations'), api.get('/api/proposals'), api.get('/api/map/routes')]);
  stations = st.items;
  proposals = pr.items;
  for (const r of rt.popular) L.polyline(r.line, { color: '#47c8f5', weight: Math.min(7, 2 + r.participants / 2), opacity: .55, className: 'flow-line' }).bindTooltip(`${esc(r.name)}: ${r.participants} участников, ${fmt(r.tripsPerMonth)} поездок/мес.`).addTo(layers.routes);
  for (const r of rt.mine) L.polyline(r.line, { color: '#e7aa44', weight: 4, opacity: .9 }).bindTooltip(`Мой маршрут: ${esc(r.name)}`).addTo(layers.mine);

  function filtered() {
    const q = $('#q').value.trim().toLowerCase().replace(/ё/g, 'е');
    const kind = $('#fKind').value, status = $('#fStatus').value, fuel = $('#fFuel').value, year = $('#fYear').value;
    const s = stations.filter((x) => (!kind || x.kind === kind) && (!status || x.status === status) && (!fuel || x.fuels.includes(fuel)) && (!year || String(x.plannedYear) === year)
      && (!q || `${x.name} ${x.region} ${x.address || ''}`.toLowerCase().replace(/ё/g, 'е').includes(q)));
    const p = proposals.filter((x) => (!q || `${x.title} ${x.region} ${x.highway || ''}`.toLowerCase().replace(/ё/g, 'е').includes(q)) && (!kind || x.preferredKind === kind) && !status && !year && (!fuel || (fuel === 'lng' ? x.preferredKind === 'cryo' : x.preferredKind !== 'cryo')));
    return { s, p };
  }

  function render() {
    const { s, p } = filtered();
    layers.stations.clearLayers(); layers.proposals.clearLayers(); layers.extra.clearLayers(); markers = new Map();
    for (const x of s) {
      const mk = L.marker([x.lat, x.lng], { icon: stationIcon(L, x), title: x.name }).on('click', () => openStation(x.id)).addTo(layers.stations);
      mk.bindTooltip(`${esc(x.name)}<br><span style="opacity:.7">${esc(LABELS.kind[x.kind])} · ${esc(x.statusLabel)}</span>`);
      markers.set('s:' + x.id, mk);
      if (x.kind === 'pagz' && x.serviceRadiusKm) L.circle([x.lat, x.lng], { radius: x.serviceRadiusKm * 1000, color: STATION_COLORS.mobile, weight: 1, dashArray: '5 6', fillOpacity: .05 }).bindTooltip('Зона работы передвижного заправщика').addTo(layers.extra);
    }
    for (const x of p) {
      const mk = L.marker([x.lat, x.lng], { icon: proposalIcon(L), title: x.title }).on('click', () => openProposal(x.id)).addTo(layers.proposals);
      mk.bindTooltip(`${esc(x.title)}<br><span style="opacity:.7">Предложение пользователей · ${x.votes} гол.</span>`);
      markers.set('p:' + x.id, mk);
    }
    $('#count').textContent = `Станций и объектов: ${s.length} · предложений: ${p.length}`;
    $('#list').innerHTML = String(html`${s.map((x) => html`<div class="map-item" data-s="${x.id}"><i class="dot" style="background:${stationColor(x)}"></i><div><h4>${x.name}</h4><p>${LABELS.kind[x.kind]} · ${x.statusLabel}${x.plannedYear && x.status !== 'operational' ? ' · ' + x.plannedYear : ''}</p><p>${x.region}</p></div></div>`)}
      ${p.map((x) => html`<div class="map-item" data-p="${x.id}"><i class="dot" style="background:${STATION_COLORS.proposal};border-radius:3px"></i><div><h4>${x.title}</h4><p>Предложение пользователей · ${x.votes} голосов</p><p>${x.region}</p></div></div>`)}
      ${!s.length && !p.length ? html`<div class="empty" style="margin:16px">Ничего не найдено. Измените фильтры.</div>` : ''}`);
    $$('#list [data-s]').forEach((el) => (el.onclick = () => openStation(el.dataset.s, true)));
    $$('#list [data-p]').forEach((el) => (el.onclick = () => openProposal(el.dataset.p, true)));
    toggleLayers();
  }
  function toggleLayers() {
    const t = (id, layer) => { const c = $('#' + id); if (!c) return; if (c.checked) m.addLayer(layer); else m.removeLayer(layer); };
    t('lStations', layers.stations); t('lStations', layers.extra); t('lProposals', layers.proposals); t('lRoutes', layers.routes); t('lMine', layers.mine);
  }
  ['q', 'fKind', 'fStatus', 'fFuel', 'fYear'].forEach((id) => $('#' + id).addEventListener('input', render));
  ['lStations', 'lProposals', 'lRoutes', 'lMine'].forEach((id) => $('#' + id)?.addEventListener('change', toggleLayers));

  function highlight(key, fly) {
    $$('.map-item.active').forEach((el) => el.classList.remove('active'));
    const [t, id] = key.split(':');
    $(`#list [data-${t}="${CSS.escape(id)}"]`)?.classList.add('active');
    const mk = markers.get(key);
    if (mk && fly) m.flyTo(mk.getLatLng(), Math.max(m.getZoom(), 8), { duration: .8 });
  }
  function drawer(content) {
    $('#drawerHost').innerHTML = `<div class="drawer">${content}</div>`;
    $('#drawerHost .x').onclick = () => { $('#drawerHost').innerHTML = ''; history.replaceState({}, '', '/map'); };
  }

  async function openStation(id, fly = false) {
    highlight('s:' + id, fly);
    history.replaceState({}, '', `/map?station=${id}`);
    let s;
    try { s = (await api.get(`/api/stations/${id}`)).item; } catch (e) { showError(e); return; }
    const p = photo(s.photoKey || 'cng-station', 900);
    const cap = s.capacityValue ? `${fmt(s.capacityValue)} ${s.capacityUnit}` : 'не указана';
    drawer(String(html`
      <div class="ph" style="${raw(photoBg(s.photoKey || 'cng-station', 900))}"><button class="x" aria-label="Закрыть">×</button><a class="img-credit" href="${p.page}" target="_blank" rel="noopener">Фото: Wikimedia Commons</a></div>
      <div class="inner">
        <div class="chips" style="gap:6px">${statusBadge(s.status, s.statusLabel)}<span class="badge info plain">${s.kindLabel}</span>${demoBadge(s.isDemo)}</div>
        <h3 style="margin:12px 0 6px;font-size:21px">${s.name}</h3>
        <p class="small muted">${s.description || ''}</p>
        <div class="dl">
          <div>Адрес</div><div>${s.address || '—'}</div>
          <div>Регион</div><div>${s.region || '—'}</div>
          <div>Координаты</div><div>${s.lat.toFixed(4)}, ${s.lng.toFixed(4)}</div>
          <div>Вид топлива</div><div>${s.fuels.map((f) => LABELS.fuel[f]).join(', ')}</div>
          <div>Оператор</div><div>${s.operator || '—'}</div>
          <div>Заправочных постов</div><div>${s.dispensers ?? '—'}</div>
          <div>Проектная производительность</div><div>${cap}</div>
          <div>Часы работы</div><div>${s.hours ? (s.hoursConfirmed ? s.hours : `${s.hours} (не подтверждены)`) : 'не подтверждены'}</div>
          ${s.status !== 'operational' ? html`<div>Планируемый год ввода</div><div>${s.plannedYear || '—'}</div><div>Категория</div><div>${LABELS.planCategory[s.planCategory] || '—'}</div>` : ''}
          ${s.kind === 'pagz' ? html`<div>Зона работы</div><div>радиус ≈ ${fmt(s.serviceRadiusKm)} км, место стоянки меняется</div>` : ''}
          <div>Данные обновлены</div><div>${date(s.dataUpdatedAt)}</div>
          <div>Источник</div><div>${s.sourceUrl ? html`<a href="${s.sourceUrl}" target="_blank" rel="noopener">${s.sourceName || 'ссылка'}</a>` : s.sourceName || '—'}</div>
        </div>
        ${s.fromProposal ? html`<div class="notice" style="margin-top:12px">${icon('vote')}<p>Объект создан по инициативе пользователей «${s.fromProposal.title}» (${s.proposalVotes} голосов).</p></div>` : ''}
        <div class="form-actions" style="margin-top:16px">
          ${s.status === 'operational' ? html`<a class="btn primary sm" href="/routes?toName=${encodeURIComponent(s.name)}&toLat=${s.lat}&toLng=${s.lng}">${icon('route')} Построить маршрут</a>` : ''}
          <button class="btn sm ${s.favorite ? 'voted' : ''}" id="favBtn">${icon('star')} ${s.favorite ? 'В избранном' : 'В избранное'}</button>
        </div>
        <p class="tiny muted" style="margin-top:12px">Подписчики получают уведомления об изменении статуса и сроков. Отслеживают: ${s.followers}.</p>
      </div>`));
    $('#favBtn').onclick = async () => {
      if (!state.user) { toast('Войдите, чтобы добавлять объекты в избранное'); go(`/login?next=${encodeURIComponent('/map?station=' + id)}`); return; }
      try {
        if (s.favorite) await api.del(`/api/favorites/station/${id}`); else await api.post('/api/favorites', { type: 'station', id });
        toast(s.favorite ? 'Удалено из избранного' : 'Добавлено в избранное');
        openStation(id);
      } catch (e) { showError(e); }
    };
  }

  async function openProposal(id, fly = false) {
    highlight('p:' + id, fly);
    const x = proposals.find((p) => p.id === id);
    if (!x) return;
    drawer(String(html`
      <div class="ph" style="${raw(photoBg(x.photoKey || 'highway', 900))}"><button class="x" aria-label="Закрыть">×</button></div>
      <div class="inner">
        <div class="chips" style="gap:6px">${statusBadge(x.status, x.statusLabel)}<span class="badge gray plain">Предложение пользователей</span>${demoBadge(x.isDemo)}</div>
        <h3 style="margin:12px 0 6px;font-size:21px">${x.title}</h3>
        <p class="small muted">${x.justification}</p>
        <div class="dl"><div>Регион</div><div>${x.region}</div><div>Трасса</div><div>${x.highway || '—'}</div><div>Тип станции</div><div>${x.preferredKindLabel}</div>
          <div>Голосов</div><div><b>${fmt(x.votes)}</b></div><div>Заинтересованных ТС</div><div>${fmt(x.demand.vehiclesTotal)} (без двойного учёта)</div><div>Организаций рядом</div><div>${fmt(x.demand.organizations)}</div></div>
        <div class="form-actions" style="margin-top:16px"><a class="btn primary sm" href="/vote/${x.id}">${icon('vote')} Поддержать строительство</a></div>
      </div>`));
  }

  render();
  // Показываем всю сеть целиком: границы по всем объектам.
  const pts = [...stations, ...proposals].map((x) => [x.lat, x.lng]);
  if (pts.length) m.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 6 });
  if (ctx.query.station) openStation(ctx.query.station, true);
  else if (ctx.query.proposal) openProposal(ctx.query.proposal, true);
  ctx.cleanup = () => m.remove();
}
