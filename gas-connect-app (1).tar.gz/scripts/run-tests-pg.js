// Запуск тестов на PostgreSQL: TEST_DATABASE_URL=postgres://user:pass@host:5432/db npm run test:pg
// ВНИМАНИЕ: тесты полностью очищают указанную базу — используйте отдельную тестовую БД.
import { spawnSync } from 'node:child_process';
import { loadDotEnv } from '../server/config.js';

loadDotEnv();
if (!process.env.TEST_DATABASE_URL) {
  console.error('Укажите TEST_DATABASE_URL (отдельная тестовая база, она будет очищена).');
  process.exit(1);
}
const r = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', '--test', '--test-concurrency=1', 'tests/*.test.js'], {
  stdio: 'inherit',
  env: { ...process.env, TEST_DB_DRIVER: 'postgres' },
});
process.exit(r.status ?? 1);
