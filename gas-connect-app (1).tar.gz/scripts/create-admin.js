// Создание учётной записи администратора или оператора для боевой версии.
// Использование: npm run create-admin -- --email admin@example.ru --role admin
// Пароль запрашивается интерактивно (или берётся из переменной ADMIN_PASSWORD).
import readline from 'node:readline';
import { loadDotEnv, buildConfig } from '../server/config.js';
import { openDatabase } from '../server/db/index.js';
import { migrate } from '../server/db/migrate.js';
import { hashPassword, uuid } from '../server/lib/security.js';
import { checkPasswordPolicy } from '../server/api/auth.js';

const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, arr) => (a.startsWith('--') ? [...acc, [a.slice(2), arr[i + 1]]] : acc), []));
const email = String(args.email || '').toLowerCase();
const role = args.role === 'operator' ? 'operator' : 'admin';
if (!email.includes('@')) { console.error('Укажите --email'); process.exit(1); }

async function askPassword() {
  if (process.env.ADMIN_PASSWORD) return process.env.ADMIN_PASSWORD;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question('Пароль (не менее 10 символов, буквы и цифры): ', (a) => { rl.close(); resolve(a); }));
}

loadDotEnv();
const config = buildConfig();
const db = await openDatabase(config.db);
await migrate(db);
const password = await askPassword();
checkPasswordPolicy(password, email);
const now = new Date().toISOString();
const existing = await db.get('SELECT id FROM users WHERE email = ?', [email]);
if (existing) {
  await db.run('UPDATE users SET role = ?, password_hash = ?, status = ?, email_verified_at = COALESCE(email_verified_at, ?), updated_at = ? WHERE id = ?', [role, await hashPassword(password), 'active', now, now, existing.id]);
  console.log(`Пользователь ${email} обновлён, роль: ${role}`);
} else {
  const id = uuid();
  await db.insert('users', { id, email, password_hash: await hashPassword(password), role, account_type: 'staff', status: 'active', email_verified_at: now, created_at: now, updated_at: now });
  await db.insert('profiles', { user_id: id, full_name: role === 'admin' ? 'Администратор платформы' : 'Сотрудник оператора', region: null, updated_at: now });
  console.log(`Создан пользователь ${email}, роль: ${role}`);
}
await db.close();
