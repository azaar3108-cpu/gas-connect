// Применение миграций: npm run migrate
import { loadDotEnv, buildConfig } from '../server/config.js';
import { openDatabase } from '../server/db/index.js';
import { migrate } from '../server/db/migrate.js';

loadDotEnv();
const config = buildConfig();
const db = await openDatabase(config.db);
const done = await migrate(db, { log: (m) => console.log(m) });
console.log(done.length ? `Готово, применено миграций: ${done.length}` : 'Схема БД актуальна, новых миграций нет');
await db.close();
