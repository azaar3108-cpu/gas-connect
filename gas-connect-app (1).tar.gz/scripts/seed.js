// Загрузка демонстрационных данных: npm run seed  (полный сброс БД: npm run db:reset)
import { loadDotEnv, buildConfig } from '../server/config.js';
import { openDatabase } from '../server/db/index.js';
import { migrate, dropAll } from '../server/db/migrate.js';
import { seedDemo, DEMO_ACCOUNTS } from '../server/db/seed-data.js';

loadDotEnv();
const config = buildConfig();
const reset = process.argv.includes('--reset');
if (!config.allowDemoSeed) {
  console.error('Загрузка демо-данных запрещена (ALLOW_DEMO_SEED=false). В боевой версии демо-аккаунты не создаются.');
  process.exit(1);
}
if (reset && config.production) {
  console.error('Сброс базы данных в режиме production запрещён.');
  process.exit(1);
}
const db = await openDatabase(config.db);
if (reset) {
  await dropAll(db);
  console.log('База данных очищена');
}
await migrate(db, { log: (m) => console.log(m) });
const password = config.seedPassword || 'GasDemo2026!';
const res = await seedDemo(db, { password });
if (res.skipped) {
  console.log('Демо-данные уже загружены (найден демо-оператор). Для перезагрузки: npm run db:reset');
} else {
  console.log('\nДемо-данные загружены. Тестовые аккаунты (пароль для всех: ' + (config.seedPassword ? 'из SEED_PASSWORD' : password) + '):');
  const labels = { person: 'Физическое лицо', ip: 'Индивидуальный предприниматель', company: 'Юридическое лицо (владелец)', companyManager: 'Юридическое лицо (менеджер)', company2: 'Юридическое лицо №2', operator: 'Оператор платформы', admin: 'Администратор' };
  for (const [k, email] of Object.entries(DEMO_ACCOUNTS)) console.log(`  ${labels[k].padEnd(34)} ${email}`);
  console.log('\nВНИМАНИЕ: тестовые пароли нельзя использовать в опубликованной версии. В production вход демо-аккаунтов отключён.');
}
await db.close();
